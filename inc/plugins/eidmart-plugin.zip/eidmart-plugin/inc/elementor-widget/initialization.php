<?php

// Initialize Elementor Widget

class ElementorCustomElement
{

	private static $instance = null;

	public static function get_instance()
	{
		if (!self::$instance)
			self::$instance = new self;
		return self::$instance;
	}

	public function init()
	{
		add_action('elementor/widgets/widgets_registered', array($this, 'widgets_registered'));
	}

	public function widgets_registered()
	{
 
      // We check if the Elementor plugin has been installed / activated.
		if (defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')) {
 
         // We look for any theme overrides for this custom Elementor element.
         // If no theme overrides are found we use the default one in this plugin.

			$widget_file = require_once 'elementor-widgets.php';
			$template_file = locate_template($widget_file);
			if (!$template_file || !is_readable($template_file)) {
				$template_file = require_once 'elementor-widgets.php';
			}
			if ($template_file && is_readable($template_file)) {
				require_once $template_file;
			}
		}
	}

}

ElementorCustomElement::get_instance()->init();

// Create new category widget name
function eidmart_elementor_widget_categories( $elements_manager ) {

	// Default Category
	$elements_manager->add_category(
		'eidmart',
		[
			'title' => __( 'Eidmart Default/Software', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);

	// Single Product Category
	$elements_manager->add_category(
		'eidmart_product',
		[
			'title' => __( 'Eidmart Single Product', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);

	// Affiliate Category
	$elements_manager->add_category(
		'eidmart_affiliate',
		[
			'title' => __( 'Eidmart Envato Affiliate', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);

	// Freelancer Category
	// $elements_manager->add_category(
	// 	'eidmart_freelancer',
	// 	[
	// 		'title' => __( 'Eidmart Freelancer', 'eidmart' ),
	// 		'icon' => 'fa fa-plug',
	// 	]
	// );

	// Photography Category
	$elements_manager->add_category(
		'eidmart_photography',
		[
			'title' => __( 'Eidmart Photography', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);

	// Graphics Category
	$elements_manager->add_category(
		'eidmart_graphics',
		[
			'title' => __( 'Eidmart Graphics', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);
	
	// Audio Category
	$elements_manager->add_category(
		'eidmart_audio',
		[
			'title' => __( 'Eidmart Audio', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);

	// Video Category
	$elements_manager->add_category(
		'eidmart_video',
		[
			'title' => __( 'Eidmart Video', 'eidmart' ),
			'icon' => 'fa fa-plug',
		]
	);	

}
add_action( 'elementor/elements/categories_registered', 'eidmart_elementor_widget_categories' );


