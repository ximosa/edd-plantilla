jQuery(document).ready(function($) {
    /*******************************
     follow / unfollow a user
     *******************************/
    $( '.followsoft-follow-link' ).on('click', function(e) {
        e.preventDefault();

        var $this = $(this);

        if( followsoft_vars.logged_in != 'undefined' && followsoft_vars.logged_in != 'true' ) {
            alert( followsoft_vars.login_required );
            return;
        }

        var data      = {
            action:    $this.hasClass('follow') ? 'follow' : 'unfollow',
            user_id:   $this.data('user-id'),
            follow_id: $this.data('follow-id'),
            nonce:     followsoft_vars.nonce
        };

        $('img.followsoft_vars-ajax').show();

        $.post( followsoft_vars.ajaxurl, data, function(response) {
            if( response == 'success' ) {
                $('.followsoft-follow-link').toggle();
            } else {
                alert( followsoft_vars.processing_error );
            }
            $('img.followsoft_vars-ajax').hide();
        } );
    });
});