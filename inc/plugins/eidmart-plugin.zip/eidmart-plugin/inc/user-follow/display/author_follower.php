<?php
/**
 * Author follower information
 */

// Collect all follower users for vendor dashboard page
if( get_current_user_id() ):
    $followers = get_user_meta( get_current_user_id(), '_followsoft_followers', true );
endif;

// Collect all follower users for author page
$author_id = isset( $author->ID ) ? $author->ID : '';
if( $author_id ):
    $followers = get_user_meta( $author_id, '_followsoft_followers', true );
endif;

// Collect all follower users for vendor page
$user_id = isset( $user->ID ) ? $user->ID : '';
if( $user_id ):
    $followers = get_user_meta( $user_id, '_followsoft_followers', true );
endif;

/**
 * Follower users check
 */
if( isset( $followers ) && is_array( $followers ) ) {

    $number_elem_per_page = 40;
    $page = isset( $_GET['follower_page'] ) ? intval( $_GET['follower_page'] - 1 ) : 0;

    // Remove first index
    array_shift( $followers );

    $total_id = count( $followers );
    $number_of_pages = intval( $total_id / $number_elem_per_page ) + 1;

    foreach ( array_slice( $followers, $page*$number_elem_per_page, $number_elem_per_page ) as $follow ) {
        
        // Collect user information
        $user = get_user_by( 'id', $follow );

        if( isset( $user->display_name ) ) {

            $post_item = count_user_posts( $user->ID, 'post' );
            $download_item = count_user_posts( $user->ID, 'download' );

            $article_text = ( $post_item <= 0 ) ? __( 'Article', 'eidmart' ) : __( 'Articles', 'eidmart' );
            $item_text = ( $download_item <= 0 ) ? __( 'Item', 'eidmart' ) : __( 'Items', 'eidmart' );

            ?>

            <div class="col-md-3">
                <div class="follower-following-users">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <?php echo get_avatar( $user->ID ); ?>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5><a href="<?php echo esc_url( get_author_posts_url( $user->ID ) ); ?>"><?php echo esc_html( $user->display_name ); ?></a></h5>
                            <?php if( $post_item > 0 ): ?>
                                <span class="user-article">
                                    <i class="las la-pen"></i> <a href="<?php echo esc_url( get_author_posts_url( $user->ID ) ); ?>"><?php printf( '%s %s', $post_item, $article_text ); ?></a>
                                </span>
                            <?php 
                            endif; // End blog post
                            if( class_exists( 'EDD_Front_End_Submissions' ) && $download_item > 0 ){ ?>												                          
                                <span class="user-item">
                                    <i class="las la-tag"></i> <a href="<?php echo esc_url( EDD_FES()->vendors->get_vendor_store_url( $user->ID ) ); ?>"> <?php printf( '%s %s', $download_item, $item_text ); ?></a>
                                </span>											
                            <?php } // End item post ?>											
                        </div>
                    </div>
                </div>
            </div>

            <?php
        } // User name check end

    } if( $total_id > $number_elem_per_page ) { ?>
    
    <div class="col-md-12">
        <div class="course-pagination text-left"><br>
            <ul class="pagination">
                <?php
                for( $i = 1; $i <= $number_of_pages; $i++ ) { ?>
                    <li><a class="page-numbers <?php if( $page == $i-1 ): echo "current"; endif; ?>" href="<?php echo esc_url( add_query_arg( 'follower_page', $i, $_SERVER['REQUEST_URI'] )); ?>"><?php echo esc_html( $i ); ?></a></li> &nbsp;
                <?php } ?>
            </ul>
        </div>
    </div>

    <?php } // Pagination check end 

} // Following users check end 