<?php

/**
 * Theme Name: Eidmart
 * Eidmart Product Fetch Query
 */


// Query list type product
function eidmart_list_quary() {
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;         
     
    // Paginationselection
    if( isset( $_GET['page'] ) ){
      $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'download_category' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;
        

    } else {        
        
        
    if( is_post_type_archive( 'download' )):

    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query( $args ); 

    if( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            
            $sales = edd_get_download_sales_stats(get_the_ID());
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
                   
            ?>
			<div class="col-md-12">
	            <div class="media">
	                <?php the_post_thumbnail();

                    if ( !empty(get_post_meta($post->ID, 'edd_feature_download')) ): ?>
                        <span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
                    <?php endif;
                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

	                <div class="media-body">
	                    <div class="product-content">
	                        <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char_list', '50' ) ); ?></a>
	                        <?php if( get_theme_mod( 'author' ) =='on' ): 

                            // Collect user ID
                            $user_id = get_the_author_meta( 'ID' ); 
                            // Collect user name
							$user_name = get_the_author_meta( 'user_login' , $user_id );

                            if( !class_exists( 'EDD_Front_End_Submissions' ) ){ ?>
	                            <p><?php esc_html_e( 'by ', 'eidmart' ); ?><a href="<?php echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); ?>"><span><?php the_author(); ?></span></a>
	                        <?php } else { ?>                       
                       	        <p><?php esc_html_e( 'by ', 'eidmart' ); ?><a href="<?php echo esc_url( eidmart_edd_fes_author_url() ); ?>"><span><?php the_author(); ?></span></a></p>
	                        <?php 
	                    	} // End author url

	                    	endif;
	                    	if( get_theme_mod( 'category' ) =='on' ):
		                        $terms = get_the_terms( $id , 'download_category' );
		                        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		                            //foreach ( $terms as $term ) {
		                                ?>		                    
		                                <p><?php esc_html_e( 'in ', 'eidmart' ); ?><a href="<?php echo esc_url( get_term_link( $terms[0]) ); ?>"><span><?php echo esc_html( $terms[0]->name ); ?></span></a> </p>
		                                <?php							  
		                            //}
		                        }
	                        endif;
	                        
                            // Check product paragraph
                            if ( get_theme_mod( 'product_para' ) == 'on'): ?>
                                <p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '100' ); endif; ?></p>
                            <?php endif;?>

	                        <h3>
                                <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
	                            <small>
	                                <?php if( $edd_price ){ ?>
	                                    <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
	                                <?php } else { ?>
	                                    <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
	                                <?php } ?>
	                                <?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
	                            </small>                                
	                        </h3>

	                        <?php if ( get_theme_mod( 'sale' ) =='on'): ?>
                            <div class="product-content-footer">
                                <h4>
                                <?php
                                if (class_exists('EDD_Reviews') && get_theme_mod('eid_ratings') == 'on') {
                                    echo "<span class='bt-review'>";
                                    $mreview = new \EDD_Reviews;                                        

                                    $rating = $mreview->average_rating(false);
                                    echo $mreview->render_star_rating( $rating );
                                    echo $mreview->display_total_reviews_count();

                                    echo "</span>";
                                } // End ratings check

                                if ( get_theme_mod('eid_love') == 'on' ):
                                ?>
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

                                <?php endif; if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo esc_html( $sales );
                                endif;
                                ?>
                                </h4>
                            </div>
	                    	<?php endif; ?>

	                    </div>                                         
	                </div>
	            </div>
        	</div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ):
    ?>               
	<div class="col-md-12">
	    <div class="course-pagination">
	      	<ul class="pagination">
	            <li>
					<?php

					global $wp_query;
			
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(							
						
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
	                    'total'        => $wp_query->max_num_pages,
	                    'current'      => max( 1, get_query_var( 'paged' ) ),
	                    'format'       => '?paged=%#%',
	                    'show_all'     => false,
	                    'type'         => 'plain',
	                    'end_size'     => 2,
	                    'mid_size'     => 1,
	                    'prev_next'    => true,
	                    'prev_text' => '<i class="fa fa-angle-left"></i>',
						'next_text' => '<i class="fa fa-angle-right"></i>',
	                    'add_args'     => false,
	                    'add_fragment' => ''

					) );

					?>
	          	</li>
	      	</ul>
		</div>
	</div>

    <?php

    endif;

    else:   // If no post

        get_template_part( 'template-parts/content','none' );

    endif;  // End posts checking                   

}
add_action( 'list_product','eidmart_list_quary' );


// Query Grid type product
function eidmart_grid_quary() {
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;        
     
    // Paginationselection
    if(isset($_GET['page'])){
      $posts_per_page_eidmart = esc_sql($_GET['page']);
    }else{
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'download_category' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;
        

    } else {        
        
        
    if( is_post_type_archive( 'download' )):

    switch ( $wp_query->query['orderby'] ) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

  	$wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );  
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;            
            
            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;

            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-6' ) ); ?>">               
               
                <div class="single-product hover01">
                    <figure>
                        <?php the_post_thumbnail(); ?>
                    </figure>

                    <?php if (!empty(get_post_meta($post->ID, 'edd_feature_download'))): ?>
                        <span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
                    <?php endif;

                    /**
                     * Discount percentage calculation 
                     * @ edd_has_variable_prices( $id )
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>
                    
                    <div class="product-details">
                        <div class="product-content">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a>

                            <?php if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ): ?>
                            <p> 

	                            <?php
	                            // Collect user ID
	                            $user_id = get_the_author_meta( 'ID' ); 
	                            // Collect user name
								$user_name = get_the_author_meta( 'user_login' , $user_id );

	                            if( get_theme_mod( 'author' ) =='on' ):
		                        esc_html_e( 'by', 'eidmart' ); 

		                        if( !class_exists( 'EDD_Front_End_Submissions' ) ){ ?>
		                          <a href="<?php echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); ?>"> <?php the_author(); ?></a>
		                        <?php } else { ?>		                          
		                          <a href="<?php echo esc_url( eidmart_edd_fes_author_url() ); ?>"> <?php the_author(); ?></a>
		                        <?php
		                        } // End author url

                            	endif;
                            	if( get_theme_mod( 'category' ) =='on' ):
                            	esc_html_e( 'in', 'eidmart' ); ?>
                            	<?php
                                    $terms = get_the_terms( $id , 'download_category' );
                                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                        //foreach ( $terms as $term ) {
                                            ?>                                
                                            <a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a>
                                            <?php							  
                                        //}
                                    }
                                endif;
                                ?>
                            </p>
                            <?php else: ?>
                            	<div class="padding-top-very-small"></div>
                            <?php endif; 

                            // Check product paragraph
                            if( get_theme_mod( 'product_para' ) =='on' ):
                            ?>
                              <p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '70' ); endif; ?></p>
                            <?php endif; ?>

                            <h3 class="<?php if ( get_theme_mod( 'sale' ) != 'on'): echo esc_attr( "price-n-preview" ); endif; ?>"> 
                                <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
                                <span class="cart-btn">
                                    <?php if( $edd_price ){ ?>
                                        <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
                                    <?php } else { ?>
                                        <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
                                    <?php } ?>
                                    <?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
                                </span>                                
                            </h3>
                        </div>

                        <?php if ( get_theme_mod( 'sale' ) =='on'): ?>
                        <div class="product-content-footer">
                            <h4>
                            <?php
                            if (class_exists('EDD_Reviews') && get_theme_mod('eid_ratings') == 'on') {
                                echo "<span class='bt-review'>";
                                $mreview = new \EDD_Reviews;                                        

                                $rating = $mreview->average_rating(false);
                                echo $mreview->render_star_rating( $rating );
                                echo $mreview->display_total_reviews_count();

                                echo "</span>";
                            } // End ratings check

                            if (get_theme_mod('eid_love') == 'on'):
                            ?>
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

                            <?php endif; if (get_theme_mod('eid_sales') == 'on'): 
                                echo "<span>".esc_html( $sales )."</span>";
                            endif;
                            ?>
                            </h4>
                        </div> 
                        <?php endif; ?>

                    </div>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ):
    ?>               

    <div class="col-md-12">
	    <div class="course-pagination">
	      	<ul class="pagination">
	            <li>
					<?php

					global $wp_query;
			
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(							
						
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
	                    'total'        => $wp_query->max_num_pages,
	                    'current'      => max( 1, get_query_var( 'paged' ) ),
	                    'format'       => '?paged=%#%',
	                    'show_all'     => false,
	                    'type'         => 'plain',
	                    'end_size'     => 2,
	                    'mid_size'     => 1,
	                    'prev_next'    => true,
	                    'prev_text' => '<i class="fa fa-angle-left"></i>',
						'next_text' => '<i class="fa fa-angle-right"></i>',
	                    'add_args'     => false,
	                    'add_fragment' => ''

					) );

					?>
	          	</li>
	      	</ul>
		</div>
	</div>

    <?php

    endif;

    else:   // If no post

        get_template_part( 'template-parts/content','none' );

    endif;  // End posts checking                   

}
add_action( 'grid_product','eidmart_grid_quary' );


// Query by grid product tag
function eidmart_product_tag_quary() {
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
     
    // Paginationselection
    if(isset($_GET['page'])){
      $posts_per_page_eidmart = esc_sql($_GET['page']);
    }else{
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart, 
           'download_tag' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;
        

    } else { 
        
        
        
    if( is_post_type_archive( 'download' )):

    switch ( $wp_query->query['orderby'] ) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

  	$wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );  
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;            
            
            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;

            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-6' ) ); ?>">               
               
                <div class="single-product hover01">
                    <figure>
                        <?php the_post_thumbnail(); ?>
                    </figure>

                    <?php if (!empty(get_post_meta($post->ID, 'edd_feature_download'))): ?>
                        <span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
                    <?php endif;

                    /**
                     * Discount percentage calculation 
                     * @ edd_has_variable_prices( $id )
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>
                    
                    <div class="product-details">
                        <div class="product-content">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a>

                            <?php if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ): ?>
                            <p> 

	                            <?php
	                            // Collect user ID
	                            $user_id = get_the_author_meta( 'ID' ); 
	                            // Collect user name
								$user_name = get_the_author_meta( 'user_login' , $user_id );

	                            if( get_theme_mod( 'author' ) =='on' ):
		                        esc_html_e( 'by', 'eidmart' ); 

		                        if( !class_exists( 'EDD_Front_End_Submissions' ) ){ ?>
		                          <a href="<?php echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); ?>"> <?php the_author(); ?></a>
		                        <?php } else { ?>		                          
		                          <a href="<?php echo esc_url( eidmart_edd_fes_author_url() ); ?>"> <?php the_author(); ?></a>
		                        <?php
		                        } // End author url

                            	endif;
                            	if( get_theme_mod( 'category' ) =='on' ):
                            	esc_html_e( 'in', 'eidmart' ); ?>
                            	<?php
                                    $terms = get_the_terms( $id , 'download_category' );
                                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                        //foreach ( $terms as $term ) {
                                            ?>                                
                                            <a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a>
                                            <?php							  
                                        //}
                                    }
                                endif;
                                ?>
                            </p>
                            <?php else: ?>
                            	<div class="padding-top-very-small"></div>
                            <?php endif; 

                            // Check product paragraph
                            if( get_theme_mod( 'product_para' ) =='on' ):
                            ?>
                              <p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '70' ); endif; ?></p>
                            <?php endif; ?>

                            <h3 class="<?php if ( get_theme_mod( 'sale' ) != 'on'): echo esc_attr( "price-n-preview" ); endif; ?>"> 
                                <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
                                <span class="cart-btn">
                                    <?php if( $edd_price ){ ?>
                                        <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
                                    <?php } else { ?>
                                        <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
                                    <?php } ?>
                                    <?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
                                </span>                                
                            </h3>
                        </div>

                        <?php if ( get_theme_mod( 'sale' ) =='on'): ?>
                        <div class="product-content-footer">
                            <h4>
                            <?php
                            if (class_exists('EDD_Reviews') && get_theme_mod('eid_ratings') == 'on') {
                                echo "<span class='bt-review'>";
                                $mreview = new \EDD_Reviews;                                        

                                $rating = $mreview->average_rating(false);
                                echo $mreview->render_star_rating( $rating );
                                echo $mreview->display_total_reviews_count();

                                echo "</span>";
                            } // End ratings check

                            if (get_theme_mod('eid_love') == 'on'):
                            ?>
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

                            <?php endif; if (get_theme_mod('eid_sales') == 'on'): 
                                echo "<span>".esc_html( $sales )."</span>";
                            endif;
                            ?>
                            </h4>
                        </div> 
                        <?php endif; ?>

                    </div>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ):
    ?>               

    <div class="col-md-12">
	    <div class="course-pagination">
	      	<ul class="pagination">
	            <li>
					<?php

					global $wp_query;
			
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(							
						
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
	                    'total'        => $wp_query->max_num_pages,
	                    'current'      => max( 1, get_query_var( 'paged' ) ),
	                    'format'       => '?paged=%#%',
	                    'show_all'     => false,
	                    'type'         => 'plain',
	                    'end_size'     => 2,
	                    'mid_size'     => 1,
	                    'prev_next'    => true,
	                    'prev_text' => '<i class="fa fa-angle-left"></i>',
						'next_text' => '<i class="fa fa-angle-right"></i>',
	                    'add_args'     => false,
	                    'add_fragment' => ''

					) );

					?>
	          	</li>
	      	</ul>
		</div>
	</div>

    <?php

    endif;

    else:   // If no post

        get_template_part( 'template-parts/content','none' );

    endif;  // End posts checking                   

}
add_action( 'product_tag','eidmart_product_tag_quary' );


// Query by list product tag
function eidmart_product_list_tag_quary() {
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
     
    // Paginationselection
    if(isset($_GET['page'])){
      $posts_per_page_eidmart = esc_sql($_GET['page']);
    }else{
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart, 
           'download_tag' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;
        

    } else { 
        
        
        
    if( is_post_type_archive( 'download' )):

    switch ( $wp_query->query['orderby'] ) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

  	$wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            
            $sales = edd_get_download_sales_stats(get_the_ID());
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
                   
            ?>
			<div class="col-md-12">
	            <div class="media">
	                <?php the_post_thumbnail();

                    if ( !empty(get_post_meta($post->ID, 'edd_feature_download')) ): ?>
                        <span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
                    <?php endif;
                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

	                <div class="media-body">
	                    <div class="product-content">
	                        <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char_list', '50' ) ); ?></a>
	                        <?php if( get_theme_mod( 'author' ) =='on' ): 

                            // Collect user ID
                            $user_id = get_the_author_meta( 'ID' ); 
                            // Collect user name
							$user_name = get_the_author_meta( 'user_login' , $user_id );

                            if( !class_exists( 'EDD_Front_End_Submissions' ) ){ ?>
	                            <p><?php esc_html_e( 'by ', 'eidmart' ); ?><a href="<?php echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); ?>"><span><?php the_author(); ?></span></a>
	                        <?php } else { ?>                       
                       	        <p><?php esc_html_e( 'by ', 'eidmart' ); ?><a href="<?php echo esc_url( eidmart_edd_fes_author_url() ); ?>"><span><?php the_author(); ?></span></a></p>
	                        <?php 
	                    	} // End author url

	                    	endif;
	                    	if( get_theme_mod( 'category' ) =='on' ):
		                        $terms = get_the_terms( $id , 'download_category' );
		                        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		                            //foreach ( $terms as $term ) {
		                                ?>		                    
		                                <p><?php esc_html_e( 'in ', 'eidmart' ); ?><a href="<?php echo esc_url( get_term_link( $terms[0]) ); ?>"><span><?php echo esc_html( $terms[0]->name ); ?></span></a> </p>
		                                <?php							  
		                            //}
		                        }
	                        endif;
	                        
                            // Check product paragraph
                            if ( get_theme_mod( 'product_para' ) == 'on'): ?>
                                <p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '100' ); endif; ?></p>
                            <?php endif;?>

	                        <h3>
                                <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
	                            <small>
	                                <?php if( $edd_price ){ ?>
	                                    <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
	                                <?php } else { ?>
	                                    <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
	                                <?php } ?>
	                                <?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
	                            </small>                                
	                        </h3>

	                        <?php if ( get_theme_mod( 'sale' ) =='on'): ?>
                            <div class="product-content-footer">
                                <h4>
                                <?php
                                if (class_exists('EDD_Reviews') && get_theme_mod('eid_ratings') == 'on') {
                                    echo "<span class='bt-review'>";
                                    $mreview = new \EDD_Reviews;                                        

                                    $rating = $mreview->average_rating(false);
                                    echo $mreview->render_star_rating( $rating );
                                    echo $mreview->display_total_reviews_count();

                                    echo "</span>";
                                } // End ratings check

                                if ( get_theme_mod('eid_love') == 'on' ):
                                ?>
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

                                <?php endif; if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo esc_html( $sales );
                                endif;
                                ?>
                                </h4>
                            </div>
	                    	<?php endif; ?>

	                    </div>                                         
	                </div>
	            </div>
        	</div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ):
    ?>               

    <div class="col-md-12">
	    <div class="course-pagination">
	      	<ul class="pagination">
	            <li>
					<?php

					global $wp_query;
			
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(							
						
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
	                    'total'        => $wp_query->max_num_pages,
	                    'current'      => max( 1, get_query_var( 'paged' ) ),
	                    'format'       => '?paged=%#%',
	                    'show_all'     => false,
	                    'type'         => 'plain',
	                    'end_size'     => 2,
	                    'mid_size'     => 1,
	                    'prev_next'    => true,
	                    'prev_text' => '<i class="fa fa-angle-left"></i>',
						'next_text' => '<i class="fa fa-angle-right"></i>',
	                    'add_args'     => false,
	                    'add_fragment' => ''

					) );

					?>
	          	</li>
	      	</ul>
		</div>
	</div>

    <?php

    endif;

    else:   // If no post

        get_template_part( 'template-parts/content','none' );

    endif;  // End posts checking                   

}
add_action( 'product_List_tag','eidmart_product_list_tag_quary' );


// Query by grid product search
function eidmart_search_inquary() {
/**
*  Custom query
*/  
global $wp_query;

$martax_query = array();

if( isset( $_GET['download_cat'] ) && $_GET['download_cat'] != 'all' ){
    $downloadcat = $_GET['download_cat'];
    $martax_query =	array(
        array(
            'taxonomy' => 'download_category',
            'field'    => 'slug',
            'terms'    => $downloadcat
        )
    );
}

// Paginationselection
if(isset($_GET['page'])){
  $posts_per_page_eidmart = esc_sql($_GET['page']);
}else{
  $posts_per_page_eidmart = get_option( 'posts_per_page' );
}
$paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
if ( ! isset( $wp_query -> query['orderby'] ) ) {

    $args = array(
        's'			=> get_search_query(),
        'orderby' 	=> 'date',
        'order' 	=> 'DESC',
        'post_type' => 'download',
        'posts_per_page'=> $posts_per_page_eidmart,
        'paged' 	=> $paged,
        'tax_query' => $martax_query
    );

} else {
    switch ($wp_query -> query['orderby']) {

        case 'newest': 
        $args = array( 
        	's'			=> get_search_query(),
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
        	's'			=> get_search_query(),
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'tax_query' => $martax_query,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;

    }
}

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

  	$wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );  
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;            
            
            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;

            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-6' ) ); ?>">               
               
                <div class="single-product hover01">
                    <figure>
                        <?php the_post_thumbnail(); ?>
                    </figure>

                    <?php if (!empty(get_post_meta($post->ID, 'edd_feature_download'))): ?>
                        <span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
                    <?php endif;

                    /**
                     * Discount percentage calculation 
                     * @ edd_has_variable_prices( $id )
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>
                    
                    <div class="product-details">
                        <div class="product-content">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a>

                            <?php if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ): ?>
                            <p> 

	                            <?php
	                            // Collect user ID
	                            $user_id = get_the_author_meta( 'ID' ); 
	                            // Collect user name
								$user_name = get_the_author_meta( 'user_login' , $user_id );

	                            if( get_theme_mod( 'author' ) =='on' ):
		                        esc_html_e( 'by', 'eidmart' ); 

		                        if( !class_exists( 'EDD_Front_End_Submissions' ) ){ ?>
		                          <a href="<?php echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); ?>"> <?php the_author(); ?></a>
		                        <?php } else { ?>		                          
		                          <a href="<?php echo esc_url( eidmart_edd_fes_author_url() ); ?>"> <?php the_author(); ?></a>
		                        <?php
		                        } // End author url

                            	endif;
                            	if( get_theme_mod( 'category' ) =='on' ):
                            	esc_html_e( 'in', 'eidmart' ); ?>
                            	<?php
                                    $terms = get_the_terms( $id , 'download_category' );
                                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                        //foreach ( $terms as $term ) {
                                            ?>                                
                                            <a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a>
                                            <?php							  
                                        //}
                                    }
                                endif;
                                ?>
                            </p>
                            <?php else: ?>
                            	<div class="padding-top-very-small"></div>
                            <?php endif; 

                            // Check product paragraph
                            if( get_theme_mod( 'product_para' ) =='on' ):
                            ?>
                              <p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '70' ); endif; ?></p>
                            <?php endif; ?>

                            <h3 class="<?php if ( get_theme_mod( 'sale' ) != 'on'): echo esc_attr( "price-n-preview" ); endif; ?>"> 
                                <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
                                <span class="cart-btn">
                                    <?php if( $edd_price ){ ?>
                                        <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
                                    <?php } else { ?>
                                        <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
                                    <?php } ?>
                                    <?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
                                </span>                                
                            </h3>
                        </div>

                        <?php if ( get_theme_mod( 'sale' ) =='on'): ?>
                        <div class="product-content-footer">
                            <h4>
                            <?php
                            if (class_exists('EDD_Reviews') && get_theme_mod('eid_ratings') == 'on') {
                                echo "<span class='bt-review'>";
                                $mreview = new \EDD_Reviews;                                        

                                $rating = $mreview->average_rating(false);
                                echo $mreview->render_star_rating( $rating );
                                echo $mreview->display_total_reviews_count();

                                echo "</span>";
                            } // End ratings check

                            if (get_theme_mod('eid_love') == 'on'):
                            ?>
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

                            <?php endif; if (get_theme_mod('eid_sales') == 'on'): 
                                echo "<span>".esc_html( $sales )."</span>";
                            endif;
                            ?>
                            </h4>
                        </div> 
                        <?php endif; ?>

                    </div>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ):

    ?>               

    <div class="col-md-12">
	    <div class="course-pagination">
	      	<ul class="pagination">
	            <li>
					<?php

					global $wp_query;
			
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(							
						
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
	                    'total'        => $wp_query->max_num_pages,
	                    'current'      => max( 1, get_query_var( 'paged' ) ),
	                    'format'       => '?paged=%#%',
	                    'show_all'     => false,
	                    'type'         => 'plain',
	                    'end_size'     => 2,
	                    'mid_size'     => 1,
	                    'prev_next'    => true,
	                    'prev_text' => '<i class="fa fa-angle-left"></i>',
						'next_text' => '<i class="fa fa-angle-right"></i>',
	                    'add_args'     => false,
	                    'add_fragment' => ''

					) );

					?>
	          	</li>
	      	</ul>
		</div>
	</div>

    <?php

    endif;

    else:   // If no post

        get_template_part( 'template-parts/content','none' );

    endif;  // End posts checking  

}
add_action( 'search_product' ,'eidmart_search_inquary' ); 


// Query by product list search
function eidmart_search_list_inquary() {
/**
*  Custom query
*/  
global $wp_query;

$martax_query = array();
if( isset( $_GET['download_cat'] ) && $_GET['download_cat'] != 'all' ){
    $downloadcat = $_GET['download_cat'];
    $martax_query =	array(
        array(
            'taxonomy' => 'download_category',
            'field'    => 'slug',
            'terms'    => $downloadcat
        )
    );
}

// Paginationselection
if(isset($_GET['page'])){
  $posts_per_page_eidmart = esc_sql($_GET['page']);
}else{
  $posts_per_page_eidmart = get_option( 'posts_per_page' );
}
$paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
if ( ! isset( $wp_query -> query['orderby'] ) ) {

    $args = array(
        's'			=> get_search_query(),
        'orderby' 	=> 'date',
        'order' 	=> 'DESC',
        'post_type' => 'download',
        'posts_per_page'=> $posts_per_page_eidmart,
        'paged' 	=> $paged,
        'tax_query' => $martax_query
    );

} else {
    switch ($wp_query -> query['orderby']) {

        case 'newest': 
        $args = array( 
        	's'			=> get_search_query(),
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
        	's'			=> get_search_query(),
		    'meta_query'       => array(
		        'relation'    => 'AND',
		        array(
		            'key'          => '_edd_download_sales',
		        ),
		        array(
		            'key'          => 'eidmart_post_views_count',
		        )
		    ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
        	's'			=> get_search_query(),
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'tax_query' => $martax_query,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;



    }
}

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

  	$wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';            
            $sales = edd_get_download_sales_stats(get_the_ID());
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
                   
            ?>
			<div class="col-md-12">
	            <div class="media">
	                <?php the_post_thumbnail();

                    if ( !empty(get_post_meta($post->ID, 'edd_feature_download')) ): ?>
                        <span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
                    <?php endif;
                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

	                <div class="media-body">
	                    <div class="product-content">
	                        <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char_list', '50' ) ); ?></a>
	                        <?php if( get_theme_mod( 'author' ) =='on' ): 

                            // Collect user ID
                            $user_id = get_the_author_meta( 'ID' ); 
                            // Collect user name
							$user_name = get_the_author_meta( 'user_login' , $user_id );

                            if( !class_exists( 'EDD_Front_End_Submissions' ) ){ ?>
	                            <p><?php esc_html_e( 'by ', 'eidmart' ); ?><a href="<?php echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); ?>"><span><?php the_author(); ?></span></a>
	                        <?php } else { ?>                       
                       	        <p><?php esc_html_e( 'by ', 'eidmart' ); ?><a href="<?php echo esc_url( eidmart_edd_fes_author_url() ); ?>"><span><?php the_author(); ?></span></a></p>
	                        <?php 
	                    	} // End author url

	                    	endif;
	                    	if( get_theme_mod( 'category' ) =='on' ):
		                        $terms = get_the_terms( $id , 'download_category' );
		                        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		                            //foreach ( $terms as $term ) {
		                                ?>		                    
		                                <p><?php esc_html_e( 'in ', 'eidmart' ); ?><a href="<?php echo esc_url( get_term_link( $terms[0]) ); ?>"><span><?php echo esc_html( $terms[0]->name ); ?></span></a> </p>
		                                <?php							  
		                            //}
		                        }
	                        endif;
	                        
                            // Check product paragraph
                            if ( get_theme_mod( 'product_para' ) == 'on'): ?>
                                <p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '100' ); endif; ?></p>
                            <?php endif;?>

	                        <h3>
                                <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
	                            <small>
	                                <?php if( $edd_price ){ ?>
	                                    <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
	                                <?php } else { ?>
	                                    <?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
	                                <?php } ?>
	                                <?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
	                            </small>                                
	                        </h3>

	                        <?php if ( get_theme_mod( 'sale' ) =='on'): ?>
                            <div class="product-content-footer">
                                <h4>
                                <?php
                                if (class_exists('EDD_Reviews') && get_theme_mod('eid_ratings') == 'on') {
                                    echo "<span class='bt-review'>";
                                    $mreview = new \EDD_Reviews;                                        

                                    $rating = $mreview->average_rating(false);
                                    echo $mreview->render_star_rating( $rating );
                                    echo $mreview->display_total_reviews_count();

                                    echo "</span>";
                                } // End ratings check

                                if ( get_theme_mod('eid_love') == 'on' ):
                                ?>
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

                                <?php endif; if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo esc_html( $sales );
                                endif;
                                ?>
                                </h4>
                            </div>
	                    	<?php endif; ?>

	                    </div>                                         
	                </div>
	            </div>
        	</div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ):

    ?>               

    <div class="col-md-12">
	    <div class="course-pagination">
	      	<ul class="pagination">
	            <li>
					<?php

					global $wp_query;
			
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(							
						
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
	                    'total'        => $wp_query->max_num_pages,
	                    'current'      => max( 1, get_query_var( 'paged' ) ),
	                    'format'       => '?paged=%#%',
	                    'show_all'     => false,
	                    'type'         => 'plain',
	                    'end_size'     => 2,
	                    'mid_size'     => 1,
	                    'prev_next'    => true,
	                    'prev_text' => '<i class="fa fa-angle-left"></i>',
						'next_text' => '<i class="fa fa-angle-right"></i>',
	                    'add_args'     => false,
	                    'add_fragment' => ''

					) );

					?>
	          	</li>
	      	</ul>
		</div>
	</div>

    <?php

    endif;

    else:   // If no post

        get_template_part( 'template-parts/content','none' );

    endif;  // End posts checking  

}
add_action( 'search_product_list' ,'eidmart_search_list_inquary' );



/*================================================================================
 * Photography *******************************************************************
 * ===============================================================================
 */

// Photography archive product
function eidmart_photography_product() { 
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;        
     
    // Paginationselection
    if(isset($_GET['page'])){
      $posts_per_page_eidmart = esc_sql($_GET['page']);
    }else{
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'download_category' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;
        

    } else {         
        
        
    if( is_post_type_archive( 'download' )):

    switch ( $wp_query->query['orderby'] ) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_category' => $term->slug,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):

    ?>

    <div class="grid">
    <div class="grid-sizer"></div> 

    <?php

        $count = 0;
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;
            $count++;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;
            
            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            // Code for ad possition
            if( $count == get_theme_mod( 'ad_position_1' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_1' ); ?>
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_2' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_2' ); ?>    
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_3' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_3' ); ?>   
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_4' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_4' ); ?>  
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_5' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_5' ); ?>   
                </div>
            <?php } // End ad position ?>

            <div class="grid-item">
                <a href="<?php the_permalink(); ?>">
                    <div class="img-gradient">
                        <?php the_post_thumbnail(); ?>
                    </div>
                </a>

                <?php
                /**
                 * Discount percentage calculation
                 */
                if( $sale_price && edd_has_variable_prices( $id ) ):
                    $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                elseif( $single_sale_price ):
                    $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                else:
                    $discount_percent = 0;
                endif;

                /**
                 * Discount Percentage
                 */
                if( $discount_percent > 0 ):
                ?>
                <p class="discount-percentage">
                    <span><?php echo esc_html( $discount_percent ); ?>%</span>
                    <?php esc_html_e( 'Off', 'eidmart' ); ?>
                </p>
                <?php endif; 
                
                if( get_theme_mod( 'eid_love' ) == 'on' ): ?>
                    <div class="image-rating">
                        <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
                    </div>
                <?php endif; if ( get_theme_mod( 'eid_price_con' ) == 'on' ): ?>
                    <span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
                <?php endif;                        

                echo "<div class='auth-info'>"; 
                    if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                        echo "<span>";
                            if( get_theme_mod( 'author' ) =='on' ):
                            
                            // Author picture show
                            echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
                            esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                            <?php 
                            endif;

                            if ( get_theme_mod( 'category' ) == 'on' ):                                    
                                esc_html_e('in', 'eidmart');                                                
                                $terms = get_the_terms($id, 'download_category');
                                if (!empty($terms) && !is_wp_error($terms)) {
                                    //foreach ( $terms as $term ) {
                                    ?>
                                        <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                    <?php
                                //}
                                }
                            endif;                                    
                        echo "</span>";
                    endif; // End author and category

                    if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                        echo "<span class='bt-review'>";

                            $mreview = new \EDD_Reviews;
                            $rating = $mreview->average_rating(false);
                            echo $mreview->render_star_rating( $rating );
                            echo '('.$mreview->count_reviews().')';

                        echo "</span>";
                    } // End ratings check 
                    if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                        echo "<span>".esc_html( $sales )."</span>";
                    endif;
                    ?>
                </div>
            </div>        

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    ?>

    </div>

    <?php if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination padding-bottom-large">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

        echo '<div class="padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'photography_product','eidmart_photography_product' );


// Query by photography tag
function eidmart_photography_tag_quary() { 

    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
     
    // Paginationselection
    if(isset($_GET['page'])){
      $posts_per_page_eidmart = esc_sql($_GET['page']);
    }else{
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart, 
           'download_tag' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;
        

    } else {         
        
        
    if( is_post_type_archive( 'download' )):

    switch ( $wp_query->query['orderby'] ) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):

    ?>

    <div class="grid">
    <div class="grid-sizer"></div> 

    <?php

        $count = 0;
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;
            $count++;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() ); 
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            // Code for ad possition
            if( $count == get_theme_mod( 'ad_position_1' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_1' ); ?>
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_2' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_2' ); ?>    
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_3' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_3' ); ?>   
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_4' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_4' ); ?>  
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_5' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_5' ); ?>   
                </div>
            <?php } // End ad position ?>
            
            <div class="grid-item">
                <a href="<?php the_permalink(); ?>">
                    <div class="img-gradient">
                        <?php the_post_thumbnail(); ?>
                    </div>
                </a>

                <?php
                /**
                 * Discount percentage calculation
                 */
                if( $sale_price && edd_has_variable_prices( $id ) ):
                    $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                elseif( $single_sale_price ):
                    $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                else:
                    $discount_percent = 0;
                endif;

                /**
                 * Discount Percentage
                 */
                if( $discount_percent > 0 ):
                ?>
                <p class="discount-percentage">
                    <span><?php echo esc_html( $discount_percent ); ?>%</span>
                    <?php esc_html_e( 'Off', 'eidmart' ); ?>
                </p>
                <?php endif; 
                
                if( get_theme_mod( 'eid_love' ) == 'on' ): ?>
                    <div class="image-rating">
                        <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
                    </div>
                <?php endif; if ( get_theme_mod( 'eid_price_con' ) == 'on' ): ?>
                    <span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
                <?php endif;                        

                echo "<div class='auth-info'>"; 
                    if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                        echo "<span>";
                            if( get_theme_mod( 'author' ) =='on' ):
                            
                            // Author picture show
                            echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
                            esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                            <?php 
                            endif;

                            if ( get_theme_mod( 'category' ) == 'on' ):                                    
                                esc_html_e('in', 'eidmart');                                                
                                $terms = get_the_terms($id, 'download_category');
                                if (!empty($terms) && !is_wp_error($terms)) {
                                    //foreach ( $terms as $term ) {
                                    ?>
                                        <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                    <?php
                                //}
                                }
                            endif;                                    
                        echo "</span>";
                    endif; // End author and category

                    if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                        echo "<span class='bt-review'>";

                            $mreview = new \EDD_Reviews;
                            $rating = $mreview->average_rating(false);
                            echo $mreview->render_star_rating( $rating );
                            echo '('.$mreview->count_reviews().')';

                        echo "</span>";
                    } // End ratings check 
                    if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                        echo "<span>".esc_html( $sales )."</span>";
                    endif;
                    ?>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    ?>

    </div>

    <?php if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination padding-bottom-large">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

        echo '<div class="padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'photography_tag_quary','eidmart_photography_tag_quary' );


// Query by photography search
function eidmart_search_photography() {
/**
*  Custom query
*/  

global $wp_query;

$martax_query = array();
if( isset( $_GET['download_cat'] ) && $_GET['download_cat'] != 'all' ){
    $downloadcat = $_GET['download_cat'];
    $martax_query = array(
        array(
            'taxonomy' => 'download_category',
            'field'    => 'slug',
            'terms'    => $downloadcat
        )
    );
}

// Paginationselection
if(isset($_GET['page'])){
  $posts_per_page_eidmart = esc_sql($_GET['page']);
}else{
  $posts_per_page_eidmart = get_option( 'posts_per_page' );
}
$paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
if ( ! isset( $wp_query -> query['orderby'] ) ) {

    $args = array(
        's'         => get_search_query(),
        'orderby'   => 'date',
        'order'     => 'DESC',
        'post_type' => 'download',
        'posts_per_page'=> $posts_per_page_eidmart,
        'paged'     => $paged,
        'tax_query' => $martax_query
    );

} else {

    switch ($wp_query -> query['orderby']) {

        case 'newest': 
        $args = array( 
            's'         => get_search_query(),
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            's'         => get_search_query(),
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            's'         => get_search_query(),
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            's'         => get_search_query(),
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            's'         => get_search_query(),
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'tax_query' => $martax_query,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            's'         => get_search_query(),
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'tax_query' => $martax_query,
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;

    }
}

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):

    ?>

    <div class="grid">
    <div class="grid-sizer"></div> 

    <?php

        $count = 0;
        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;
            $count++;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;
            
            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            // Code for ad possition
            if( $count == get_theme_mod( 'ad_position_1' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_1' ); ?>
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_2' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_2' ); ?>    
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_3' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_3' ); ?>   
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_4' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_4' ); ?>  
                </div>
            <?php } else if( $count == get_theme_mod( 'ad_position_5' ) ){ ?>
                <div class="grid-item">
                    <?php echo get_theme_mod( 'ad_code_5' ); ?>   
                </div>
            <?php } // End ad position ?>

            <div class="grid-item">
                <a href="<?php the_permalink(); ?>">
                    <div class="img-gradient">
                        <?php the_post_thumbnail(); ?>
                    </div>
                </a>

                <?php
                /**
                 * Discount percentage calculation
                 */
                if( $sale_price && edd_has_variable_prices( $id ) ):
                    $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                elseif( $single_sale_price ):
                    $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                else:
                    $discount_percent = 0;
                endif;

                /**
                 * Discount Percentage
                 */
                if( $discount_percent > 0 ):
                ?>
                <p class="discount-percentage">
                    <span><?php echo esc_html( $discount_percent ); ?>%</span>
                    <?php esc_html_e( 'Off', 'eidmart' ); ?>
                </p>
                <?php endif; 
                
                if( get_theme_mod( 'eid_love' ) == 'on' ): ?>
                    <div class="image-rating">
                        <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
                    </div>
                <?php endif; if ( get_theme_mod( 'eid_price_con' ) == 'on' ): ?>
                    <span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
                <?php endif;                        

                echo "<div class='auth-info'>"; 
                    if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                        echo "<span>";
                            if( get_theme_mod( 'author' ) =='on' ):
                            
                            // Author picture show
                            echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
                            esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                            <?php 
                            endif;

                            if ( get_theme_mod( 'category' ) == 'on' ):                                    
                                esc_html_e('in', 'eidmart');                                                
                                $terms = get_the_terms($id, 'download_category');
                                if (!empty($terms) && !is_wp_error($terms)) {
                                    //foreach ( $terms as $term ) {
                                    ?>
                                        <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                    <?php
                                //}
                                }
                            endif;                                    
                        echo "</span>";
                    endif; // End author and category

                    if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                        echo "<span class='bt-review'>";

                            $mreview = new \EDD_Reviews;
                            $rating = $mreview->average_rating(false);
                            echo $mreview->render_star_rating( $rating );
                            echo '('.$mreview->count_reviews().')';

                        echo "</span>";
                    } // End ratings check 
                    if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                        echo "<span>".esc_html( $sales )."</span>";
                    endif;
                    ?>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    ?>

    </div>

    <?php if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination padding-bottom-large">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

    echo '<div class="padding-top-large padding-bottom-large">';
       echo get_template_part( 'template-parts/content','none' );
    echo '</div>';

    endif;  // End posts checking  

}
add_action( 'search_photography' ,'eidmart_search_photography' ); 


/*================================================================================
 * Graphicland *******************************************************************
 * ===============================================================================
 */

// Graphicland archive product
function eidmart_graphicland_product() { 
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    if ( !isset( $wp_query->query['orderby'] ) ) {

        if ( is_post_type_archive( 'download' ) ):

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'paged'          => $paged,
            );

        else:

            $args = array(
                'orderby'           => 'date',
                'order'             => 'DESC',
                'post_type'         => 'download',
                'posts_per_page'    => $posts_per_page_eidmart,
                'download_category' => $term->slug,
                'paged'             => $paged,
            );

        endif;

    } else {

        if ( is_post_type_archive( 'download' ) ):

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            }
            
            else :

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                    'post_type'         => 'download',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'paged'             => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'          => 'edd_feature_download',
                    'order'             => 'ASC',
                    'orderby'           => 'date',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'          => '_edd_download_sales',
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'        => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'          => 'edd_price',
                    'order'             => 'ASC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'          => 'edd_price',
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;

            }

        endif;

    }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):


        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;
            
            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-3' ) ); ?>">
                <div class="single-product">                  
                    <div class="graphicland-product-container">                               
                        <div class="product-content">
                            <a href="<?php the_permalink(); ?>" target="_blank">
                                <div class="content-overlay"></div>

                                <?php the_post_thumbnail( '', [ 'class' => 'graphicland-image' ] ); ?>
                            
                                <div class="overlay-center">
                                    <?php if( get_post_meta( $post->ID, 'preview_url',true ) ): ?>
                                    <div class="graphicland-live-preview">
                                        <?php if( get_post_meta( $post->ID, 'preview_url',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>"> <i class="las la-eye"></i> </a><?php endif; ?>
                                    </div>
                                    <?php endif; if ( get_theme_mod( 'eid_love' ) == 'on'): ?>
                                    <div class="graphicland-favourite-icon">
                                        <?php echo eidmart_get_likes_button( get_the_ID() ); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>                                
                            </a>
                        </div>
                    </div>
                
                    <?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
                        <span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
                    <?php endif; 

                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

                    <div class="product-details graphicland-product-details">
                        <div class="product-content">

                            <div class="product-details graphicland-product-details">                                       
                                <h3 class="content-title" ><a href="<?php the_permalink(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a> <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?></h3>
                            </div>
                            
                            <?php

                            // Collect user ID
                            $user_id = get_the_author_meta( 'ID' ); 
                            // Collect user name
                            $user_name = get_the_author_meta( 'user_login' , $user_id );

                            echo "<p>"; 
                                if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                                    echo "<span>";
                                        if( get_theme_mod( 'author' ) =='on' ):
                                        echo get_avatar( $user_id, 20, '' , '' , array( 'class' => array( 'vendor-avatar' ) ) ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
                                        
                                        <?php 
                                        endif;
                                        if( get_theme_mod( 'category' ) =='on' ):
                                        esc_html_e( 'in', 'eidmart' ); ?>
                                        <?php
                                            $terms = get_the_terms( $id , 'download_category' );
                                            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                                //foreach ( $terms as $term ) {
                                                    ?>
                                        
                                                    <a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

                                                    <?php                             
                                            // }
                                            }
                                        endif;
                                    echo "</span>";
                                endif; // End author and category

                                if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                                    echo "<span class='bt-review'>";

                                        $mreview = new \EDD_Reviews;
                                        $rating = $mreview->average_rating(false);
                                        echo $mreview->render_star_rating( $rating );
                                        echo '('.$mreview->count_reviews().')';

                                    echo "</span>";
                                } // End ratings check 
                                if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo "<span>".esc_html( $sales )."</span>";
                                endif;
                                ?>
                            </p>                                  

                        </div>
                    </div>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

        echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'graphicland_product','eidmart_graphicland_product' );


// Query graphicland for tag
function eidmart_graphicland_tag_quary() { 

    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
     
    // Paginationselection
    if(isset($_GET['page'])){
      $posts_per_page_eidmart = esc_sql($_GET['page']);
    }else{
      $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }
            
    if ( ! isset( $wp_query -> query['orderby'] ) ) { 

        if( is_post_type_archive( 'download' )):
            
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart,
           'paged' => $paged 
        ); 
        
        else:
        
        $args = array( 
           'orderby' => 'date', 
           'order' => 'DESC', 
           'post_type' => 'download', 
           'posts_per_page' => $posts_per_page_eidmart, 
           'download_tag' => $term->slug, 
           'paged' => $paged 
        );
        
        endif;        

    } else {
        
    if( is_post_type_archive( 'download' )):

    switch ( $wp_query->query['orderby'] ) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    } 
        
    else:        
    
    switch ($wp_query->query['orderby']) { 

        case 'newest': 
        $args = array( 
            'orderby' => 'date', 
            'order' => 'DESC', 
            'post_type' => 'download',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'paged' => $paged ); 
        break;
        case 'featured': 
        $args = array( 
            'meta_key'=>'edd_feature_download', 
            'order' => 'ASC', 
            'orderby' => 'date',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug,  
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'bestselling': 
        $args = array( 
            'meta_key'=>'_edd_download_sales', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'popular': 
        $args = array( 
            'meta_query'       => array(
                'relation'    => 'AND',
                array(
                    'key'          => '_edd_download_sales',
                ),
                array(
                    'key'          => 'eidmart_post_views_count',
                )
            ),
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break;
        case 'low_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'ASC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
        case 'high_price': 
        $args = array( 
            'meta_key'=>'edd_price', 
            'order' => 'DESC', 
            'orderby' => 'meta_value_num',
            'posts_per_page' => $posts_per_page_eidmart,
            'download_tag' => $term->slug, 
            'post_type' => 'download', 
            'paged' => $paged ); 
        break; 
            
    }        
        
    endif;
        
  }

  $temp = $wp_query; 
  $wp_query = null; 

  $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):

        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-3' ) ); ?>">
                <div class="single-product">                  
                    <div class="graphicland-product-container">                               
                        <div class="product-content">
                            <a href="<?php the_permalink(); ?>" target="_blank">
                                <div class="content-overlay"></div>

                                <?php the_post_thumbnail( '', [ 'class' => 'graphicland-image' ] ); ?>
                            
                                <div class="overlay-center">
                                    <?php if( get_post_meta( $post->ID, 'preview_url',true ) ): ?>
                                    <div class="graphicland-live-preview">
                                        <?php if( get_post_meta( $post->ID, 'preview_url',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>"> <i class="las la-eye"></i> </a><?php endif; ?>
                                    </div>
                                    <?php endif; if ( get_theme_mod( 'eid_love' ) == 'on'): ?>
                                    <div class="graphicland-favourite-icon">
                                        <?php echo eidmart_get_likes_button( get_the_ID() ); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>                                
                            </a>
                        </div>
                    </div>
                
                    <?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
                        <span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
                    <?php endif; 

                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

                    <div class="product-details graphicland-product-details">
                        <div class="product-content">

                            <div class="product-details graphicland-product-details">                                       
                                <h3 class="content-title" ><a href="<?php the_permalink(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a> <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?></h3>
                            </div>
                            
                            <?php

                            // Collect user ID
                            $user_id = get_the_author_meta( 'ID' ); 
                            // Collect user name
                            $user_name = get_the_author_meta( 'user_login' , $user_id );

                            echo "<p>"; 
                                if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                                    echo "<span>";
                                        if( get_theme_mod( 'author' ) =='on' ):
                                        echo get_avatar( $user_id, 20, '' , '' , array( 'class' => array( 'vendor-avatar' ) ) ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
                                        
                                        <?php 
                                        endif;
                                        if( get_theme_mod( 'category' ) =='on' ):
                                        esc_html_e( 'in', 'eidmart' ); ?>
                                        <?php
                                            $terms = get_the_terms( $id , 'download_category' );
                                            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                                //foreach ( $terms as $term ) {
                                                    ?>
                                        
                                                    <a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

                                                    <?php                             
                                            // }
                                            }
                                        endif;
                                    echo "</span>";
                                endif; // End author and category

                                if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                                    echo "<span class='bt-review'>";

                                        $mreview = new \EDD_Reviews;
                                        $rating = $mreview->average_rating(false);
                                        echo $mreview->render_star_rating( $rating );
                                        echo '('.$mreview->count_reviews().')';

                                    echo "</span>";
                                } // End ratings check 
                                if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo "<span>".esc_html( $sales )."</span>";
                                endif;
                                ?>
                            </p>                                  

                        </div>
                    </div>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

        echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'graphicland_tag_quary','eidmart_graphicland_tag_quary' );


// Query graphicland for search
function eidmart_search_graphicland() {
    /**
    *  Custom query
    */  
    global $wp_query;

    $martax_query = array();
    if( isset( $_GET['download_cat'] ) && $_GET['download_cat'] != 'all' ){
        $downloadcat = $_GET['download_cat'];
        $martax_query = array(
            array(
                'taxonomy' => 'download_category',
                'field'    => 'slug',
                'terms'    => $downloadcat
            )
        );
    }

    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;

    if ( ! isset( $wp_query -> query['orderby'] ) ) {

        $args = array(
            's'         => get_search_query(),
            'orderby'   => 'date',
            'order'     => 'DESC',
            'post_type' => 'download',
            'posts_per_page'=> $posts_per_page_eidmart,
            'paged'     => $paged,
            'tax_query' => $martax_query
        );

    } else {

        switch ( $wp_query->query['orderby'] ) {

        case 'newest':
            $args = array(
                's'              => get_search_query(),
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'paged'          => $paged );
            break;
        case 'featured':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_feature_download',
                'order'          => 'ASC',
                'orderby'        => 'date',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'bestselling':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => '_edd_download_sales',
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'popular':
            $args = array(
                's'              => get_search_query(),
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key' => '_edd_download_sales',
                    ),
                    array(
                        'key' => 'eidmart_post_views_count',
                    ),
                ),
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'low_price':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_price',
                'order'          => 'ASC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'high_price':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_price',
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;

        }
    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):

        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta( get_the_ID() );
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
            $sales = edd_get_download_sales_stats( get_the_ID() );
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-3' ) ); ?>">
                <div class="single-product">                  
                    <div class="graphicland-product-container">                               
                        <div class="product-content">
                            <a href="<?php the_permalink(); ?>" target="_blank">
                                <div class="content-overlay"></div>

                                <?php the_post_thumbnail( '', [ 'class' => 'graphicland-image' ] ); ?>
                            
                                <div class="overlay-center">
                                    <?php if( get_post_meta( $post->ID, 'preview_url',true ) ): ?>
                                    <div class="graphicland-live-preview">
                                        <?php if( get_post_meta( $post->ID, 'preview_url',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>"> <i class="las la-eye"></i> </a><?php endif; ?>
                                    </div>
                                    <?php endif; if ( get_theme_mod( 'eid_love' ) == 'on'): ?>
                                    <div class="graphicland-favourite-icon">
                                        <?php echo eidmart_get_likes_button( get_the_ID() ); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>                                
                            </a>
                        </div>
                    </div>
                
                    <?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
                        <span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
                    <?php endif; 

                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

                    <div class="product-details graphicland-product-details">
                        <div class="product-content">

                            <div class="product-details graphicland-product-details">                                       
                                <h3 class="content-title" ><a href="<?php the_permalink(); ?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a> <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?></h3>
                            </div>
                            
                            <?php

                            // Collect user ID
                            $user_id = get_the_author_meta( 'ID' ); 
                            // Collect user name
                            $user_name = get_the_author_meta( 'user_login' , $user_id );

                            echo "<p>"; 
                                if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                                    echo "<span>";
                                        if( get_theme_mod( 'author' ) =='on' ):
                                        echo get_avatar( $user_id, 20, '' , '' , array( 'class' => array( 'vendor-avatar' ) ) ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
                                        
                                        <?php 
                                        endif;
                                        if( get_theme_mod( 'category' ) =='on' ):
                                        esc_html_e( 'in', 'eidmart' ); ?>
                                        <?php
                                            $terms = get_the_terms( $id , 'download_category' );
                                            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                                //foreach ( $terms as $term ) {
                                                    ?>
                                        
                                                    <a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

                                                    <?php                             
                                            // }
                                            }
                                        endif;
                                    echo "</span>";
                                endif; // End author and category

                                if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                                    echo "<span class='bt-review'>";

                                        $mreview = new \EDD_Reviews;
                                        $rating = $mreview->average_rating(false);
                                        echo $mreview->render_star_rating( $rating );
                                        echo '('.$mreview->count_reviews().')';

                                    echo "</span>";
                                } // End ratings check 
                                if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo "<span>".esc_html( $sales )."</span>";
                                endif;
                                ?>
                            </p>                                  

                        </div>
                    </div>
                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination padding-bottom-large">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

    echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
       echo get_template_part( 'template-parts/content','none' );
    echo '</div>';

    endif;  // End posts checking  

}
add_action( 'search_graphicland' ,'eidmart_search_graphicland' ); 


/*================================================================================
 * Audio ************************************************************************
 * ===============================================================================
 */

// Audio archive product
function eidmart_audio_product() { 
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    if ( !isset( $wp_query->query['orderby'] ) ) {

        if ( is_post_type_archive( 'download' ) ):

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'paged'          => $paged,
            );

        else:

            $args = array(
                'orderby'           => 'date',
                'order'             => 'DESC',
                'post_type'         => 'download',
                'posts_per_page'    => $posts_per_page_eidmart,
                'download_category' => $term->slug,
                'paged'             => $paged,
            );

        endif;

    } else {

        if ( is_post_type_archive( 'download' ) ):

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            }
            
            else :

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                    'post_type'         => 'download',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'paged'             => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'          => 'edd_feature_download',
                    'order'             => 'ASC',
                    'orderby'           => 'date',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'          => '_edd_download_sales',
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'        => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'          => 'edd_price',
                    'order'             => 'ASC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'          => 'edd_price',
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;

            }

        endif;

    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):


        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta(get_the_ID());
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : __('Free', 'eidmart');
            $external_url = isset($meta['purchase_url'][0]) ? $meta['purchase_url'][0] : '';

            $sales = edd_get_download_sales_stats(get_the_ID());
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            $mp3_url = isset($meta['mp3_url'][0]) ? $meta['mp3_url'][0] : '';
            $mp3_artist = isset($meta['artist'][0]) ? $meta['artist'][0] : '';

            // Collect downloads tearms
            $terms = get_the_terms($post->ID, 'download_category');

            $mp3_title = html_entity_decode(get_the_title()) . uniqid();
            $mp3_title = preg_replace('/[^A-Za-z0-9\-]/', '', $mp3_title);

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-2' ) ); ?>">
                <div class="single-product">
                    <a href="javascript:void(0);" class="album-poster <?php echo esc_attr($mp3_title); ?>" data-uniqid="<?php echo esc_attr($mp3_title); ?>" data-switch="0" data-price='<?php if ($edd_price): echo $item_price; else: echo __esc_html('Free', 'eidmart'); endif; ?>' data-title='<?php the_title();?>' data-artist="<?php echo esc_attr($mp3_artist); ?>" data-mp3="<?php echo esc_attr($mp3_url); ?>" data-pid="<?php echo esc_attr($id); ?>" data-cover="<?php the_post_thumbnail_url();?>">
                        <?php the_post_thumbnail();?>
                        <div class="player-icon">
                            <i class="las la-play"></i>
                            <i class="las la-pause"></i>
                        </div>
                    </a>

                    <?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
                        <span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
                    <?php endif; 

                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

                    <div class="product-content">
                        <div class="audio-title">
                            <a href="<?php the_permalink();?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a>
                        </div>
                        <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><div class="price"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart');endif;?></div><?php endif; ?>
                    </div>                            

                    <?php

                    echo "<div class='auth-info'>"; 
                        if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                            echo "<span>";
                                if( get_theme_mod( 'author' ) =='on' ):
                                
                                // Author picture show
                                //echo get_avatar( get_the_author_meta('ID'), '40', '' , '' , array( 'class' => array( 'vendor-pic' ) ) );
                                esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                                <?php 
                                endif;
                                if( get_theme_mod( 'category' ) =='on' ):
                                    esc_html_e( 'in', 'eidmart' ); 
                                    $terms = get_the_terms($id, 'download_category');
                                    if (!empty($terms) && !is_wp_error($terms)) { ?>
                                        <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                    <?php
                                    }
                                endif;
                            echo "</span>";
                        endif; // End author and category

                        if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                            echo "<span class='bt-review'>";

                                $mreview = new \EDD_Reviews;
                                $rating = $mreview->average_rating(false);
                                echo $mreview->render_star_rating( $rating );
                                echo '('.$mreview->count_reviews().')';

                            echo "</span>";
                        } // End ratings check 
                        if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                            echo "<span>".esc_html( $sales )."</span>";
                        endif;
                        ?>
                    </div>

                </div>
            </div>

        <?php

        endwhile;   // End while loop 
        wp_reset_postdata();  // Reset post data

    if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

        echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'audio_product','eidmart_audio_product' );

// Query Audio for search
function eidmart_search_audio() {
    /**
    *  Custom query
    */  
    global $wp_query;

    $martax_query = array();
    if( isset( $_GET['download_cat'] ) && $_GET['download_cat'] != 'all' ){
        $downloadcat = $_GET['download_cat'];
        $martax_query = array(
            array(
                'taxonomy' => 'download_category',
                'field'    => 'slug',
                'terms'    => $downloadcat
            )
        );
    }

    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;

    if ( ! isset( $wp_query -> query['orderby'] ) ) {

        $args = array(
            's'         => get_search_query(),
            'orderby'   => 'date',
            'order'     => 'DESC',
            'post_type' => 'download',
            'posts_per_page'=> $posts_per_page_eidmart,
            'paged'     => $paged,
            'tax_query' => $martax_query
        );

    } else {

        switch ( $wp_query->query['orderby'] ) {

        case 'newest':
            $args = array(
                's'              => get_search_query(),
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'paged'          => $paged );
            break;
        case 'featured':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_feature_download',
                'order'          => 'ASC',
                'orderby'        => 'date',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'bestselling':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => '_edd_download_sales',
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'popular':
            $args = array(
                's'              => get_search_query(),
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key' => '_edd_download_sales',
                    ),
                    array(
                        'key' => 'eidmart_post_views_count',
                    ),
                ),
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'low_price':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_price',
                'order'          => 'ASC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'high_price':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_price',
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;

        }
    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):

        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta(get_the_ID());
            $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : __('Free', 'eidmart');
            $external_url = isset($meta['purchase_url'][0]) ? $meta['purchase_url'][0] : '';

            $sales = edd_get_download_sales_stats(get_the_ID());
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            $mp3_url = isset($meta['mp3_url'][0]) ? $meta['mp3_url'][0] : '';
            $mp3_artist = isset($meta['artist'][0]) ? $meta['artist'][0] : '';

            // Collect downloads tearms
            $terms = get_the_terms($post->ID, 'download_category');

            $mp3_title = html_entity_decode(get_the_title()) . uniqid();
            $mp3_title = preg_replace('/[^A-Za-z0-9\-]/', '', $mp3_title);

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-2' ) ); ?>">
                <div class="single-product">
                    <a href="javascript:void(0);" class="album-poster <?php echo esc_attr($mp3_title); ?>" data-uniqid="<?php echo esc_attr($mp3_title); ?>" data-switch="0" data-price='<?php if ($edd_price): echo $item_price; else: echo __esc_html('Free', 'eidmart'); endif; ?>' data-title='<?php the_title();?>' data-artist="<?php echo esc_attr($mp3_artist); ?>" data-mp3="<?php echo esc_attr($mp3_url); ?>" data-pid="<?php echo esc_attr($id); ?>" data-cover="<?php the_post_thumbnail_url();?>">
                        <?php the_post_thumbnail();?>
                        <div class="player-icon">
                            <i class="las la-play"></i>
                            <i class="las la-pause"></i>
                        </div>
                    </a>

                    <?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
                        <span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
                    <?php endif; 

                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

                    <div class="product-content">
                        <div class="audio-title">
                            <a href="<?php the_permalink();?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a>
                        </div>
                        <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><div class="price"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart');endif;?></div><?php endif; ?>
                    </div>                            

                    <?php

                    echo "<div class='auth-info'>"; 
                        if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                            echo "<span>";
                                if( get_theme_mod( 'author' ) =='on' ):
                                
                                // Author picture show
                                //echo get_avatar( get_the_author_meta('ID'), '40', '' , '' , array( 'class' => array( 'vendor-pic' ) ) );
                                esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                                <?php 
                                endif;
                                if( get_theme_mod( 'category' ) =='on' ):
                                    esc_html_e( 'in', 'eidmart' ); 
                                    $terms = get_the_terms($id, 'download_category');
                                    if (!empty($terms) && !is_wp_error($terms)) { ?>
                                        <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                    <?php
                                    }
                                endif;
                            echo "</span>";
                        endif; // End author and category

                        if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                            echo "<span class='bt-review'>";

                                $mreview = new \EDD_Reviews;
                                $rating = $mreview->average_rating(false);
                                echo $mreview->render_star_rating( $rating );
                                echo '('.$mreview->count_reviews().')';

                            echo "</span>";
                        } // End ratings check 
                        if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                            echo "<span>".esc_html( $sales )."</span>";
                        endif;
                        ?>
                    </div>

                </div>
            </div>

        <?php

    endwhile;   // End while loop 
    wp_reset_postdata();  // Reset post data

    if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination padding-bottom-large">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

    echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
       echo get_template_part( 'template-parts/content','none' );
    echo '</div>';

    endif;  // End posts checking  

}
add_action( 'search_audio' ,'eidmart_search_audio' ); 

// Query Audio for tag
function eidmart_audio_tag_quary() { 

    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
     
    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    if ( !isset( $wp_query->query['orderby'] ) ) {

        if ( is_post_type_archive( 'download' ) ):

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'paged'          => $paged,
            );

        else:

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'download_tag'   => $term->slug,
                'paged'          => $paged,
            );

        endif;

    } else {

        if ( is_post_type_archive( 'download' ) ):

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            } else :

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            }

        endif;

    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ):


        while ( $wp_query->have_posts() ) : 
            $wp_query -> the_post();

            global $post;

            $id = get_the_ID();
            $meta = get_post_meta(get_the_ID());
            $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : __('Free', 'eidmart');
            $external_url = isset($meta['purchase_url'][0]) ? $meta['purchase_url'][0] : '';

            $sales = edd_get_download_sales_stats(get_the_ID());
            $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

            $mp3_url = isset($meta['mp3_url'][0]) ? $meta['mp3_url'][0] : '';
            $mp3_artist = isset($meta['artist'][0]) ? $meta['artist'][0] : '';

            // Collect downloads tearms
            $terms = get_the_terms($post->ID, 'download_category');

            $mp3_title = html_entity_decode(get_the_title()) . uniqid();
            $mp3_title = preg_replace('/[^A-Za-z0-9\-]/', '', $mp3_title);

            /**
             * Get all variable pricing
             */
            $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
            
            /**
             * Get checked item
             */
            $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
            $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
            $price_checked = isset( $price_checked ) ? $price_checked: 0;

            // Variables pricing price
            $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
            $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

            // Pricing options price
            $single_regular_price = get_post_meta( $id, 'edd_price', true );
            $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

            /**
             * Get the selected price of variable item
             */
            if( 1 != $checked_key ): 
                $item_price = edd_price( $id, false, $price_checked ); 
            else: 
                $item_price = edd_price( $id, false, '' ); 
            endif;
            
            ?>

            <div class="<?php echo esc_attr( get_theme_mod( 'course_grid', 'col-md-2' ) ); ?>">
                <div class="single-product">
                    <a href="javascript:void(0);" class="album-poster <?php echo esc_attr($mp3_title); ?>" data-uniqid="<?php echo esc_attr($mp3_title); ?>" data-switch="0" data-price='<?php if ($edd_price): echo $item_price; else: echo __esc_html('Free', 'eidmart'); endif; ?>' data-title='<?php the_title();?>' data-artist="<?php echo esc_attr($mp3_artist); ?>" data-mp3="<?php echo esc_attr($mp3_url); ?>" data-pid="<?php echo esc_attr($id); ?>" data-cover="<?php the_post_thumbnail_url();?>">
                        <?php the_post_thumbnail();?>
                        <div class="player-icon">
                            <i class="las la-play"></i>
                            <i class="las la-pause"></i>
                        </div>
                    </a>

                    <?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
                        <span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
                    <?php endif; 

                    /**
                     * Discount percentage calculation
                     */
                    if( $sale_price && edd_has_variable_prices( $id ) ):
                        $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                    elseif( $single_sale_price ):
                        $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                    else:
                        $discount_percent = 0;
                    endif;

                    /**
                     * Discount Percentage
                     */
                    if( $discount_percent > 0 ):
                    ?>
                    <p class="discount-percentage">
                        <span><?php echo esc_html( $discount_percent ); ?>%</span>
                        <?php esc_html_e( 'Off', 'eidmart' ); ?>
                    </p>
                    <?php endif; ?>

                    <div class="product-content">
                        <div class="audio-title">
                            <a href="<?php the_permalink();?>"><?php echo eidmart_excerpt_char_course_title( get_theme_mod( 'max_char', '30' ) ); ?></a>
                        </div>
                        <?php if( get_theme_mod( 'eid_price_con' ) == 'on' ): ?><div class="price"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart');endif;?></div><?php endif; ?>
                    </div>                            

                    <?php

                    echo "<div class='auth-info'>"; 
                        if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                            echo "<span>";
                                if( get_theme_mod( 'author' ) =='on' ):
                                
                                // Author picture show
                                //echo get_avatar( get_the_author_meta('ID'), '40', '' , '' , array( 'class' => array( 'vendor-pic' ) ) );
                                esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                                <?php 
                                endif;
                                if( get_theme_mod( 'category' ) =='on' ):
                                    esc_html_e( 'in', 'eidmart' ); 
                                    $terms = get_the_terms($id, 'download_category');
                                    if (!empty($terms) && !is_wp_error($terms)) { ?>
                                        <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                    <?php
                                    }
                                endif;
                            echo "</span>";
                        endif; // End author and category

                        if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                            echo "<span class='bt-review'>";

                                $mreview = new \EDD_Reviews;
                                $rating = $mreview->average_rating(false);
                                echo $mreview->render_star_rating( $rating );
                                echo '('.$mreview->count_reviews().')';

                            echo "</span>";
                        } // End ratings check 
                        if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                            echo "<span>".esc_html( $sales )."</span>";
                        endif;
                        ?>
                    </div>

                </div>
            </div>

        <?php

        endwhile;   // End while loop 
        wp_reset_postdata();  // Reset post data


        if( paginate_links() ){ ?>               

        <div class="col-md-12">
            <div class="course-pagination">
                <ul class="pagination">
                    <li>
                        <?php

                        global $wp_query;
                
                        $big = 999999999; // need an unlikely integer

                        echo paginate_links( array(                         
                            
                            'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                            'total'        => $wp_query->max_num_pages,
                            'current'      => max( 1, get_query_var( 'paged' ) ),
                            'format'       => '?paged=%#%',
                            'show_all'     => false,
                            'type'         => 'plain',
                            'end_size'     => 2,
                            'mid_size'     => 1,
                            'prev_next'    => true,
                            'prev_text' => '<i class="fa fa-angle-left"></i>',
                            'next_text' => '<i class="fa fa-angle-right"></i>',
                            'add_args'     => false,
                            'add_fragment' => ''

                        ) );

                        ?>
                    </li>
                </ul>
            </div>
        </div>

        <?php

        } else {

            echo '<div class="padding-bottom-large"></div>';

        }

    else:   // If no post

        echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'audio_tag_quary','eidmart_audio_tag_quary' );


/*================================================================================
 * Video ************************************************************************
 * ===============================================================================
 */

// Video archive product
function eidmart_video_product() { 
                                
    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
        
    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    if ( !isset( $wp_query->query['orderby'] ) ) {

        if ( is_post_type_archive( 'download' ) ):

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'paged'          => $paged,
            );

        else:

            $args = array(
                'orderby'           => 'date',
                'order'             => 'DESC',
                'post_type'         => 'download',
                'posts_per_page'    => $posts_per_page_eidmart,
                'download_category' => $term->slug,
                'paged'             => $paged,
            );

        endif;

    } else {

        if ( is_post_type_archive( 'download' ) ):

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            }
            
            else :

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                    'post_type'         => 'download',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'paged'             => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'          => 'edd_feature_download',
                    'order'             => 'ASC',
                    'orderby'           => 'date',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'          => '_edd_download_sales',
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'        => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'          => 'edd_price',
                    'order'             => 'ASC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'          => 'edd_price',
                    'order'             => 'DESC',
                    'orderby'           => 'meta_value_num',
                    'posts_per_page'    => $posts_per_page_eidmart,
                    'download_category' => $term->slug,
                    'post_type'         => 'download',
                    'paged'             => $paged );
                break;

            }

        endif;

    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ): ?>

        <div class="col-md-12">
            <div class="grid">
                <div class="grid-sizer"></div> 

                <?php

                while ( $wp_query->have_posts() ) : 
                    $wp_query -> the_post();

                    global $post;

                    $id = get_the_ID();
                    $meta = get_post_meta(get_the_ID());
                    $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
                    $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';

                    $sales = edd_get_download_sales_stats(get_the_ID());
                    $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

                    $internal_url = isset($meta['mp4_url'][0]) ? $meta['mp4_url'][0] : '';
                    $external_url = isset($meta['external_url'][0]) ? $meta['external_url'][0] : '';

                    $video_url = !empty( $external_url ) ? $external_url : $internal_url;
                    $video_type = isset($meta['video_type'][0]) ? $meta['video_type'][0] : 1;

                    // Collect downloads tearms
                    $terms = get_the_terms($post->ID, 'download_category');

                    /**
                     * Get all variable pricing
                     */
                    $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
                    
                    /**
                     * Get checked item
                     */
                    $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
                    $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
                    $price_checked = isset( $price_checked ) ? $price_checked: 0;

                    // Variables pricing price
                    $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
                    $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

                    // Pricing options price
                    $single_regular_price = get_post_meta( $id, 'edd_price', true );
                    $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

                    /**
                     * Get the selected price of variable item
                     */
                    if( 1 != $checked_key ): 
                        $item_price = edd_price( $id, false, $price_checked ); 
                    else: 
                        $item_price = edd_price( $id, false, '' ); 
                    endif;
                    
                    ?>                    

                    <div class="grid-item photography-filter-item">
                        <div class="load-more">
                        
                            <a class="photography-item_url" href="<?php the_permalink();?>">
                            <?php if( $video_url ): 
                                
                                // Check video type
                                if( $video_type == 1 ){ ?>

                                    <video <?php if( get_theme_mod( 'video_sound' ) == 1 ): echo "muted"; endif; ?> class="hvrbox-layer_bottom video-control" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
                                        <source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
                                        <?php esc_html_e( 'Your browser does not support HTML5 video.', 'eidmart' ); ?>
                                    </video>

                                <?php } else { ?>

                                    <!-- 16:9 aspect ratio -->
                                    <div class="embed-responsive embed-responsive-16by9" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo esc_attr( $video_url ); ?>?rel=0&controls=0&modestbranding=1&showinfo=0" allowfullscreen frameborder="0""></iframe>
                                    </div>

                                <?php } endif; ?>
                            </a>

                            <?php
                            /**
                             * Discount percentage calculation
                             */
                            if( $sale_price && edd_has_variable_prices( $id ) ):
                                $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                            elseif( $single_sale_price ):
                                $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                            else:
                                $discount_percent = 0;
                            endif;

                            /**
                             * Discount Percentage
                             */
                            if( $discount_percent > 0 ):
                            ?>
                            <p class="discount-percentage">
                                <span><?php echo esc_html( $discount_percent ); ?>%</span>
                                <?php esc_html_e( 'Off', 'eidmart' ); ?>
                            </p>
                            <?php endif; 
                            
                            if ( get_theme_mod( 'eid_love' ) == 'on' ): ?>
                                <div class="image-rating">
                                    <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
                                </div>
                            <?php endif; if ( get_theme_mod( 'eid_price_con' ) == 'on' ): ?>
                                <span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
                            <?php endif;

                            echo "<div class='auth-info'>"; 
                                if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                                    echo "<span>";
                                        if( get_theme_mod( 'author' ) =='on' ):
                                        
                                        // Author picture show
                                        echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
                                        esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                                        <?php 
                                        endif;

                                        if ( get_theme_mod( 'category' ) == 'on' ):                                    
                                            esc_html_e('in', 'eidmart');                                                
                                            $terms = get_the_terms($id, 'download_category');
                                            if (!empty($terms) && !is_wp_error($terms)) {
                                                //foreach ( $terms as $term ) {
                                                ?>
                                                    <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                                    <?php if( $video_type == 2 && get_theme_mod( 'youtube_btn' ) ): ?>
                                                    <a class="btn-hover color-11" href="<?php the_permalink(); ?>"><?php echo esc_html( get_theme_mod( 'youtube_btn', 'Read more' ) ); ?></a>
                                                <?php
                                            endif; // End video type checking
                                            //}
                                            }
                                        endif;                                    
                                    echo "</span>";
                                endif; // End author and category

                                if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                                    echo "<span class='bt-review'>";

                                        $mreview = new \EDD_Reviews;
                                        $rating = $mreview->average_rating(false);
                                        echo $mreview->render_star_rating( $rating );
                                        echo '('.$mreview->count_reviews().')';

                                    echo "</span>";
                                } // End ratings check 
                                if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo "<span>".esc_html( $sales )."</span>";
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>

                <?php

                endwhile;   // End while loop 
                wp_reset_postdata();  // Reset post data ?>

            </div>
        </div>
    
    <?php if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', html_entity_decode( get_pagenum_link( 999999999 ) )),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

        echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'video_product','eidmart_video_product' );


// Query Video for search
function eidmart_search_video() {
    /**
    *  Custom query
    */  
    global $wp_query;

    $martax_query = array();
    if( isset( $_GET['download_cat'] ) && $_GET['download_cat'] != 'all' ){
        $downloadcat = $_GET['download_cat'];
        $martax_query = array(
            array(
                'taxonomy' => 'download_category',
                'field'    => 'slug',
                'terms'    => $downloadcat
            )
        );
    }

    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;

    if ( ! isset( $wp_query -> query['orderby'] ) ) {

        $args = array(
            's'         => get_search_query(),
            'orderby'   => 'date',
            'order'     => 'DESC',
            'post_type' => 'download',
            'posts_per_page'=> $posts_per_page_eidmart,
            'paged'     => $paged,
            'tax_query' => $martax_query
        );

    } else {

        switch ( $wp_query->query['orderby'] ) {

        case 'newest':
            $args = array(
                's'              => get_search_query(),
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'paged'          => $paged );
            break;
        case 'featured':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_feature_download',
                'order'          => 'ASC',
                'orderby'        => 'date',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'bestselling':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => '_edd_download_sales',
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'popular':
            $args = array(
                's'              => get_search_query(),
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key' => '_edd_download_sales',
                    ),
                    array(
                        'key' => 'eidmart_post_views_count',
                    ),
                ),
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'low_price':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_price',
                'order'          => 'ASC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;
        case 'high_price':
            $args = array(
                's'              => get_search_query(),
                'meta_key'       => 'edd_price',
                'order'          => 'DESC',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $posts_per_page_eidmart,
                'tax_query'      => $martax_query,
                'post_type'      => 'download',
                'paged'          => $paged );
            break;

        }
    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ): ?>

        <div class="col-md-12">
            <div class="grid">
            <div class="grid-sizer"></div>

            <?php

            while ( $wp_query->have_posts() ) : 
                $wp_query -> the_post();

                global $post;

                $id = get_the_ID();
                $meta = get_post_meta(get_the_ID());
                $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
                $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';

                $sales = edd_get_download_sales_stats(get_the_ID());
                $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

                $internal_url = isset($meta['mp4_url'][0]) ? $meta['mp4_url'][0] : '';
                $external_url = isset($meta['external_url'][0]) ? $meta['external_url'][0] : '';

                $video_url = !empty( $external_url ) ? $external_url : $internal_url;
                $video_type = isset($meta['video_type'][0]) ? $meta['video_type'][0] : 1;

                // Collect downloads tearms
                $terms = get_the_terms($post->ID, 'download_category');

                /**
                 * Get all variable pricing
                 */
                $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
                
                /**
                 * Get checked item
                 */
                $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
                $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
                $price_checked = isset( $price_checked ) ? $price_checked: 0;

                // Variables pricing price
                $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
                $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

                // Pricing options price
                $single_regular_price = get_post_meta( $id, 'edd_price', true );
                $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

                /**
                 * Get the selected price of variable item
                 */
                if( 1 != $checked_key ): 
                    $item_price = edd_price( $id, false, $price_checked ); 
                else: 
                    $item_price = edd_price( $id, false, '' ); 
                endif;
                
                ?>                    

                <div class="grid-item photography-filter-item">
                    <div class="load-more">
                    
                        <a class="photography-item_url" href="<?php the_permalink();?>">
                        <?php if( $video_url ): 
                            
                            // Check video type
                            if( $video_type == 1 ){ ?>

                                <video <?php if( get_theme_mod( 'video_sound' ) == 1 ): echo "muted"; endif; ?> class="hvrbox-layer_bottom video-control" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
                                    <source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
                                    <?php esc_html_e( 'Your browser does not support HTML5 video.', 'eidmart' ); ?>
                                </video>

                            <?php } else { ?>

                                <!-- 16:9 aspect ratio -->
                                <div class="embed-responsive embed-responsive-16by9" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo esc_attr( $video_url ); ?>?rel=0&controls=0&modestbranding=1&showinfo=0" allowfullscreen frameborder="0""></iframe>
                                </div>

                            <?php } endif; ?>
                        </a>

                        <?php
                        /**
                         * Discount percentage calculation
                         */
                        if( $sale_price && edd_has_variable_prices( $id ) ):
                            $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                        elseif( $single_sale_price ):
                            $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                        else:
                            $discount_percent = 0;
                        endif;

                        /**
                         * Discount Percentage
                         */
                        if( $discount_percent > 0 ):
                        ?>
                        <p class="discount-percentage">
                            <span><?php echo esc_html( $discount_percent ); ?>%</span>
                            <?php esc_html_e( 'Off', 'eidmart' ); ?>
                        </p>
                        <?php endif; 
                        
                        if ( get_theme_mod( 'eid_love' ) == 'on' ): ?>
                            <div class="image-rating">
                                <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
                            </div>
                        <?php endif; if ( get_theme_mod( 'eid_price_con' ) == 'on' ): ?>
                            <span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
                        <?php endif;

                        echo "<div class='auth-info'>"; 
                            if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                                echo "<span>";
                                    if( get_theme_mod( 'author' ) =='on' ):
                                    
                                    // Author picture show
                                    echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
                                    esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                                    <?php 
                                    endif;

                                    if ( get_theme_mod( 'category' ) == 'on' ):                                    
                                        esc_html_e('in', 'eidmart');                                                
                                        $terms = get_the_terms($id, 'download_category');
                                        if (!empty($terms) && !is_wp_error($terms)) {
                                            //foreach ( $terms as $term ) {
                                            ?>
                                                <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                                <?php if( $video_type == 2 && get_theme_mod( 'youtube_btn' ) ): ?>
                                                <a class="btn-hover color-11" href="<?php the_permalink(); ?>"><?php echo esc_html( get_theme_mod( 'youtube_btn', 'Read more' ) ); ?></a>
                                            <?php
                                        endif; // End video type checking
                                        //}
                                        }
                                    endif;                                    
                                echo "</span>";
                            endif; // End author and category

                            if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                                echo "<span class='bt-review'>";

                                    $mreview = new \EDD_Reviews;
                                    $rating = $mreview->average_rating(false);
                                    echo $mreview->render_star_rating( $rating );
                                    echo '('.$mreview->count_reviews().')';

                                echo "</span>";
                            } // End ratings check 
                            if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                echo "<span>".esc_html( $sales )."</span>";
                            endif;
                            ?>
                        </div>
                    </div>
                </div>

            <?php

            endwhile;   // End while loop 
            wp_reset_postdata();  // Reset post data ?>

            </div>
        </div>

    <?php if( paginate_links() ){ ?>               

    <div class="col-md-12">
        <div class="course-pagination padding-bottom-large">
            <ul class="pagination">
                <li>
                    <?php

                    global $wp_query;
            
                    $big = 999999999; // need an unlikely integer

                    echo paginate_links( array(                         
                        
                        'base'         => str_replace( 999999999, '%#%', html_entity_decode( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $wp_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'add_args'     => false,
                        'add_fragment' => ''

                    ) );

                    ?>
                </li>
            </ul>
        </div>
    </div>

    <?php

    } else {

        echo '<div class="padding-bottom-large"></div>';

    }

    else:   // If no post

    echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
       echo get_template_part( 'template-parts/content','none' );
    echo '</div>';

    endif;  // End posts checking  

}
add_action( 'search_video' ,'eidmart_search_video' ); 

// Query Video for tag
function eidmart_video_tag_quary() { 

    global $wp_query;

    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
    $paged = ( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
     
    // Paginationselection
    if ( isset( $_GET['page'] ) ) {
        $posts_per_page_eidmart = esc_sql( $_GET['page'] );
    } else {
        $posts_per_page_eidmart = get_option( 'posts_per_page' );
    }

    if ( !isset( $wp_query->query['orderby'] ) ) {

        if ( is_post_type_archive( 'download' ) ):

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'paged'          => $paged,
            );

        else:

            $args = array(
                'orderby'        => 'date',
                'order'          => 'DESC',
                'post_type'      => 'download',
                'posts_per_page' => $posts_per_page_eidmart,
                'download_tag'   => $term->slug,
                'paged'          => $paged,
            );

        endif;

    } else {

        if ( is_post_type_archive( 'download' ) ):

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            } else :

            switch ( $wp_query->query['orderby'] ) {

            case 'newest':
                $args = array(
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'post_type'      => 'download',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'paged'          => $paged );
                break;
            case 'featured':
                $args = array(
                    'meta_key'       => 'edd_feature_download',
                    'order'          => 'ASC',
                    'orderby'        => 'date',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'bestselling':
                $args = array(
                    'meta_key'       => '_edd_download_sales',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'popular':
                $args = array(
                    'meta_query'     => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_edd_download_sales',
                        ),
                        array(
                            'key' => 'eidmart_post_views_count',
                        ),
                    ),
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'low_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'ASC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;
            case 'high_price':
                $args = array(
                    'meta_key'       => 'edd_price',
                    'order'          => 'DESC',
                    'orderby'        => 'meta_value_num',
                    'posts_per_page' => $posts_per_page_eidmart,
                    'download_tag'   => $term->slug,
                    'post_type'      => 'download',
                    'paged'          => $paged );
                break;

            }

        endif;

    }

    $temp = $wp_query; 
    $wp_query = null; 

    $wp_query = new WP_Query(); 

    $wp_query -> query( $args ); 

    if( $wp_query->have_posts() ): ?>

        <div class="col-md-12">
            <div class="grid">
                <div class="grid-sizer"></div> 

                <?php

                while ( $wp_query->have_posts() ) : 
                    $wp_query -> the_post();

                    global $post;

                    $id = get_the_ID();
                    $meta = get_post_meta(get_the_ID());
                    $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
                    $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';

                    $sales = edd_get_download_sales_stats(get_the_ID());
                    $sales = $sales > 1 ? $sales . __(' sales', 'eidmart') : $sales . __(' sale', 'eidmart');

                    $internal_url = isset($meta['mp4_url'][0]) ? $meta['mp4_url'][0] : '';
                    $external_url = isset($meta['external_url'][0]) ? $meta['external_url'][0] : '';

                    $video_url = !empty( $external_url ) ? $external_url : $internal_url;
                    $video_type = isset($meta['video_type'][0]) ? $meta['video_type'][0] : 1;

                    // Collect downloads tearms
                    $terms = get_the_terms($post->ID, 'download_category');

                    /**
                     * Get all variable pricing
                     */
                    $prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
                    
                    /**
                     * Get checked item
                     */
                    $checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
                    $price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
                    $price_checked = isset( $price_checked ) ? $price_checked: 0;

                    // Variables pricing price
                    $regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
                    $sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

                    // Pricing options price
                    $single_regular_price = get_post_meta( $id, 'edd_price', true );
                    $single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

                    /**
                     * Get the selected price of variable item
                     */
                    if( 1 != $checked_key ): 
                        $item_price = edd_price( $id, false, $price_checked ); 
                    else: 
                        $item_price = edd_price( $id, false, '' ); 
                    endif;
                    
                    ?>                    

                    <div class="grid-item photography-filter-item">
                        <div class="load-more">
                        
                            <a class="photography-item_url" href="<?php the_permalink();?>">
                            <?php if( $video_url ): 
                                
                                // Check video type
                                if( $video_type == 1 ){ ?>

                                    <video <?php if( get_theme_mod( 'video_sound' ) == 1 ): echo "muted"; endif; ?> class="hvrbox-layer_bottom video-control" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
                                        <source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
                                        <?php esc_html_e( 'Your browser does not support HTML5 video.', 'eidmart' ); ?>
                                    </video>

                                <?php } else { ?>

                                    <!-- 16:9 aspect ratio -->
                                    <div class="embed-responsive embed-responsive-16by9" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo esc_attr( $video_url ); ?>?rel=0&controls=0&modestbranding=1&showinfo=0" allowfullscreen frameborder="0""></iframe>
                                    </div>

                                <?php } endif; ?>
                            </a>

                            <?php
                            /**
                             * Discount percentage calculation
                             */
                            if( $sale_price && edd_has_variable_prices( $id ) ):
                                $discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
                            elseif( $single_sale_price ):
                                $discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
                            else:
                                $discount_percent = 0;
                            endif;

                            /**
                             * Discount Percentage
                             */
                            if( $discount_percent > 0 ):
                            ?>
                            <p class="discount-percentage">
                                <span><?php echo esc_html( $discount_percent ); ?>%</span>
                                <?php esc_html_e( 'Off', 'eidmart' ); ?>
                            </p>
                            <?php endif; 
                            
                            if ( get_theme_mod( 'eid_love' ) == 'on' ): ?>
                                <div class="image-rating">
                                    <span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
                                </div>
                            <?php endif; if ( get_theme_mod( 'eid_price_con' ) == 'on' ): ?>
                                <span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
                            <?php endif;

                            echo "<div class='auth-info'>"; 
                                if( get_theme_mod( 'author' ) =='on' || get_theme_mod( 'category' ) =='on' ):                                            
                                    echo "<span>";
                                        if( get_theme_mod( 'author' ) =='on' ):
                                        
                                        // Author picture show
                                        echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
                                        esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

                                        <?php 
                                        endif;

                                        if ( get_theme_mod( 'category' ) == 'on' ):                                    
                                            esc_html_e('in', 'eidmart');                                                
                                            $terms = get_the_terms($id, 'download_category');
                                            if (!empty($terms) && !is_wp_error($terms)) {
                                                //foreach ( $terms as $term ) {
                                                ?>
                                                    <a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                                                    <?php if( $video_type == 2 && get_theme_mod( 'youtube_btn' ) ): ?>
                                                    <a class="btn-hover color-11" href="<?php the_permalink(); ?>"><?php echo esc_html( get_theme_mod( 'youtube_btn', 'Read more' ) ); ?></a>
                                                <?php
                                            endif; // End video type checking
                                            //}
                                            }
                                        endif;                                    
                                    echo "</span>";
                                endif; // End author and category

                                if (class_exists('EDD_Reviews') && get_theme_mod( 'eid_ratings' ) == 'on') {
                                    echo "<span class='bt-review'>";

                                        $mreview = new \EDD_Reviews;
                                        $rating = $mreview->average_rating(false);
                                        echo $mreview->render_star_rating( $rating );
                                        echo '('.$mreview->count_reviews().')';

                                    echo "</span>";
                                } // End ratings check 
                                if ( get_theme_mod( 'eid_sales' ) == 'on'): 
                                    echo "<span>".esc_html( $sales )."</span>";
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>

                <?php

                endwhile;   // End while loop 
                wp_reset_postdata();  // Reset post data ?>
        
            </div>
        </div>

        <?php if( paginate_links() ){ ?>               

        <div class="col-md-12">
            <div class="course-pagination">
                <ul class="pagination">
                    <li>
                        <?php

                        global $wp_query;
                
                        $big = 999999999; // need an unlikely integer

                        echo paginate_links( array(                         
                            
                            'base'         => str_replace( 999999999, '%#%', html_entity_decode( get_pagenum_link( 999999999 ) ) ),
                            'total'        => $wp_query->max_num_pages,
                            'current'      => max( 1, get_query_var( 'paged' ) ),
                            'format'       => '?paged=%#%',
                            'show_all'     => false,
                            'type'         => 'plain',
                            'end_size'     => 2,
                            'mid_size'     => 1,
                            'prev_next'    => true,
                            'prev_text' => '<i class="fa fa-angle-left"></i>',
                            'next_text' => '<i class="fa fa-angle-right"></i>',
                            'add_args'     => false,
                            'add_fragment' => ''

                        ) );

                        ?>
                    </li>
                </ul>
            </div>
        </div>

        <?php

        } else {

            echo '<div class="padding-bottom-large"></div>';

        }

    else:   // If no post

        echo '<div class="col-md-12 padding-top-large padding-bottom-large">';
           echo get_template_part( 'template-parts/content','none' );
        echo '</div>';

    endif;  // End posts checking                   

}
add_action( 'video_tag_quary','eidmart_video_tag_quary' );


// Header menu product search
if ( !function_exists( 'eidmart_web_product_search' ) ) :
function eidmart_web_product_search(){ ?>

    <form action="<?php echo esc_url( get_post_type_archive_link('download')); ?>">
        <div class="input-group">                                     
            <input class="form-control" name="s" type="text" value="<?php echo (isset($_GET['s']))?$_GET['s']: null; ?>" placeholder="<?php esc_attr_e( 'Search...', 'eidmart' ); ?>">
            <input type="hidden" name="post_type" value="download">
            <div class="input-group-append">
                <button class="btn btn-search" type="submit"><i class="las la-search"></i></button>
            </div>
        </div>
    </form>

<?php } endif;

if ( ! function_exists( 'eidmart_set_post_views' ) ) :
    //popular posts
    function eidmart_set_post_views($postID) {
        $count_key = 'eidmart_post_views_count';
        $count = get_post_meta($postID, $count_key, true);
        if($count==''){
            $count = 0;
            delete_post_meta($postID, $count_key);
            add_post_meta($postID, $count_key, '0');
        }else{
            $count++;
            update_post_meta($postID, $count_key, $count);
        }
    }
endif;

if ( ! function_exists( 'eidmart_get_post_views' ) ) :
    //post count with icon
    function eidmart_get_post_views($postID){
        $count_key = 'eidmart_post_views_count';
        $count = get_post_meta($postID, $count_key, true);
        if($count==''){
            delete_post_meta($postID, $count_key);
            add_post_meta($postID, $count_key, '1');
            return esc_html__( "0 View", "eidmart" );
        }
        return '<span class="lnr lnr-eye"></span> '.$count ;
    }
endif;

if ( ! function_exists( 'eidmart_get_post_view' ) ) :
    //post count without icon
    function eidmart_get_post_view($postID){
        $count_key = 'eidmart_post_views_count';
        $count = get_post_meta($postID, $count_key, true);
        if($count==''){
            delete_post_meta($postID, $count_key);
            add_post_meta($postID, $count_key, '1');
            return "0 View";
        }
        return $count ;
    }
endif;

// Unused rating
function eidmart_show_average_star_rating() {
    // make sure edd reviews is active
    if ( ! function_exists( 'edd_reviews' ) )
        return;
    
    $edd_reviews = edd_reviews();
    // get the average rating for this download
    $average_rating = (int) $edd_reviews->average_rating( false );  
    $rating = $average_rating;
    ob_start();
    ?>

    <div class="rating product--rating">        
        <ul>
            <li>
                <div itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating" class="star-rating">
                    <div class="edd_reviews_rating_box" role="img" aria-label="<?php echo esc_attr( $rating ) . ' ' . esc_html__( 'stars', 'eidmart' ); ?>">
                        <div class="edd_star_rating" style="width: <?php echo ( 19 * $rating ); ?>px"></div>
                    </div>
                    <div style="display:none" itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">
                        <meta itemprop="worstRating" content="1" />
                        <span itemprop="ratingValue"><?php echo esc_html( $rating ); ?></span>
                        <span itemprop="bestRating">5</span>
                    </div>
                </div>
            </li>            
        </ul>        
    </div>
        
    <?php
    $rating_html = ob_get_clean();
    return $rating_html;
}

if( ! function_exists( 'eidmart_share_tags' )  ) :
    /**
     *  Tags fetch
     */
    function eidmart_share_tags() { ?>
 
         <div class="share_tags">
             <div class="share">
                 <p><?php esc_html_e( 'Share this post' , 'eidmart' ); ?></p>
                 <div class="social_share active">
                     <ul class="social_icons">
 
                         <li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>"><span class="fa fa-facebook"></span></a></li>
                         <li><a href="http://twitter.com/home?status=Reading: <?php the_permalink(); ?>"><span class="fa fa-twitter"></span></a></li>
                         <li><a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="window.open('https://plus.google.com/share?url=<?php the_permalink(); ?>','gplusshare','width=600,height=400,left='+(screen.availWidth/2-225)+',top='+(screen.availHeight/2-150)+'');return false;"><span class="fa fa-google-plus"></span></a></li>
                         <li><a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>" title="Share on LinkedIn" rel="external nofollow" rel="nofollow" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                     
                     </ul>
 
                 </div><!-- end social_share -->
             </div><!-- end bog_share_ara  -->
 
             <div class="tags">
                 <ul>
                     <li><?php the_tags( '',' ','' ); ?></li>
                 </ul>
             </div>
         </div>
 
    <?php        
    }
endif;

// Single Page Share Button
if( ! function_exists( 'eidmart_page_share_buttons' )  ) :
    /**
     *  Share URL
     */
    function eidmart_page_share_buttons() { ?>                                     
        <li><a href='http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>'> <i class="fa fa-facebook"></i> </a></li>
        <li><a href='http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title_attribute(); ?>&amp;url=<?php the_permalink(); ?>'> <i class="fa fa-linkedin"></i> </a></li>                                     
        <li><a href='http://twitter.com/home?status=Reading: <?php the_permalink(); ?>'> <i class="fa fa-twitter"></i> </a></li>
    <?php        
    }
 endif;

 // Default Share Button
if( ! function_exists( 'eidmart_default_blog_share_buttons' )  ) :
    /**
     *  Share URL
     */
    function eidmart_default_blog_share_buttons() { ?>                                     
        <a class="dropdown-item" href='http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>'> <i class="fa fa-facebook-f"></i> </a>
        <a class="dropdown-item" href='http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title_attribute(); ?>&amp;url=<?php the_permalink(); ?>'> <i class="fa fa-linkedin"></i> </a>									
        <a class="dropdown-item" href='http://twitter.com/home?status=Reading: <?php the_permalink(); ?>'> <i class="fa fa-twitter"></i> </a>
    <?php        
    }
 endif;
