<?php

// Register custom posts type

/* ----------------------------------------------------- */
/* Register Custom Post for Events */ 
/* ----------------------------------------------------- */
add_action( 'init', 'register_eidmart_event' );

function register_eidmart_event() {
	$labels = array(
		'name' => __( 'Events','eidmart'),
		'singular_name' => __( 'Events','eidmart'),
		'add_new' => __( 'Add New','eidmart' ),
		'add_new_item' => __( 'Add New Event','eidmart' ),
		'edit_item' => __( 'Edit Event','eidmart'),
		'new_item' => __( 'New Event','eidmart'),
		'view_item' => __( 'View Event','eidmart'),
		'search_items' => __( 'Search Events','eidmart'),
		'not_found' => __( 'No event found','eidmart'),
		'not_found_in_trash' => __( 'No works found in Trash','eidmart'),
		'parent_item_colon' => __( 'Parent work:','eidmart'),
		'menu_name' => __( 'Eidmart Events','eidmart'),
	);

	$args = array(
		'labels' => $labels,
		'hierarchical' => false,
		'description' => 'Display your works by department',
		'supports' => array( 'title', 'editor', 'thumbnail' ),

		'public' => true,
		'menu_icon' => 'dashicons-megaphone',
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'has_archive' => true,
		'query_var' => true,
		'can_export' => true,
		'rewrite' => true,
		'capability_type' => 'post'
	);

	register_post_type( 'events', $args );
	flush_rewrite_rules( false );
}

/* ----------------------------------------------------- */
/* Register Custom Post for Jobs */ 
/* ----------------------------------------------------- */
add_action( 'init', 'register_eidmart_job' );

function register_eidmart_job() {
	$labels = array(
		'name' => __( 'Jobs','eidmart'),
		'singular_name' => __( 'Jobs','eidmart'),
		'add_new' => __( 'Add New','eidmart' ),
		'add_new_item' => __( 'Add New Job','eidmart' ),
		'edit_item' => __( 'Edit Job','eidmart'),
		'new_item' => __( 'New Job','eidmart'),
		'view_item' => __( 'View Job','eidmart'),
		'search_items' => __( 'Search Jobs','eidmart'),
		'not_found' => __( 'No job found','eidmart'),
		'not_found_in_trash' => __( 'No works found in Trash','eidmart'),
		'parent_item_colon' => __( 'Parent work:','eidmart'),
		'menu_name' => __( 'Eidmart Jobs','eidmart'),
	);

	$args = array(
		'labels' => $labels,
		'hierarchical' => false,
		'description' => 'Display your works by department',
		'supports' => array( 'title', 'editor', 'thumbnail' ),

		'public' => true,
		'menu_icon' => 'dashicons-admin-users',
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'has_archive' => true,
		'query_var' => true,
		'can_export' => true,
		'rewrite' => true,
		'capability_type' => 'post'
	);

	register_post_type( 'jobs', $args );
	flush_rewrite_rules( false );
}
