<?php

// Start inner page coding...

// ===================================================================
//Start Related item 
// [related-product title="Related Items" author="on" category="on" footer="on" max_char="70" price="on" ratings="on" love="on" sale="on"]
// ===================================================================
function eidmart_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}


	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 6,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'footer'       => '',
				'price'        => '',
				'ratings'      => '',
				'love'         => '',
				'sale'   	   => '',
			),
			$atts
		)
	);
	
	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);
	
	$wp_query = new wp_query( $args );

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x">
	    <div class="container">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>

	            <div class="col-md-12">                
	                <div class="featured-product">	                    

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
			            while ( $wp_query->have_posts() ) : 
			                $wp_query -> the_post();
			        
			                $id = get_the_ID();
			                $meta = get_post_meta( get_the_ID() );
			                $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
			                $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
			                $sales = edd_get_download_sales_stats( get_the_ID() );
			                $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;            
            
							/**
							 * Get all variable pricing
							 */
							$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
							
							/**
							 * Get checked item
							 */
							$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
							$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
							$price_checked = isset( $price_checked ) ? $price_checked: 0;

							// Variables pricing price
							$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
							$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

							// Pricing options price
							$single_regular_price = get_post_meta( $id, 'edd_price', true );
							$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

							/**
							 * Get the selected price of variable item
							 */
							if( 1 != $checked_key ): 
								$item_price = edd_price( $id, false, $price_checked ); 
							else: 
								$item_price = edd_price( $id, false, '' ); 
							endif;
			        
							?>			            
							
							<div class="single-product hover01">
								<figure>
									<?php the_post_thumbnail(); ?>
								</figure>

								<?php if (!empty(get_post_meta($post->ID, 'edd_feature_download'))): ?>
									<span class="sticker-feature" data-toggle="tooltip" data-placement="right" title="<?php esc_html_e('Featured', 'eidmart');?>"><i class="las la-gem"></i></span>
								<?php endif;

								/**
								 * Discount percentage calculation 
								 * @ edd_has_variable_prices( $id )
								 */
								if( $sale_price && edd_has_variable_prices( $id ) ):
									$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
								elseif( $single_sale_price ):
									$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
								else:
									$discount_percent = 0;
								endif;

								/**
								 * Discount Percentage
								 */
								if( $discount_percent > 0 ):
								?>
								<p class="discount-percentage">
									<span><?php echo esc_html( $discount_percent ); ?>%</span>
									<?php esc_html_e( 'Off', 'eidmart' ); ?>
								</p>
								<?php endif; ?>

								<div class="product-details">
									<div class="product-content">
										<a href="<?php the_permalink(); ?>" ><?php echo eidmart_excerpt_char_course_title( $max_char ); ?></a>

										<?php

										// Collect user ID
										$user_id = get_the_author_meta( 'ID' ); 
										// Collect user name
										$user_name = get_the_author_meta( 'user_login' , $user_id );

										if( $author =='on' || $category =='on' ): ?>
										<p> 
											<?php 
											if( $author =='on' ):
											esc_html_e( 'by', 'eidmart' ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
											
											<?php 
											endif;
											if( $category =='on' ):
											esc_html_e( 'in', 'eidmart' ); ?>
											<?php
												$terms = get_the_terms( $id , 'download_category' );
												if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
													//foreach ( $terms as $term ) {
														?>
											
														<a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

														<?php                             
													//}
												}
											endif;
											?>
										</p>
										<?php else: ?>
											<div class="padding-top-very-small"></div>
										<?php endif; 

										// Check product paragraph
										if( $product_para =='on' ):
										?>
										<p class="product-paragraph"><?php if ( has_excerpt() ): echo get_the_excerpt(); else: echo eidmart_excerpt_char( '60' ); endif; ?></p>
										<?php endif; ?>

										<h3 class="<?php if ( $sale != 'on'): echo esc_attr( "price-n-preview" ); endif; ?>">
										<?php if( $price == 'on' ): ?><strong><?php if( $edd_price ): echo $item_price; else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?>
											<span class="cart-btn">
												<?php if( $edd_price ){ ?>
													<?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-shopping-cart"></i></a><?php endif; ?>
												<?php } else { ?>
													<?php if( get_post_meta( $post->ID, 'cart_bt_url',true) ): ?><a href="<?php echo esc_url( get_post_meta( $post->ID, 'cart_bt_url',true) ); ?>"><i class="las la-cloud-download-alt"></i></a><?php endif; ?>
												<?php } ?>
												<?php if( get_post_meta( $post->ID, 'preview_text',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>" class="btn-bordered"> <?php echo esc_html( get_post_meta( $post->ID, 'preview_text',true) ); ?> </a><?php endif; ?>
											</span>                                
										</h3>
									</div>

									<?php if ( $footer =='on' ): ?>									
									<div class="product-content-footer">
										<h4>
										<?php
										if (class_exists('EDD_Reviews') && $ratings == 'on') {
											echo "<span class='bt-review'>";
											$mreview = new \EDD_Reviews;                                        

											$rating = $mreview->average_rating(false);
											echo $mreview->render_star_rating( $rating );
											echo $mreview->display_total_reviews_count();

											echo "</span>";
										} // End ratings check

										if ( $love == 'on' ):
										?>
											<span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span> 

										<?php endif; if ( $sale == 'on'): 
											echo "<span>".esc_html( $sales )."</span>";
										endif;
										?>
										</h4>
									</div> 
									<?php endif; ?>

								</div>
							</div>
			           
			            <?php 
			            
			            endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
			            
			            <?php endif; ?>

	                </div>                 
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('related-product', 'eidmart_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start Related item 
// [video-related-product title="Related Items" author="on" category="on" product_para="off" max_post="6" max_char="35" price="on" ratings="on" love="on"]
// ===================================================================
function eidmart_video_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}

	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 6,
				'col'     	   => 'col-md-4',
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'sale'         => '',
				'footer'       => '',
				'price'        => '',
				'ratings'      => '',
				'love'         => ''
			),
			$atts
		)
	);
	
	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);	
	
	$wp_query = new wp_query( $args );

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x video-filter">
	    <div class="container-fluid">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; if( $wp_query->have_posts() ): ?>

	            <div class="col-md-12 photography-filter">
						
					<div class="grid">
						<div class="grid-sizer"></div>
						<?php
						while ( $wp_query->have_posts() ) : 
							$wp_query -> the_post();
					
							$id = get_the_ID();
							$meta = get_post_meta(get_the_ID());
							$variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
							$edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';

							$sales = edd_get_download_sales_stats(get_the_ID());
							$sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

							$internal_url = isset($meta['mp4_url'][0]) ? $meta['mp4_url'][0] : '';
							$external_url = isset($meta['external_url'][0]) ? $meta['external_url'][0] : '';

							$video_url = !empty( $external_url ) ? $external_url : $internal_url;
							$video_type = isset($meta['video_type'][0]) ? $meta['video_type'][0] : 1;

							// Collect downloads tearms
							$terms = get_the_terms($post->ID, 'download_category');

							/**
							 * Get all variable pricing
							 */
							$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
							
							/**
							 * Get checked item
							 */
							$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
							$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
							$price_checked = isset( $price_checked ) ? $price_checked: 0;
		
							// Variables pricing price
							$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
							$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;
		
							// Pricing options price
							$single_regular_price = get_post_meta( $id, 'edd_price', true );
							$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );
		
							/**
							 * Get the selected price of variable item
							 */
							if( 1 != $checked_key ): 
								$item_price = edd_price( $id, false, $price_checked ); 
							else: 
								$item_price = edd_price( $id, false, '' ); 
							endif;
							
							// Collect user ID
							$user_id = get_the_author_meta('ID');
							// Collect user name
							$user_name = get_the_author_meta('user_login', $user_id); ?>	

							<div class="grid-item photography-filter-item">
								<div class="load-more">
								
									<a class="photography-item_url" href="<?php the_permalink();?>">
									<?php if( $video_url ): 
										
										// Check video type
										if( $video_type == 1 ){ ?>

											<video <?php if( get_theme_mod( 'video_sound' ) == 1 ): echo "muted"; endif; ?> class="hvrbox-layer_bottom video-control" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
												<source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
												<?php esc_html_e( 'Your browser does not support HTML5 video.', 'eidmart' ); ?>
											</video>

										<?php } else { ?>

											<!-- 16:9 aspect ratio -->
											<div class="embed-responsive embed-responsive-16by9" style="height: <?php echo esc_attr( get_theme_mod( 'video_height', 210 ) );?>px">
												<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo esc_attr( $video_url ); ?>?rel=0&controls=0&modestbranding=1&showinfo=0" allowfullscreen frameborder="0""></iframe>
											</div>

										<?php } endif; ?>
									</a>

									<?php
									/**
									 * Discount percentage calculation
									 */
									if( $sale_price && edd_has_variable_prices( $id ) ):
										$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
									elseif( $single_sale_price ):
										$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
									else:
										$discount_percent = 0;
									endif;

									/**
									 * Discount Percentage
									 */
									if( $discount_percent > 0 ):
									?>
									<p class="discount-percentage">
										<span><?php echo esc_html( $discount_percent ); ?>%</span>
										<?php esc_html_e( 'Off', 'eidmart' ); ?>
									</p>
									<?php endif; 
									
									if ( $love == 'on' ): ?>
										<div class="image-rating">
											<span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
										</div>
									<?php endif; if ( $price == 'on' ): ?>
										<span class="sale"><?php if ($edd_price): echo $item_price; else: echo __('Free', 'eidmart'); endif; ?></span>
									<?php endif;

									echo "<div class='auth-info'>"; 
										if( $author == 'on' || $category =='on' ):                                            
											echo "<span>";
												if( $author == 'on' ):
												
												// Author picture show
												echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
												esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

												<?php 
												endif;

												if ( $category == 'on' ):                                    
													esc_html_e('in', 'eidmart');                                                
													$terms = get_the_terms($id, 'download_category');
													if (!empty($terms) && !is_wp_error($terms)) {
														//foreach ( $terms as $term ) {
														?>
															<a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
															<?php if( $video_type == 2 && get_theme_mod( 'youtube_btn' ) ): ?>
															<a class="btn-hover color-11" href="<?php the_permalink(); ?>"><?php echo esc_html( get_theme_mod( 'youtube_btn', 'Read more' ) ); ?></a>
														<?php
													endif; // End video type checking
													//}
													}
												endif;                                    
											echo "</span>";
										endif; // End author and category

										if (class_exists('EDD_Reviews') && $ratings == 'on') {
											echo "<span class='bt-review'>";

												$mreview = new \EDD_Reviews;
												$rating = $mreview->average_rating(false);
												echo $mreview->render_star_rating( $rating );
												echo '('.$mreview->count_reviews().')';

											echo "</span>";
										} // End ratings check 
										if ( $sale == 'on'): 
											echo "<span>".esc_html( $sales )."</span>";
										endif;
										?>
									</div>
								</div>
							</div>
					
						<?php							
						endwhile; wp_reset_postdata(); ?>

					</div>

					<?php else: ?>
						<h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
					<?php endif; ?>
             
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode('video-related-product', 'eidmart_video_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start graphicland one Related item "title and price in the same line" 
// [graphicland title="Related Items" max_post="6" author="on" category="on" sale="on" love="on" max_char="50"]
// ===================================================================
function eidmart_graphicland_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}


	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 6,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'love'         => '',
				'sale'         => '',
			),
			$atts
		)
	);

	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);		
	
	$wp_query = new wp_query( $args );

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x graphicland-style">
	    <div class="container">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>

	            <div class="col-md-12">                
	                <div class="featured-product">	                    

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
			            while ( $wp_query->have_posts() ) : 
			                $wp_query -> the_post();
			        
			                $id = get_the_ID();
			                $meta = get_post_meta( get_the_ID() );
			                $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
			                $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
			                $sales = edd_get_download_sales_stats( get_the_ID() );
			                $sales = $sales > 1 ? $sales . __(' sales','eidmart') : $sales . __(' sale','eidmart');

							/**
							 * Get all variable pricing
							 */
							$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
							
							/**
							 * Get checked item
							 */
							$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
							$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
							$price_checked = isset( $price_checked ) ? $price_checked: 0;

							// Variables pricing price
							$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
							$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

							// Pricing options price
							$single_regular_price = get_post_meta( $id, 'edd_price', true );
							$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

							/**
							 * Get the selected price of variable item
							 */
							if( 1 != $checked_key ): 
								$item_price = edd_price( $id, false, $price_checked ); 
							else: 
								$item_price = edd_price( $id, false, '' ); 
							endif;
			        
							?>			            
							
							<div class="single-product">                       

								<div class="graphicland-product-container">								  
									<div class="product-content">
										<a href="<?php the_permalink(); ?>" target="_blank">
											<div class="content-overlay"></div>

											<?php the_post_thumbnail( '', [ 'class' => 'graphicland-image' ] ); ?>
											
											<div class="content-details fadeIn-bottom">	
												<div class="product-content product-author">

													<?php

													// Collect user ID
													$user_id = get_the_author_meta( 'ID' ); 
													// Collect user name
													$user_name = get_the_author_meta( 'user_login' , $user_id );

													if( $author =='on' || $category =='on' ): ?>
													<p> 
														<?php 
														if( $author =='on' ):
														echo get_avatar( $user_id, 30, '' , '' , array( 'class' => array( 'vendor-avatar' ) ) ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
														
														<?php 
														endif;
														if( $category =='on' ):
														esc_html_e( 'in', 'eidmart' ); ?>
														<?php
															$terms = get_the_terms( $id , 'download_category' );
															if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
																//foreach ( $terms as $term ) {
																	?>
														
																	<a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

																	<?php                             
															    //}
															}
														endif;

														if ($love == 'on'): ?>
														<span class="right-side overlay-icon">
															<?php echo eidmart_get_likes_button( get_the_ID() ); ?>
														</span>
														<?php endif; ?>

													</p>
													<?php endif; ?>
												</div>
											</div>											
										</a>
									</div>
								</div>
							
								<?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
									<span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
								<?php endif; 
								
								/**
								 * Discount percentage calculation
								 */
								if( $sale_price && edd_has_variable_prices( $id ) ):
									$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
								elseif( $single_sale_price ):
									$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
								else:
									$discount_percent = 0;
								endif;

								/**
								 * Discount Percentage
								 */
								if( $discount_percent > 0 ):
								?>
								<p class="discount-percentage">
									<span><?php echo esc_html( $discount_percent ); ?>%</span>
									<?php esc_html_e( 'Off', 'eidmart' ); ?>
								</p>
								<?php endif; ?>

								<div class="product-details graphicland-product-details">		                                
									<h3 class="content-title" ><a href="<?php the_permalink(); ?>"><?php echo eidmart_excerpt_char_course_title( $max_char ); ?></a> <strong><?php if( $edd_price ): echo edd_price(); else: echo __( 'Free','eidmart' ); endif; ?></strong></h3>
								</div>

							</div>
			           
			            <?php 
			            
			            endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
			            
			            <?php endif; ?>

	                </div>                 
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('graphicland', 'eidmart_graphicland_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start graphicland two Related item "up title and under author" 
// [graphicland-two title="Related Items" max_post="6" author="on" category="on" price="on" ratings="on" sale="on" love="on" max_char="50"]
// ===================================================================
function eidmart_graphicland_two_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}


	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 6,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'price'        => '',
				'ratings'      => '',
				'love'         => '',
				'sale'   	   => '',
			),
			$atts
		)
	);

	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);		
	
	$wp_query = new wp_query( $args );       

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x graphicland-style graphicland-one">
	    <div class="container">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>

	            <div class="col-md-12">                
	                <div class="featured-product">	                    

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
			            while ( $wp_query->have_posts() ) : 
			                $wp_query -> the_post();
			        
			                $id = get_the_ID();
			                $meta = get_post_meta( get_the_ID() );
			                $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
			                $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
			                $sales = edd_get_download_sales_stats( get_the_ID() );
			                $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

							/**
							 * Get all variable pricing
							 */
							$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
							
							/**
							 * Get checked item
							 */
							$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
							$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
							$price_checked = isset( $price_checked ) ? $price_checked: 0;

							// Variables pricing price
							$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
							$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

							// Pricing options price
							$single_regular_price = get_post_meta( $id, 'edd_price', true );
							$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

							/**
							 * Get the selected price of variable item
							 */
							if( 1 != $checked_key ): 
								$item_price = edd_price( $id, false, $price_checked ); 
							else: 
								$item_price = edd_price( $id, false, '' ); 
							endif;
			        
							?>

							<div class="single-product">                  
								<div class="graphicland-product-container">                               
									<div class="product-content">
										<a href="<?php the_permalink(); ?>" target="_blank">
											<div class="content-overlay"></div>

											<?php the_post_thumbnail( '', [ 'class' => 'graphicland-image' ] ); ?>
										
											<div class="overlay-center">
												<?php if( get_post_meta( $post->ID, 'preview_url',true ) ): ?>
												<div class="graphicland-live-preview">
													<?php if( get_post_meta( $post->ID, 'preview_url',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>"> <i class="las la-eye"></i> </a><?php endif; ?>
												</div>
												<?php endif; if ($love == 'on'): ?>
												<div class="graphicland-favourite-icon">
													<?php echo eidmart_get_likes_button( get_the_ID() ); ?>
												</div>
												<?php endif; ?>
											</div>                                
										</a>
									</div>
								</div>
							
								<?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
									<span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
								<?php endif; 

								/**
								 * Discount percentage calculation
								 */
								if( $sale_price && edd_has_variable_prices( $id ) ):
									$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
								elseif( $single_sale_price ):
									$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
								else:
									$discount_percent = 0;
								endif;

								/**
								 * Discount Percentage
								 */
								if( $discount_percent > 0 ):
								?>
								<p class="discount-percentage">
									<span><?php echo esc_html( $discount_percent ); ?>%</span>
									<?php esc_html_e( 'Off', 'eidmart' ); ?>
								</p>
								<?php endif; ?>

								<div class="product-details graphicland-product-details">
									<div class="product-content">

										<div class="product-details graphicland-product-details">                                       
											<h3 class="content-title" ><a href="<?php the_permalink(); ?>"><?php echo eidmart_excerpt_char_course_title( $max_char ); ?></a> <?php if( $price == 'on' ): ?><strong><?php if( $edd_price ): echo wp_kses_post( $item_price ); else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?></h3>
										</div>
										
										<?php

										// Collect user ID
										$user_id = get_the_author_meta( 'ID' ); 
										// Collect user name
										$user_name = get_the_author_meta( 'user_login' , $user_id );

										echo "<p>"; 
											if( $author =='on' || $category =='on' ):                                            
												echo "<span>";
													if( $author =='on' ):
													echo get_avatar( $user_id, 20, '' , '' , array( 'class' => array( 'vendor-avatar' ) ) ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
													
													<?php 
													endif;
													if( $category =='on' ):
													esc_html_e( 'in', 'eidmart' ); ?>
													<?php
														$terms = get_the_terms( $id , 'download_category' );
														if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
															//foreach ( $terms as $term ) {
																?>
													
																<a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

																<?php                             
														// }
														}
													endif;
												echo "</span>";
											endif; // End author and category

											if (class_exists('EDD_Reviews') && $ratings == 'on') {
												echo "<span class='bt-review'>";

													$mreview = new \EDD_Reviews;
													$rating = $mreview->average_rating(false);
													echo wp_kses_post( $mreview->render_star_rating( $rating ) );
													echo '('. esc_html( $mreview->count_reviews() ).')';

												echo "</span>";
											} // End ratings check 
											if ($sale == 'on'): 
												echo "<span>".esc_html( $sales )."</span>";
											endif;
											?>
										</p>                                  

									</div>
								</div>
							</div>
			           
			            <?php 
			            
			            endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
			            
			            <?php endif; ?>

	                </div>                 
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('graphicland-two', 'eidmart_graphicland_two_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start graphicland two Related item without slide "up title and under author"
// [graphicland-noslide title="Related Items" column="col-md-4" author="on" category="on" price="on" ratings="on" sale="on" love="on" max_char="50"]
// ===================================================================
function eidmart_graphicland_three_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}

	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 6,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'price'        => '',
				'column'       => '',
				'sale'         => '',
				'ratings'      => '',
				'love'         => '',
			),
			$atts
		)
	);

	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);		
	
	$wp_query = new wp_query( $args );    

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x graphicland-style graphicland-one no-slide">
	    <div class="container">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>

	            <div class="col-md-12">	                    
	                <div class="row">	                    

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
			            while ( $wp_query->have_posts() ) : 
			                $wp_query -> the_post();
			        
			                $id = get_the_ID();
			                $meta = get_post_meta( get_the_ID() );
			                $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
			                $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
			                $sales = edd_get_download_sales_stats( get_the_ID() );
			                $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;

							/**
							 * Get all variable pricing
							 */
							$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
							
							/**
							 * Get checked item
							 */
							$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
							$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
							$price_checked = isset( $price_checked ) ? $price_checked: 0;

							// Variables pricing price
							$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
							$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

							// Pricing options price
							$single_regular_price = get_post_meta( $id, 'edd_price', true );
							$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

							/**
							 * Get the selected price of variable item
							 */
							if( 1 != $checked_key ): 
								$item_price = edd_price( $id, false, $price_checked ); 
							else: 
								$item_price = edd_price( $id, false, '' ); 
							endif;
			        
							?>
											
							<div class="<?php echo esc_attr( $column ); ?>">  
								<div class="single-product">                  
									<div class="graphicland-product-container">                               
										<div class="product-content">
											<a href="<?php the_permalink(); ?>" target="_blank">
												<div class="content-overlay"></div>

												<?php the_post_thumbnail( '', [ 'class' => 'graphicland-image' ] ); ?>
											
												<div class="overlay-center">
													<?php if( get_post_meta( $post->ID, 'preview_url',true ) ): ?>
													<div class="graphicland-live-preview">
														<?php if( get_post_meta( $post->ID, 'preview_url',true) ): ?><a  target="_blank" href="<?php echo esc_url( get_post_meta( $post->ID, 'preview_url',true) ); ?>"> <i class="las la-eye"></i> </a><?php endif; ?>
													</div>
													<?php endif; if ($love == 'on'): ?>
													<div class="graphicland-favourite-icon">
														<?php echo eidmart_get_likes_button( get_the_ID() ); ?>
													</div>
													<?php endif; ?>
												</div>                                
											</a>
										</div>
									</div>
								
									<?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
										<span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
									<?php endif; 

									/**
									 * Discount percentage calculation
									 */
									if( $sale_price && edd_has_variable_prices( $id ) ):
										$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
									elseif( $single_sale_price ):
										$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
									else:
										$discount_percent = 0;
									endif;

									/**
									 * Discount Percentage
									 */
									if( $discount_percent > 0 ):
									?>
									<p class="discount-percentage">
										<span><?php echo esc_html( $discount_percent ); ?>%</span>
										<?php esc_html_e( 'Off', 'eidmart' ); ?>
									</p>
									<?php endif; ?>

									<div class="product-details graphicland-product-details">
										<div class="product-content">

											<div class="product-details graphicland-product-details">                                       
												<h3 class="content-title" ><a href="<?php the_permalink(); ?>"><?php echo eidmart_excerpt_char_course_title( $max_char ); ?></a> <?php if( $price == 'on' ): ?><strong><?php if( $edd_price ): echo wp_kses_post( $item_price ); else: echo __( 'Free','eidmart' ); endif; ?></strong><?php endif; ?></h3>
											</div>
											
											<?php

											// Collect user ID
											$user_id = get_the_author_meta( 'ID' ); 
											// Collect user name
											$user_name = get_the_author_meta( 'user_login' , $user_id );

											echo "<p>"; 
												if( $author =='on' || $category =='on' ):                                            
													echo "<span>";
														if( $author =='on' ):
														echo get_avatar( $user_id, 20, '' , '' , array( 'class' => array( 'vendor-avatar' ) ) ); ?> <a href="<?php if( !class_exists( 'EDD_Front_End_Submissions' ) ){ echo esc_url( home_url( 'profile/' ) ); ?>?user=<?php echo esc_attr( $user_name ); } else { echo esc_url( eidmart_edd_fes_author_url() ); } ?>"> <?php the_author(); ?></a> 
														
														<?php 
														endif;
														if( $category =='on' ):
														esc_html_e( 'in', 'eidmart' ); ?>
														<?php
															$terms = get_the_terms( $id , 'download_category' );
															if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
																//foreach ( $terms as $term ) {
																	?>
														
																	<a href="<?php echo esc_url( get_term_link( $terms[0] ) ); ?>"><?php echo esc_html( $terms[0]->name ); ?></a> 

																	<?php                             
															// }
															}
														endif;
													echo "</span>";
												endif; // End author and category

												if (class_exists('EDD_Reviews') && $ratings == 'on') {
													echo "<span class='bt-review'>";

														$mreview = new \EDD_Reviews;
														$rating = $mreview->average_rating(false);
														echo wp_kses_post( $mreview->render_star_rating( $rating ) );
														echo '('. esc_html( $mreview->count_reviews() ).')';

													echo "</span>";
												} // End ratings check 
												if ($sale == 'on'): 
													echo "<span>".esc_html( $sales )."</span>";
												endif;
												?>
											</p>                                  

										</div>
									</div>
								</div>
							</div>
			           
			            <?php 
			            
			            endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
			            
			            <?php endif; ?>

	                </div>                                 
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('graphicland-noslide', 'eidmart_graphicland_three_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start Related image
// [image-related-product title="Related Items" author="on" category="on" price="on" ratings="on" sale="on" love="on" max_char="35" max_post="6"]
// ===================================================================
function eidmart_image_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}


	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 9,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'price'        => '',
				'column'       => '',
				'sale'         => '',
				'ratings'      => '',
				'love'         => '',
			),
			$atts
		)
	);

	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);		
	
	$wp_query = new wp_query( $args );      

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x">
	    <div class="container">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>

	            <div class="col-md-12">
	            	<div class="grid">
					<div class="grid-sizer"></div>                                  

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
			            while ( $wp_query->have_posts() ) : 
			                $wp_query -> the_post();
			        
			                $id = get_the_ID();
			                $meta = get_post_meta( get_the_ID() );
			                $variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
			                $edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';
			                $sales = edd_get_download_sales_stats( get_the_ID() );
			                $sales = $sales > 1 ? __('Sales ', 'eidmart') . $sales : __('Sale ', 'eidmart') .$sales;
			        
				            // Collect user ID
		                    $user_id = get_the_author_meta( 'ID' ); 
		                    // Collect user name
		                    $user_name = get_the_author_meta( 'user_login' , $user_id );

							/**
							 * Get all variable pricing
							 */
							$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
							
							/**
							 * Get checked item
							 */
							$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
							$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
							$price_checked = isset( $price_checked ) ? $price_checked: 0;

							// Variables pricing price
							$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
							$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

							// Pricing options price
							$single_regular_price = get_post_meta( $id, 'edd_price', true );
							$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

							/**
							 * Get the selected price of variable item
							 */
							if( 1 != $checked_key ): 
								$item_price = edd_price( $id, false, $price_checked ); 
							else: 
								$item_price = edd_price( $id, false, '' ); 
							endif;

					        ?>				      

							<div class="grid-item">
								<a href="<?php the_permalink(); ?>">
									<div class="img-gradient">
										<?php the_post_thumbnail(); ?>
									</div>
								</a>

								<?php
								/**
								 * Discount percentage calculation
								 */
								if( $sale_price && edd_has_variable_prices( $id ) ):
									$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
								elseif( $single_sale_price ):
									$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
								else:
									$discount_percent = 0;
								endif;

								/**
								 * Discount Percentage
								 */
								if( $discount_percent > 0 ):
								?>
								<p class="discount-percentage">
									<span><?php echo esc_html( $discount_percent ); ?>%</span>
									<?php esc_html_e( 'Off', 'eidmart' ); ?>
								</p>
								<?php endif; 
								
								if ( $love == 'on' ): ?>
									<div class="image-rating">
										<span><i><?php echo eidmart_get_likes_button(get_the_ID()); ?></i></span>
									</div>
								<?php endif; if ( $price == 'on' ): ?>
									<span class="sale"><?php if ($edd_price): echo wp_kses_post( $item_price ); else: echo __('Free', 'eidmart'); endif; ?></span>
								<?php endif;                        

								echo "<div class='auth-info'>"; 
									if( $author =='on' || $category =='on' ):                                            
										echo "<span>";
											if( $author =='on' ):
											
											// Author picture show
											echo get_avatar(get_the_author_meta('ID'), '40', '', '', array('class' => array('vendor-pic')));
											esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

											<?php 
											endif;

											if ( $category == 'on' ):                                    
												esc_html_e('in', 'eidmart');                                                
												$terms = get_the_terms($id, 'download_category');
												if (!empty($terms) && !is_wp_error($terms)) {
													//foreach ( $terms as $term ) {
													?>
														<a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
													<?php
												//}
												}
											endif;                                    
										echo "</span>";
									endif; // End author and category

									if (class_exists('EDD_Reviews') && $ratings == 'on') {
										echo "<span class='bt-review'>";

											$mreview = new \EDD_Reviews;
											$rating = $mreview->average_rating(false);
											echo wp_kses_post( $mreview->render_star_rating( $rating ) );
											echo '('. esc_html( $mreview->count_reviews() ) .')';

										echo "</span>";
									} // End ratings check 
									if ( $sale == 'on' ): 
										echo "<span>".esc_html( $sales )."</span>";
									endif;
									?>
								</div>
							</div>			           
			            <?php 
			            
			            endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
			            
			            <?php endif; ?> 
			        </div>              
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('image-related-product', 'eidmart_image_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start Audio Related item "title and price in the same line" 
// [audio title="Related Items" column="col-md-3" author="on" category="on" price="on" ratings="on" sale="on" love="on" max_char="35" max_post="6"]
// ===================================================================
function eidmart_audio_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'download_category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}


	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 6,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'column'       => '',
				'price'        => '',
				'column'       => '',
				'sale'         => '',
				'ratings'      => '',
				'love'         => '',
			),
			$atts
		)
	);

	$args = array(
		'post_type'      => 'download',
		'post__not_in'   => array( $post->ID ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
		'tax_query'      => array(
			array(
				'taxonomy' => 'download_category',
				'field'    => 'slug',
				'terms'    => $cat_name,
			),
		),
	);		
	
	$wp_query = new wp_query( $args );

	ob_start();	// Output buffering
	
	?>	

    <div class="featured-product-1x graphicland-style audio-version">
	    <div class="container-fluid">
	        <div class="row">
	        	<?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>

	            <div class="col-md-12">                
	                <div class="row">	                    

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
							while ( $wp_query->have_posts() ) : $wp_query -> the_post();
						
								$id = get_the_ID();
								$meta = get_post_meta(get_the_ID());
								$variable_pricing = isset($meta['_variable_pricing'][0]) ? $meta['_variable_pricing'][0] : '';
								$edd_price = isset($meta['edd_price'][0]) ? $meta['edd_price'][0] : '';

								$sales = edd_get_download_sales_stats(get_the_ID());
								$sales = $sales > 1 ? $sales . __(' sales', 'eidmart') : $sales . __(' sale', 'eidmart');

								$external_audio = isset($meta['external_audio'][0]) ? $meta['external_audio'][0] : '';
								if ( $external_audio ):
									$mp3_url = $external_audio;
								else:
									$mp3_url = isset($meta['mp3_url'][0]) ? $meta['mp3_url'][0] : '';
								endif;
								$mp3_artist = isset($meta['artist'][0]) ? $meta['artist'][0] : '';

								// Collect downloads tearms
								$terms = get_the_terms($post->ID, 'download_category');

								$mp3_title = html_entity_decode(get_the_title()) . uniqid();
								$mp3_title = preg_replace('/[^A-Za-z0-9\-]/', '', $mp3_title);

								/**
								 * Get all variable pricing
								 */
								$prices = apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $id ), $id );
								
								/**
								 * Get checked item
								 */
								$checked_key = isset( $_GET['price_option'] ) ? absint( $_GET['price_option'] ) : edd_get_default_variable_price( $id );
								$price_checked = apply_filters( 'edd_price_option_checked', $checked_key, $id );                            
								$price_checked = isset( $price_checked ) ? $price_checked: 0;

								// Variables pricing price
								$regular_amount = isset( $prices[$price_checked]['regular_amount'] ) ? $prices[$price_checked]['regular_amount']: 1;
								$sale_price = isset( $prices[$price_checked]['sale_price'] ) ? $prices[$price_checked]['sale_price']: 1;

								// Pricing options price
								$single_regular_price = get_post_meta( $id, 'edd_price', true );
								$single_sale_price = get_post_meta( $id, 'edd_sale_price', true );

								/**
								 * Get the selected price of variable item
								 */
								if( 1 != $checked_key ): 
									$item_price = edd_price( $id, false, $price_checked ); 
								else: 
									$item_price = edd_price( $id, false, '' ); 
								endif;
						
								?>			            
								
								<div class="<?php echo esc_attr( $column ); ?> single-product">
									<a href="javascript:void(0);" class="album-poster <?php echo esc_attr($mp3_title); ?>" data-uniqid="<?php echo esc_attr($mp3_title); ?>" data-switch="0" data-price='<?php if ($edd_price): echo wp_kses_post( $item_price ); else: esc_html_e('Free', 'eidmart'); endif; ?>' data-title='<?php the_title();?>' data-artist="<?php echo esc_attr($mp3_artist); ?>" data-mp3="<?php echo esc_attr($mp3_url); ?>" data-pid="<?php echo esc_attr($id); ?>" data-cover="<?php the_post_thumbnail_url();?>">
										<?php the_post_thumbnail();?>
										<div class="player-icon">
											<i class="las la-play"></i>
											<i class="las la-pause"></i>
										</div>
									</a>

									<?php if( !empty( get_post_meta( $post->ID, 'edd_feature_download' ) ) ): ?>
										<span class="sticker-feature"><i class="fa fa-gitlab"></i></span>
									<?php endif; 

									/**
									 * Discount percentage calculation
									 */
									if( $sale_price && edd_has_variable_prices( $id ) ):
										$discount_percent = intval( 100 * ( $regular_amount - $sale_price ) / $regular_amount );
									elseif( $single_sale_price ):
										$discount_percent = intval( 100 * ( $single_regular_price - $single_sale_price ) / $single_regular_price );
									else:
										$discount_percent = 0;
									endif;

									/**
									 * Discount Percentage
									 */
									if( $discount_percent > 0 ):
									?>
									<p class="discount-percentage">
										<span><?php echo esc_html( $discount_percent ); ?>%</span>
										<?php esc_html_e( 'Off', 'eidmart' ); ?>
									</p>
									<?php endif; ?>

									<div class="product-content">
										<div class="audio-title">
											<a href="<?php the_permalink();?>"><?php echo eidmart_excerpt_char_course_title($max_char); ?></a>
										</div>
										<?php if( $price == 'on' ): ?><div class="price"><?php if ($edd_price): echo wp_kses_post( $item_price ); else: echo __('Free', 'eidmart');endif;?></div><?php endif; ?>
									</div>                            

									<?php

									echo "<div class='auth-info'>"; 
										if( $author =='on' || $category =='on' ):                                            
											echo "<span>";
												if( $author =='on' ):
												
												// Author picture show
												//echo get_avatar( get_the_author_meta('ID'), '40', '' , '' , array( 'class' => array( 'vendor-pic' ) ) );
												esc_html_e('by', 'eidmart');?> <a href="<?php if (!class_exists('EDD_Front_End_Submissions')) {echo esc_url(home_url('profile/'));?>?user=<?php echo esc_attr($user_name);} else {echo esc_url(eidmart_edd_fes_author_url());} ?>"> <?php the_author();?></a>

												<?php 
												endif;
												if( $category =='on' ):
													esc_html_e( 'in', 'eidmart' ); 
													$terms = get_the_terms($id, 'download_category');
													if (!empty($terms) && !is_wp_error($terms)) { ?>
														<a href="<?php echo esc_url(get_term_link($terms[0])); ?>"><?php echo esc_html($terms[0]->name); ?></a>
													<?php
													}
												endif;
											echo "</span>";
										endif; // End author and category

										if (class_exists('EDD_Reviews') && $ratings == 'on') {
											echo "<span class='bt-review'>";

												$mreview = new \EDD_Reviews;
												$rating = $mreview->average_rating(false);
												echo wp_kses_post( $mreview->render_star_rating( $rating ) );
												echo '('. esc_html( $mreview->count_reviews() ) .')';

											echo "</span>";
										} // End ratings check 
										if ($sale == 'on'): 
											echo "<span>".esc_html( $sales )."</span>";
										endif;
										?>
									</div>
								</div>
						
							<?php 							
							endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related product.','eidmart' ); ?></h3>
			            
			            <?php endif; ?>

	                </div>                 
	            </div>
	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('audio', 'eidmart_audio_related_item_shortcode');
//End Related Artilces

// ===================================================================
//Start Related blog 
// [blog-related-product title="Related Items" max_post="3" max_char="35"]
// ===================================================================
function eidmart_blog_related_item_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
		// Print the name method from $term which is an OBJECT
		$cat_name = $term->name ;
		//echo $cat_name;
		// Get rid of the other data stored in the object, since it's not needed
		unset($term);
		} 
	}


	if ($cat_name) {

	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'max_char'     => '35',
				'max_post'     => 3,
				'author'       => '',
				'product_para' => '',
				'category'     => '',
				'sale'         => '',
			),
			$atts
		)
	); 
	
	$args = array(
		'post_type'      => 'post',
		'post__not_in'   => get_option( 'sticky_posts' ),
		'posts_per_page' => $max_post,
		'orderby'        => 'rand',
	);

	$wp_query = new wp_query( $args );

	ob_start();	// Output buffering
	
	?>	

	<div class="blog-1x related-article">
	    <div class="container"> 
	        <div class="row">
	            <?php if( $title ): ?>
	            <div class="col-md-12">
	                <div class="title-left">
	                    <h2><?php echo esc_html( $title ); ?></h2>
	                </div>                    
	            </div>
	        	<?php endif; ?>
	            <div class="col-md-12">
	                <div class="row">  

	                    <?php 
	        
			            if( $wp_query->have_posts() ):
			            while ( $wp_query->have_posts() ) : 
			            $wp_query -> the_post(); ?>

						<div class="col-lg-4">
							<div class="single-blog hover01">
								<figure>
									<a href="<?php the_permalink();?>">
			                        	<?php the_post_thumbnail();?>
			                        </a>
								</figure>
								<div class="blog-content">

									<span><i class="fa fa-bookmark-o"></i>
										<?php $categories = get_the_category();
                                        if (!empty($categories)) {
                                            echo esc_html($categories[0]->name);
                                        } ?>
									</span>

									<a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php echo eidmart_excerpt_char_course_title( $max_char ); ?></a>

						            <div class="pub-meta">
						                <span class="pub-author">
						                  <i class="fa fa-user-o"></i><?php the_author();?>
						                </span>
						                <span class="pub-date">
						                  <i class="fa fa-clock-o"></i><?php the_time('d M, Y');?>
						                </span>
						            </div>

								</div>
							</div>
						</div>  

	                    <?php 
			            
			            endwhile; wp_reset_postdata();
			            else:
			        
			            ?>                
			            
			            <h3><?php echo esc_attr__( 'No related blog.','eidmart' ); ?></h3>
			            
			            <?php endif; ?>   

	                </div>
	            </div>                      

	        </div>
	    </div>
	</div>
		
	<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('blog-related-product', 'eidmart_blog_related_item_shortcode');
//End Related Artilces

// Start contact page coding...
// *******************************************************************
function eidmart_page_contact_shortcode( $atts, $content = null ) {	
	
	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'desc'         => '',
				'form_title'   => '',
				'contact_form' => '',
			),
			$atts
		)
	);      

	ob_start();	// Output buffering	
	
	?>

	<div class="contact-section pt-190 pb-190">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="c-left-area">
						<div class="title-contact">							
							<?php if( $title ): ?><h2><?php echo esc_html( $title ); ?></h2><?php endif; ?>
							<?php if( $desc ): ?><p><?php echo wp_kses_post( $desc ); ?></p><?php endif; ?>
						</div>

						<?php 

						if( is_array( $atts['contact_adress'] ) ){
						foreach( $atts['contact_adress'] as $i => $item ): 

						$img = wp_get_attachment_image_src( $item->image_url,'full' );

						?>
						<div class="c-discript">
							<div class="c-icon">
								<img src="<?php echo esc_url( $img[0] ); ?>" alt="<?php echo esc_attr( $item->title ); ?>">
							</div>
							<div class="c-d-area">
								<h4><?php echo esc_html( $item->title ); ?></h4>
								<p><?php echo wp_kses_post( $item->adress ); ?></p>
							</div>
						</div>
						
						<?php endforeach; } ?>

					</div>
				</div>

				<div class="col-md-6">
					<div class="contact-form">
						<?php if( $form_title ): ?><h2><?php echo esc_html( $form_title ); ?></h2><?php endif; ?>
						<div id="contact">
							<?php echo do_shortcode( wp_kses_post( $contact_form ) ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- End contact -->



	<?php 
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode( 'eidmart_page_contact', 'eidmart_page_contact_shortcode' );

/**
 * Shortocde for displaying terms filter and results on page
 * 
 */
function eidmart_ajax_filter_product($atts) {

    $a = shortcode_atts( array(
        'menu-align'        => '',
        'menu-style'        => '',
        'menu_appear'       => '',
        'status'            => '',
        'column'            => '',

        'max_char'          => '35',
        'product_para_char' => '50',
        'author'            => '',
        'product_para'      => '',
        'category'          => '',
        'sale'              => '',
		'ratings'              => '',
		'love'              => '',
		'sales'              => '',
		'price_con'              => '',
        'pagination_switch' => '',
        'product_style' => '',

        'tax'               => 'download_category', // Taxonomy
        'terms'             => false, // Get specific taxonomy terms only
        'max-term'          => '',
        'term-id'           => '',
        'active'            => false, // Set active term by ID
        'per_page'          => 12, // How many posts per page,
        'pager'             => 'pager', // 'pager' to use numbered pagination || 'infscr' to use infinite scroll
    ), $atts );

    $result = NULL;
    $terms  = get_terms( $a['tax'], ['include' => $a['term-id'] ] );

    if (count($terms)) :
        ob_start(); ?>
            <div id="container-async" data-product_style="<?php echo esc_attr( $a['product_style'] ); ?>" data-paged="<?php echo esc_attr( $a['per_page'] ); ?>"  data-pagination_switch="<?php echo esc_attr( $a['pagination_switch'] ); ?>" data-para_char="<?php echo esc_attr( $a['product_para_char'] ); ?>" data-column="<?php echo esc_attr( $a['column'] ); ?>" data-max_char="<?php echo esc_attr( $a['max_char'] ); ?>" data-author="<?php echo esc_attr( $a['author'] ); ?>" data-product_para="<?php echo esc_attr( $a['product_para'] ); ?>" data-category="<?php echo esc_attr( $a['category'] ); ?>" data-sale="<?php echo esc_attr( $a['sale'] ); ?>" data-ratings="<?php echo esc_attr( $a['ratings'] ); ?>" data-love="<?php echo esc_attr( $a['love'] ); ?>" data-sales="<?php echo esc_attr( $a['sales'] ); ?>" data-price_con="<?php echo esc_attr( $a['price_con'] ); ?>" class="eidmart-ajax-filter">

                <div class="latest-product-title <?php  if ( $a['menu-style'] == 'on' ): echo "filter-btn-style "; endif; if ( $a['menu_appear'] != 'on' ): echo "menu-appear"; endif; ?>">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="latest-product-title-right <?php echo esc_attr( $a['menu-align'] ); ?>">
                                <div id="filters" class="course-menu">
                                    <ul class="nav-filter">
                                        <li>
                                            <a class="filter" href="#" data-filter="<?php echo esc_attr( $terms[0]->taxonomy ); ?>" data-term="all-terms" data-page="1">
                                                <?php esc_html_e( 'All', 'eidmart' ); ?>
                                            </a>
                                        </li>
                                        <?php 
                                        $i = 0;
                                        foreach ($terms as $term) :
                                        $i++;
                                        if( $i <= $a['max-term'] ):                                     
                                        ?>
                                            <li<?php if ($term->term_id == $a['active']) :?> class="active"<?php endif; ?>>
                                                <a class="filter" href="<?php echo get_term_link( $term, $term->taxonomy ); ?>" data-filter="<?php echo esc_attr( $term->taxonomy ); ?>" data-term="<?php echo esc_attr( $term->slug ); ?>" data-page="1">
                                                    <?php echo esc_html( $term->name ); ?>
                                                </a>
                                            </li>
                                        <?php 
                                        endif;
                                        endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ( $a['status'] == 'on' ): ?>
                    <div class="status"></div>
                <?php endif; ?>
                <div class="product-container row"></div>
                
                <?php if ( 'infscr' == $a['pager'] ) : ?>
					<nav class="pagination infscr-pager">
						<a href="#page-2" class="btn-small"><?php esc_html_e( 'Load More','eidmart' ); ?></a>
					</nav>
				<?php endif; ?>
            </div>
        
        <?php $result = ob_get_clean();
    endif;

    return $result;
}
add_shortcode( 'eidmart_ajax_filter', 'eidmart_ajax_filter_product');
