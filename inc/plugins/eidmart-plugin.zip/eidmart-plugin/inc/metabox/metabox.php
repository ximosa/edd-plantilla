<?php
/**
 * Metabox
 *
 * @package eidmart
 */

// Add the custom column to the Event
add_filter( 'manage_events_posts_columns', 'eidmart_event_add_custom_column' );
function eidmart_event_add_custom_column( $columns ) {
    
    $columns = array(
      'cb' => $columns['cb'],
      'name' => esc_html__( 'Event Name', 'eidmart' ),
      'schedule' => esc_html__( 'Schedule', 'eidmart' ),
      'vanue' => esc_html__( 'Vanue', 'eidmart' ),
      'time' => esc_html__( 'Time', 'eidmart' ),
      'featured' => esc_html__( 'Featured', 'eidmart' )   
    );

    return $columns;
}

// Add the data to the custom column event
add_action( 'manage_events_posts_custom_column' , 'eidmart_event_add_custom_column_data', 10, 2 );
function eidmart_event_add_custom_column_data( $column, $post_id ) {
    switch ( $column ) {
        case 'name' :
            the_title(); // the data that is displayed in the column 
        break;
        case 'schedule' :
            echo esc_html( get_post_meta( $post_id, 'dates', true )); // the data that is displayed in the column 
        break;
        case 'vanue' :
            echo esc_html( get_post_meta( $post_id, 'vanue', true )); // the data that is displayed in the column
            break;
        case 'time' :
            echo esc_html( get_post_meta( $post_id, 'start_time', true )); // the data that is displayed in the column
            echo " - ";
            echo esc_html( get_post_meta( $post_id, 'end_time', true )); // the data that is displayed in the column
            break;
        case 'featured' :
            if( get_post_meta( $post_id, 'featured-checkbox', true ) == 'yes' ):
                esc_html_e( 'Featured', 'eidmart' );
            endif;
            break;        
    }
}

// Add the custom column to the Job
add_filter( 'manage_jobs_posts_columns', 'eidmart_job_add_custom_column' );
function eidmart_job_add_custom_column( $columns ) {
    
    $columns = array(
      'cb' => $columns['cb'],
      'name' => esc_html__( 'Job Name', 'eidmart' ),
      'education' => esc_html__( 'Education', 'eidmart' ),
      'experience' => esc_html__( 'Experience', 'eidmart' ),
      'sallery' => esc_html__( 'Sallery', 'eidmart' ),
      'deadline' => esc_html__( 'Deadline', 'eidmart' ), 
      'job_type' => esc_html__( 'Job Type', 'eidmart' )   
    );

    return $columns;
}

// Add the data to the custom column event
add_action( 'manage_jobs_posts_custom_column' , 'eidmart_job_add_custom_column_data', 10, 2 );
function eidmart_job_add_custom_column_data( $column, $post_id ) {
    switch ( $column ) {
        case 'name' :
            the_title(); // the data that is displayed in the column 
        break;
        case 'education' :
            echo esc_html( get_post_meta( $post_id, 'education', true )); // the data that is displayed in the column 
        break;
        case 'experience' :
            echo esc_html( get_post_meta( $post_id, 'experience', true )); // the data that is displayed in the column
            break;
        case 'sallery' :
            echo esc_html( get_post_meta( $post_id, 'sallery', true )); // the data that is displayed in the column
            break;
        case 'deadline' :
            echo esc_html( get_post_meta( $post_id, 'deadline', true )); // the data that is displayed in the column
            break;  
        case 'job_type' :
            echo esc_html( get_post_meta( $post_id, 'job_type', true )); // the data that is displayed in the column
            break;       
    }
}

// ********************************************************************************************************************
// Event meta box
// ********************************************************************************************************************
function eidmart_event_meta_box(){
  add_meta_box(
    'event_meta_box',
    esc_html__( 'Event Information', 'eidmart' ),
    'eidmart_event_meta_box_output',
    'events',
    'normal',
    'high'
  );
}
add_action('add_meta_boxes','eidmart_event_meta_box');

function eidmart_event_meta_box_output( $post ){
  
  $dates = get_post_meta( $post->ID, 'dates', true ); 

  $vanue = get_post_meta( $post->ID, 'vanue', true );   
  $start_time = get_post_meta( $post->ID, 'start_time', true );   
  $end_time = get_post_meta( $post->ID, 'end_time', true ); 
  $price = get_post_meta( $post->ID, 'price', true );

  $btn_text = get_post_meta( $post->ID, 'btn_text', true );   
  $btn_url = get_post_meta( $post->ID, 'btn_url', true );   
  
  
  ?>
  <div class="backend-form">

    <label for="dates"><b> <?php esc_html_e('Event schedule','eidmart'); ?> </b></label>
    <input placeholder="<?php esc_attr_e( 'Date', 'eidmart' ); ?>"  class="metastyle mt-input" type="date" id="dates" name="dates" value="<?php if ($dates): echo esc_attr($dates); endif; ?>" />   
   
    <label for="vanue"><b> <?php esc_html_e('Event vanue','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="text" id="vanue" name="vanue" value="<?php if ($vanue): echo esc_attr($vanue); endif; ?>" />

    <label for="start_time"><b> <?php esc_html_e('Event time','eidmart'); ?> </b></label>
    <input placeholder="<?php esc_attr_e( 'Start time', 'eidmart' ); ?>" class="metastyle mt-input" type="text" id="start_time" name="start_time" value="<?php if ($start_time): echo esc_attr($start_time); endif; ?>" />
    <input placeholder="<?php esc_attr_e( 'End time', 'eidmart' ); ?>" class="metastyle mt-input" type="text" id="end_time" name="end_time" value="<?php if ($end_time): echo esc_attr($end_time); endif; ?>" />  
    
    <label for="fee"><b> <?php esc_html_e('Entry Fee','eidmart'); ?> </b></label>
    <input placeholder="<?php esc_attr_e( 'Entry Fee', 'eidmart' ); ?>" class="metastyle mt-input" type="text" id="price" name="price" value="<?php if ($price): echo esc_attr($price); endif; ?>" />  
  
    <label for="btntxt"><b> <?php esc_html_e('Ticket Button Text','eidmart'); ?> </b></label>
    <input placeholder="<?php esc_attr_e( 'Ticket Button Text', 'eidmart' ); ?>" class="metastyle mt-input" type="text" id="btn_text" name="btn_text" value="<?php if ($btn_text): echo esc_attr($btn_text); endif; ?>" />  
  
    <label for="btn_url"><b> <?php esc_html_e('Buy Ticket Link','eidmart'); ?> </b></label>
    <input placeholder="<?php esc_attr_e( 'Buy Ticket Link', 'eidmart' ); ?>" class="metastyle mt-input" type="text" id="btn_url" name="btn_url" value="<?php if ($btn_url): echo esc_attr($btn_url); endif; ?>" />  
  
  </div>  
  <?php
}

function eidmart_event_database( $post_id ){
  
  if (isset($_POST['dates'])) {
    update_post_meta($post_id,'dates', sanitize_text_field($_POST['dates']));
    update_post_meta($post_id,'vanue', sanitize_text_field($_POST['vanue'])); 
    update_post_meta($post_id,'start_time', sanitize_text_field($_POST['start_time'])); 
    update_post_meta($post_id,'end_time', sanitize_text_field($_POST['end_time'])); 
    update_post_meta($post_id,'price', sanitize_text_field($_POST['price'])); 
    update_post_meta($post_id,'btn_text', sanitize_text_field($_POST['btn_text'])); 
    update_post_meta($post_id,'btn_url', sanitize_text_field($_POST['btn_url'])); 
  }
}
add_action('save_post','eidmart_event_database');

// ********************************************************************************************************************
// Featured event meta box
// ********************************************************************************************************************
function eidmart_event_featured_meta() {
    add_meta_box( 
        'eidmart_event_meta', 
        esc_html__( 'Featured Post', 'eidmart' ), 
        'eidmart_event_meta_callback', 
        'post', 
        'side', 
        'high' 
    );
}
add_action( 'add_meta_boxes', 'eidmart_event_featured_meta' );

/**
 * Outputs the content of the meta box
 */

function eidmart_event_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'eidmart_event_nonce' );
    $is_featured = get_post_meta( $post->ID, 'is_featured', true );
    $checked = $is_featured == 1 ? 'checked' : '';
    ?>

    <p><?php esc_html_e( 'Check if this is a featured post ', 'eidmart' )?></p>
    <p>
        <label for="is_featured">
            <input type="checkbox" name="is_featured" id="is_featured" value="1" <?php echo esc_html( $checked ); ?> />
            <?php esc_html_e( 'Featured Item', 'eidmart' )?>
        </label>
    </p>   

    <?php
}

/**
 * Saves the custom meta input
 */
function eidmart_event_meta_save( $post_id ) {

    // Checks save status - overcome autosave, etc.
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'eidmart_event_nonce' ] ) && wp_verify_nonce( $_POST[ 'eidmart_event_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

    // Checks for input and saves - save checked as yes and unchecked at no
    if( isset( $_POST[ 'is_featured' ] ) ) {
        update_post_meta( $post_id, 'is_featured', '1' );
    } else {
        update_post_meta( $post_id, 'is_featured', '0' );
    }

}
add_action( 'save_post', 'eidmart_event_meta_save' );

// *******************************************************************************************************************
// Job meta box
// *******************************************************************************************************************
function eidmart_job_meta_box(){
  add_meta_box(
    'job_meta_box',
    esc_html__( 'Job Information', 'eidmart' ),
    'eidmart_job_meta_box_output',
    'jobs',
    'normal',        
    'high'
  );
}
add_action('add_meta_boxes','eidmart_job_meta_box');

function eidmart_job_meta_box_output( $post ){
  
  $location = get_post_meta( $post->ID, 'location', true ); 
  $job_name = get_post_meta( $post->ID, 'job_name', true );   
  $sallery = get_post_meta( $post->ID, 'sallery', true );   
  $education = get_post_meta( $post->ID, 'education', true );   
  $experience = get_post_meta( $post->ID, 'experience', true );   
  $deadline = get_post_meta( $post->ID, 'deadline', true );     
  $job_type = get_post_meta( $post->ID, 'job_type', true );     
  
  ?>

  <div class="backend-form">
    <label for="locations"><b> <?php esc_html_e('Job location','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="text" id="locations" name="location" value="<?php if ( $location ): echo esc_attr( $location ); endif; ?>" />

    <label for="job_names"><b> <?php esc_html_e('Job Name','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="text" id="job_names" name="job_name" value="<?php if ( $job_name ): echo esc_attr( $job_name ); endif; ?>" />   

    <label for="sallerys"><b> <?php esc_html_e('Sallery','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="text" id="sallerys" name="sallery" value="<?php if ( $sallery ): echo esc_attr( $sallery ); endif; ?>" /> 
        
    <label for="educations"><b> <?php esc_html_e('Education','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="text" id="educations" name="education" value="<?php if ( $education ): echo esc_attr( $education ); endif; ?>" /> 

    <label for="experiences"><b> <?php esc_html_e('Experience','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="text" id="experiences" name="experience" value="<?php if ( $experience ): echo esc_attr( $experience ); endif; ?>" /> 
    
    <label for="deadlines"><b> <?php esc_html_e('Deadline ','eidmart'); ?> </b></label>
    <input  class="metastyle mt-input" type="date" id="deadlines" name="deadline" value="<?php if ( $deadline ): echo esc_attr( $deadline ); endif; ?>" /> 
  
    <label for="job_types"><b> <?php esc_html_e('Job Type ','eidmart'); ?> </b></label>  
    <select name="job_type" class="metastyle mt-input">
    <?php 
    $interests = array( 'Full Time' => 'Full Time',  'Part Time' => 'Part Time' );
    foreach($interests as $k => $v) {
    ?>
       <option class="metastyle mt-input" value="<?php echo esc_attr( $k ); ?>" <?php if( $k = isset( $_POST['job_type'] ) ) { ?> selected="selected" <?php } ?>> <?php echo esc_html( $v ); ?> </option>
    <?php
    }
    ?>
    </select>

  </div>
    
  <?php
}

function eidmart_job_database( $post_id ){
  
  if (isset( $_POST['location'] )) {
    update_post_meta( $post_id,'location', sanitize_text_field( $_POST['location']));
    update_post_meta( $post_id,'job_name', sanitize_text_field( $_POST['job_name'])); 
    update_post_meta( $post_id,'sallery', sanitize_text_field( $_POST['sallery'])); 
    update_post_meta( $post_id,'education', sanitize_text_field( $_POST['education'])); 
    update_post_meta( $post_id,'experience', sanitize_text_field( $_POST['experience'])); 
    update_post_meta( $post_id,'deadline', sanitize_text_field( $_POST['deadline'])); 
    update_post_meta( $post_id,'job_type', sanitize_text_field( $_POST['job_type'])); 
  }
}
add_action('save_post','eidmart_job_database');

// ********************************************************************************************************************
// Logo Image metabox
// ********************************************************************************************************************
function eidmart_gallery_metabox_enqueue( $hook ) {
  if ( 'post.php' == $hook || 'post-new.php' == $hook ) {
    wp_enqueue_script('eidmart-metabox-js', plugin_dir_url( __FILE__ ) . 'js/gallery-metabox.js', array('jquery'), time(), true );
    wp_enqueue_style('eidmart-metabox-style', plugin_dir_url( __FILE__ ) . 'css/gallery-metabox.css');
  }
}
add_action('admin_enqueue_scripts', 'eidmart_gallery_metabox_enqueue');


function eidmart_add_gallery_metabox($post_type) {
  $types = array( 'download' );
  if (in_array($post_type, $types)) {
    add_meta_box(
      'gallery-metabox',
      esc_html__( 'Product Logo', 'eidmart' ),
      'eidmart_gallery_meta_callback',
      $post_type,
      'normal',
      'high'
    );
  }
}
add_action('add_meta_boxes', 'eidmart_add_gallery_metabox');


function eidmart_gallery_meta_callback($post) {

  wp_nonce_field( basename(__FILE__), 'product_logo_nonce' );

  $image_id = esc_attr(get_post_meta($post->ID,'product_logo_img_id',true));
  $image_url = esc_attr(get_post_meta($post->ID,'product_logo_img_url',true));

  ?>
  <table class="form-table">
    <tr><td>
      
      <label><?php _e( 'Images', 'eidmart' ); ?></label>
      <input type="hidden" name="product_logo_img_id" id="product_logo_img_id" value="<?php echo $image_id; ?>"/>
      <input type="hidden" name="product_logo_img_url" id="product_logo_img_url" value="<?php echo $image_url; ?>"/>
      <div id="logo_display"></div>
      <button class="gallery-add button" id="upload_image"><?php _e( 'Upload Image', 'eidmart' ); ?></button>
      <button class="button" id="remove_image_single" ><?php _e( 'Remove Image', 'eidmart' ); ?></button>
    
    </td></tr>
  </table>

<?php }

function eidmart_gallery_meta_save($post_id) {
    if (!isset($_POST['product_logo_nonce']) || !wp_verify_nonce($_POST['product_logo_nonce'], basename(__FILE__))) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if( isset($_POST['product_logo_img_id']) && isset($_POST['product_logo_img_url']) ) {
      update_post_meta($post_id, 'product_logo_img_id', $_POST['product_logo_img_id']);
      update_post_meta($post_id, 'product_logo_img_url', $_POST['product_logo_img_url']);
    } else {
      delete_post_meta($post_id, 'product_logo_img_id');
      delete_post_meta($post_id, 'product_logo_img_url');
    }
}
add_action('save_post', 'eidmart_gallery_meta_save');

// ********************************************************************************************************************
// Gallery Image metabox
// ********************************************************************************************************************
function eidmart_add_product_gallery_metabox($post_type) {
  $types = array( 'download' );
  if (in_array($post_type, $types)) {
    add_meta_box(
      'product-gallery-metabox',
      esc_html__( 'Product Image Gallery', 'eidmart' ),
      'eidmart_product_gallery_meta_callback',
      $post_type,
      'normal',
      'high'
    );
  }
}
add_action('add_meta_boxes', 'eidmart_add_product_gallery_metabox');


function eidmart_product_gallery_meta_callback($post) {

  wp_nonce_field( basename(__FILE__), 'product_gallery_nonce' );

  $image_id = esc_attr(get_post_meta($post->ID,'product_gallery_img_id',true));
  $image_url = esc_attr(get_post_meta($post->ID,'product_gallery_img_url',true));

  ?>
  <table class="form-table">
    <tr><td>
      
      <label>Product Gallery</label>
      <input type="hidden" name="product_gallery_img_id" id="product_gallery_img_id" value="<?php echo $image_id; ?>"/>
      <input type="hidden" name="product_gallery_img_url" id="product_gallery_img_url" value="<?php echo $image_url; ?>"/>
      <div id="gallery_display"></div>
      <button class="gallery-add button" id="upload_gallery_image">Upload Image</button>
      <button class="button" id="remove_image_multi" >Remove Image</button>
    </td></tr>
  </table>

<?php }

function eidmart_product_gallery_meta_save($post_id) {
    if (!isset($_POST['product_gallery_nonce']) || !wp_verify_nonce($_POST['product_gallery_nonce'], basename(__FILE__))) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if( isset($_POST['product_gallery_img_id']) && isset($_POST['product_gallery_img_url']) ) {
      update_post_meta($post_id, 'product_gallery_img_id', $_POST['product_gallery_img_id']);
      update_post_meta($post_id, 'product_gallery_img_url', $_POST['product_gallery_img_url']);
    } else {
      delete_post_meta($post_id, 'product_gallery_img_id');
      delete_post_meta($post_id, 'product_gallery_img_url');
    }
}
add_action('save_post', 'eidmart_product_gallery_meta_save');


// ********************************************************************************************************************
// Adding the metaboxes for single product feature
// ********************************************************************************************************************

function eidmart_product_feature_metabox() {
    add_meta_box(
        'eidmart_feature_feature',
        __( 'Item Features', 'eidmart' ),
        'eidmart_product_feature_metabox_output',
        'download',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'eidmart_product_feature_metabox' );


function eidmart_product_feature_metabox_output() {

    global $post;
    // Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'feature_nonce' );

    // Use nonce for faq verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'faqs_nonce' );

    $request_text = get_post_meta( $post->ID, 'request_text', true );   
    $request_form = get_post_meta( $post->ID, 'request_form', true );

    $cart_bt_url = get_post_meta( $post->ID, 'cart_bt_url', true ); 

    $preview_text = get_post_meta( $post->ID, 'preview_text', true );   
    $preview_url = get_post_meta( $post->ID, 'preview_url', true ); 

    $doc_text = get_post_meta( $post->ID, 'doc_text', true );   
    $doc_url = get_post_meta( $post->ID, 'doc_url', true );  

    $purchase_text = get_post_meta( $post->ID, 'purchase_text', true );     
    $purchase_url = get_post_meta( $post->ID, 'purchase_url', true );   
    //Obtaining the linked feature_features meta values
    $_feature_details = get_post_meta( $post->ID,'_feature_details',true );

    //Obtaining the faqs meta values
    $_faqs_details = get_post_meta( $post->ID,'_faqs_details',true );

    $meta = get_post_meta( $post->ID );
    $ex_dwonload_url = ( isset( $meta['ex_dwonload_url'][0] ) && '' !== $meta['ex_dwonload_url'][0] ) ? $meta['ex_dwonload_url'][0] : '';

    $download_item_id = esc_attr(get_post_meta($post->ID,'download_item_id',true));
    $download_item_url = esc_attr(get_post_meta($post->ID,'download_item_url',true));

    ?>
    <div class="backend-form">

        <label for="preview_texts"><b> <?php esc_html_e( 'Preview Button Text','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="preview_texts" name="preview_text" value="<?php if ( $preview_text ): echo esc_attr( $preview_text ); endif; ?>" />     

        <label for="preview_urls"><b> <?php esc_html_e( 'Preview Button Link','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="preview_urls" name="preview_url" value="<?php if ( $preview_url ): echo esc_attr( $preview_url ); endif; ?>" />            
        <hr>
        <label for="doc_texts"><b> <?php esc_html_e( 'Documentation Button Text','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="doc_texts" name="doc_text" value="<?php if ( $doc_text ): echo esc_attr( $doc_text ); endif; ?>" />     

        <label for="doc_urls"><b> <?php esc_html_e( 'Documentation Button Link','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="doc_urls" name="doc_url" value="<?php if ( $doc_url ): echo esc_attr( $doc_url ); endif; ?>" />            
        <hr>
        <label for="purchase_text"><b> <?php esc_html_e( 'External Purchase/ Quick Cart / Free Download Button Text','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="purchase_texts" name="purchase_text" value="<?php if ( $purchase_text ): echo esc_attr( $purchase_text ); endif; ?>" />     

        <label for="purchase_urls"><b> <?php esc_html_e( 'External Purchase Button Link','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="purchase_urls" name="purchase_url" value="<?php if ( $purchase_url ): echo esc_attr( $purchase_url ); endif; ?>" />     
        
        <hr>
        <label for="download_item_url"><b> <?php esc_html_e( 'Quick Cart / Free Download Url','eidmart' ); ?> </b></label>
        <p><?php esc_html_e( 'If you input the product URL in this field it\'ll override "External Purchase Button Link" field value.','eidmart' ); ?></p>
        <input  class="widefat" type="text" id="download_item_url" name="cart_bt_url" value="<?php if ( $cart_bt_url ): echo esc_attr( $cart_bt_url ); endif; ?>" />
        <input type="hidden" name="download_item_id" id="download_item_id" value="<?php echo esc_attr( $download_item_id ); ?>"/>
        <input type="hidden" name="download_item_url" id="download_item_url" value="<?php echo esc_attr( $download_item_url ); ?>"/>
        <button class="gallery-add button" id="upload_download_item"><?php _e( 'Upload Item', 'eidmart' ); ?></button>
        <button class="button" id="remove_download_item" ><?php _e( 'Remove Item', 'eidmart' ); ?></button>
        

        <p>
            <label class="edd-custom-price-option-section-title"><?php _e( 'Make this link direct downloadable', 'eidmart' ); ?></label>
            <br>
            <label>                    
                <input type="radio" name="ex_dwonload_url" value="download_yes" <?php checked( $ex_dwonload_url, 'download_yes' ); ?>>
                <?php esc_html_e( 'Yes', 'eidmart' ); ?>
            </label>
            <label>                    
                <input type="radio" name="ex_dwonload_url" value="download_no" <?php checked( $ex_dwonload_url, 'download_no' ); ?>>
                <?php esc_html_e( 'No', 'eidmart' ); ?>
            </label>                
        </p>

    </div>

    <!--*********************************************************Item features******************************-->
    <br><hr/>
    <h3><?php _e( 'Item Information', 'eidmart' ); ?></h3>
    <hr/>

    <div class="feature-feature">
      <?php
      
      $c = 0;
      if ( is_array($_feature_details)) {
          foreach( $_feature_details as $feature_feature ) {
              if (  isset( $feature_feature['name'] ) || isset( $feature_feature['feature_value'] ) ) {
                  printf( '

                      <p>

                      <b>'. esc_html__( 'Name', 'eidmart' ) .' </b> <input class="metastyle mt-input" type="text" name="_feature_details[%1$s][name]" value="%2$s" />  
                      <b>'. esc_html__( 'Value', 'eidmart' ) .' </b> <input name="_feature_details[%1$s][feature_value]" class="metastyle mt-input" value="%3$s" />
                      <a href="#" class="remove-package">%4$s</a>
                      
                      </p>', 

                      $c, 
                      $feature_feature['name'], 
                      $feature_feature['feature_value'],
                      'Remove' 
                  );                
                  $c = $c +1;
              }
          }
      }
    ?>   

    <!-- Item features -->
    <span id="output-package"></span>
    <a href="#" class="add_package"><?php esc_html_e( 'Add item information', 'eidmart' ); ?></a>

      <script>
      var $ =jQuery.noConflict();
      $(document).ready(function() {
          var count = <?php echo esc_html( $c ); ?>;

          $(".add_package").on('click',function(e) {
              e.preventDefault();

              $(this).animate({ opacity: 1 }, 200, function() {
                  count = count + 1;
                  $('#output-package').append('<p> <b> <?php esc_html_e( 'Name ', 'eidmart' ) ?><input class="metastyle mt-input" type="text" name="_feature_details['+count+'][name]" value=""/>       <b><?php esc_html_e( 'Value ', 'eidmart' ) ?> </b> <input name="_feature_details['+count+'][feature_value]" class="metastyle mt-input" >  <a href="#" class="remove-package"><?php echo esc_html__( 'Remove', 'eidmart' ); ?></a> </p>' );
                  return false;
              });

          });
          $(document.body).on('click','.remove-package', function(e) {
              e.preventDefault();            
              $(this).animate({ opacity: 0 }, 200, function() {
                $(this).parent().remove();
              });
          });
      });
      </script>

    </div>

    <!--*********************************************************Faqs details******************************-->
    <br><hr/>
    <h3><?php _e( 'Item Faqs', 'eidmart' ); ?></h3>
    <hr/>

    <div class="backend-form">

        <label for="request_texts"><b> <?php esc_html_e( 'Request Button Text','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="request_texts" name="request_text" value="<?php if ( $request_text ): echo esc_attr( $request_text ); endif; ?>" />     

        <label for="request_forms"><b> <?php esc_html_e( 'Request Form Shortcode','eidmart' ); ?> </b></label>
        <input  class="widefat" type="text" id="request_forms" name="request_form" value="<?php if ( $request_form ): echo esc_attr( $request_form ); endif; ?>" />     

    </div>

    <div class="feature-feature">
      <?php
      
      $c = 0;
      if ( is_array($_faqs_details)) {
          foreach( $_faqs_details as $faqs_details ) {
              if (  isset( $faqs_details['name'] ) || isset( $faqs_details['feature_value'] ) ) {
                  printf( '

                      <p>

                      <b>'. esc_html__( 'Title', 'eidmart' ) .' </b> <input class="metastyle mt-input" type="text" name="_faqs_details[%1$s][name]" value="%2$s" />  
                      <b>'. esc_html__( 'Description', 'eidmart' ) .' </b> <textarea name="_faqs_details[%1$s][feature_value]" class="metastyle mt-input" rows="4" cols="50">%3$s</textarea>
                      <a href="#" class="remove-package1">%4$s</a>
                      
                      </p>', 

                      $c, 
                      $faqs_details['name'], 
                      $faqs_details['feature_value'],
                      'Remove' 
                  );                
                  $c = $c +1;
              }
          }
      }
    ?>   

    <!-- Item faqs -->
    <span id="output-package1"></span>
    <a href="#" class="add_package1"><?php esc_html_e( 'Add Item Faqs', 'eidmart' ); ?></a>

      <script>
      var $ =jQuery.noConflict();
      $(document).ready(function() {
          var count = <?php echo esc_html( $c ); ?>;

          $(".add_package1").on('click',function(e) {
              e.preventDefault();

              $(this).animate({ opacity: 1 }, 200, function() {
                  count = count + 1;
                  $('#output-package1').append('<p> <b> <?php esc_html_e( 'Title ', 'eidmart' ) ?><input class="metastyle mt-input" type="text" name="_faqs_details['+count+'][name]" value=""/>       <b><?php esc_html_e( 'Description ', 'eidmart' ) ?> </b> <textarea name="_faqs_details['+count+'][feature_value]" class="metastyle mt-input"></textarea>  <a href="#" class="remove-package1"><?php echo esc_html__( 'Remove', 'eidmart' ); ?></a> </p>' );
                  return false;
              });

          });
          $(document.body).on('click','.remove-package1', function(e) {
              e.preventDefault();            
              $(this).animate({ opacity: 0 }, 200, function() {
                $(this).parent().remove();
              });
          });
      });
      </script>

    </div>

<?php

}

function eidmart_product_feature_metabox_save( $post_id ) {        
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
        return;
    // Verifying the nonce
    if ( !isset( $_POST['feature_nonce'] ) )
        return;
    if ( !wp_verify_nonce( $_POST['feature_nonce'], plugin_basename( __FILE__ ) ) )
        return; 

    // Verifying the nonce
    if ( !isset( $_POST['faqs_nonce'] ) )
        return;
    if ( !wp_verify_nonce( $_POST['faqs_nonce'], plugin_basename( __FILE__ ) ) )
        return;  

    update_post_meta( $post_id,'request_text', sanitize_text_field( $_POST['request_text']) );            
    update_post_meta( $post_id,'request_form', sanitize_text_field( $_POST['request_form']) ); 
    
    update_post_meta( $post_id,'cart_bt_url', sanitize_text_field( $_POST['cart_bt_url']) ); 
               
    update_post_meta( $post_id,'preview_text', sanitize_text_field( $_POST['preview_text']) );            
    update_post_meta( $post_id,'preview_url', sanitize_text_field( $_POST['preview_url']) );            
    update_post_meta( $post_id,'doc_text', sanitize_text_field( $_POST['doc_text']) );            
    update_post_meta( $post_id,'doc_url', sanitize_text_field( $_POST['doc_url']) );            
    update_post_meta( $post_id,'purchase_text', sanitize_text_field( $_POST['purchase_text']) );            
    update_post_meta( $post_id,'purchase_url', sanitize_text_field( $_POST['purchase_url']) );            

    // Updating the _feature_details meta data
    $_feature_details = $_POST['_feature_details'];
    update_post_meta( $post_id,'_feature_details',$_feature_details );

    // Updating the faqs details meta data
    $_faqs_details = $_POST['_faqs_details'];
    update_post_meta( $post_id,'_faqs_details',$_faqs_details );

    if ( isset( $_POST['ex_dwonload_url'] ) ) { // Input var okay.
        update_post_meta( $post_id, 'ex_dwonload_url', sanitize_text_field( wp_unslash( $_POST['ex_dwonload_url'] ) ) ); // Input var okay.
    }

    if( isset($_POST['download_item_id']) && isset($_POST['download_item_url']) ) {
        update_post_meta($post_id, 'download_item_id', $_POST['download_item_id']);
        update_post_meta($post_id, 'download_item_url', $_POST['download_item_url']);
    } else {
        delete_post_meta($post_id, 'download_item_id');
        delete_post_meta($post_id, 'download_item_url');
    }

}
add_action( 'save_post', 'eidmart_product_feature_metabox_save' );


// ********************************************************************************************************************
// Prerequisites
// ********************************************************************************************************************

add_action( 'add_meta_boxes', 'eidmart_add_meta_box' );
 
if ( ! function_exists( 'eidmart_add_meta_box' ) ) {
    /**
     * Add meta box to page screen
     *
     * This function handles the addition of variuos meta boxes to your page or post screens.
     * You can add as many meta boxes as you want, but as a rule of thumb it's better to add
     * only what you need. If you can logically fit everything in a single metabox then add
     * it in a single meta box, rather than putting each control in a separate meta box.
     *
     * @since 1.0.0
     */
    function eidmart_add_meta_box() {
        add_meta_box( 
            'additional-page-metabox-options', 
            esc_html__( 'Settings', 'eidmart' ), 
            'eidmart_metabox_controls', 
            'download', 
            'normal', 
            'high' 
        );
    }
}

// Adding the control
if ( ! function_exists( 'eidmart_metabox_controls' ) ) {
    /**
     * Meta box render function
     *
     * @param  object $post Post object.
     * @since  1.0.0
     */
    function eidmart_metabox_controls( $post ) {

        $meta = get_post_meta( $post->ID );

        $related_product = ( isset( $meta['related_product'][0] ) && '' !== $meta['related_product'][0] ) ? $meta['related_product'][0] : '';
        $product_name = ( isset( $meta['product_name'][0] ) && '' !== $meta['product_name'][0] ) ? $meta['product_name'][0] : '';
        $purchase_btn_text = ( isset( $meta['purchase_btn_text'][0] ) && '' !== $meta['purchase_btn_text'][0] ) ? $meta['purchase_btn_text'][0] : '';
        $plan_name = ( isset( $meta['plan_name'][0] ) && '' !== $meta['plan_name'][0] ) ? $meta['plan_name'][0] : '';
        $product_number = ( isset( $meta['product_number'][0] ) && '' !== $meta['product_number'][0] ) ? $meta['product_number'][0] : '';
        $purchase_plan_btn_text = ( isset( $meta['purchase_plan_btn_text'][0] ) && '' !== $meta['purchase_plan_btn_text'][0] ) ? $meta['purchase_plan_btn_text'][0] : '';
        $purchase_plan_btn_id = ( isset( $meta['purchase_plan_btn_id'][0] ) && '' !== $meta['purchase_plan_btn_id'][0] ) ? $meta['purchase_plan_btn_id'][0] : '';

        $eidmart_radio_value = ( isset( $meta['eidmart_radio_value'][0] ) && '' !== $meta['eidmart_radio_value'][0] ) ? $meta['eidmart_radio_value'][0] : '';
        $eidmart_radio_value1 = ( isset( $meta['eidmart_radio_value1'][0] ) && '' !== $meta['eidmart_radio_value1'][0] ) ? $meta['eidmart_radio_value1'][0] : '';
        $eidmart_radio_value2 = ( isset( $meta['eidmart_radio_value2'][0] ) && '' !== $meta['eidmart_radio_value2'][0] ) ? $meta['eidmart_radio_value2'][0] : '';
        $eidmart_radio_value3 = ( isset( $meta['eidmart_radio_value3'][0] ) && '' !== $meta['eidmart_radio_value3'][0] ) ? $meta['eidmart_radio_value3'][0] : '';
        $eidmart_radio_value4 = ( isset( $meta['eidmart_radio_value4'][0] ) && '' !== $meta['eidmart_radio_value4'][0] ) ? $meta['eidmart_radio_value4'][0] : '';
        $eidmart_radio_value5 = ( isset( $meta['eidmart_radio_value5'][0] ) && '' !== $meta['eidmart_radio_value5'][0] ) ? $meta['eidmart_radio_value5'][0] : '';
        $eidmart_radio_value6 = ( isset( $meta['eidmart_radio_value6'][0] ) && '' !== $meta['eidmart_radio_value6'][0] ) ? $meta['eidmart_radio_value6'][0] : '';
        
        wp_nonce_field( 'eidmart_control_meta_box', 'eidmart_control_meta_box_nonce' ); // Add nonce to meta boxes!
        ?>
        
        <!--*********************************************************Product layout******************************-->
        <h3><?php _e( 'Select Item Layout', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_1" <?php checked( $eidmart_radio_value, 'value_1' ); ?> checked>
                    <?php esc_html_e( 'General', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_p3" <?php checked( $eidmart_radio_value, 'value_p3' ); ?>>
                    <?php esc_html_e( 'Landing', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_2" <?php checked( $eidmart_radio_value, 'value_2' ); ?>>
                    <?php esc_html_e( 'Photography General', 'eidmart' ); ?>
                </label> 
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_3" <?php checked( $eidmart_radio_value, 'value_3' ); ?>>
                    <?php esc_html_e( 'Graphicland General', 'eidmart' ); ?>
                </label> 
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_4" <?php checked( $eidmart_radio_value, 'value_4' ); ?>>
                    <?php esc_html_e( 'Graphicland Woo', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_5" <?php checked( $eidmart_radio_value, 'value_5' ); ?>>
                    <?php esc_html_e( 'Audio Single', 'eidmart' ); ?>
                </label><br><br>
                <label>                    
                    <input type="radio" name="eidmart_radio_value" value="value_6" <?php checked( $eidmart_radio_value, 'value_6' ); ?>>
                    <?php esc_html_e( 'Video Single', 'eidmart' ); ?>
                </label>

            </p>
        </div> 

        <!--*********************************************************Show hide sticky price******************************-->
        <br><hr/>
        <h3><?php _e( 'Price Settings', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label class="edd-custom-price-option-section-title"><?php _e( 'Show/Hide Sticky Price', 'eidmart' ); ?></label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value5" value="value_11" <?php checked( $eidmart_radio_value5, 'value_11' ); ?>>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value5" value="value_12" <?php checked( $eidmart_radio_value5, 'value_12' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                
            </p>
            <p><?php _e( 'Note: To hide sticky price from all products, Go to Dashboard -> Appearance -> Customize -> Eidmart Settings -> Product Single -> Stiky Price show/hide -> Published.', 'eidmart' ); ?></p>
            <p>
                <label class="edd-custom-price-option-section-title"><?php _e( 'Show/Hide Price Nav', 'eidmart' ); ?></label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value6" value="price_nav_show" <?php checked( $eidmart_radio_value6, 'price_nav_show' ); ?>>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value6" value="price_nav_hide" <?php checked( $eidmart_radio_value6, 'price_nav_hide' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                
            </p>
            <p>
                <label for="product-name"><b> <?php esc_html_e( 'Product Name Ex: Eidmart Pro','eidmart' ); ?> </b></label>
                <input  class="widefat" type="text" id="product-name" name="product_name" value="<?php if ( $product_name ): echo esc_attr( $product_name ); endif; ?>" /> 
            </p>
            <p>
                <label for="product-button-text"><b> <?php esc_html_e( 'Change Product Purchase Button Text Ex: Get It Now', 'eidmart' ); ?> </b></label>
                <input  class="widefat" type="text" id="product-button-text" name="purchase_btn_text" value="<?php if ( $purchase_btn_text ): echo esc_attr( $purchase_btn_text ); endif; ?>" /> 
            </p>
            <p>
                <label for="plan-name"><b> <?php esc_html_e( 'Plan Name Ex: All Themes Plan','eidmart' ); ?> </b></label>
                <input  class="widefat" type="text" id="plan-name" name="plan_name" value="<?php if ( $plan_name ): echo esc_attr( $plan_name ); endif; ?>" /> 
            </p>
            <p>
                <label for="product-number"><b> <?php esc_html_e( 'Product Number in Plan Ex: 30 Premium Themes','eidmart' ); ?> </b></label>
                <input  class="widefat" type="text" id="product-number" name="product_number" value="<?php if ( $product_number ): echo esc_attr( $product_number ); endif; ?>" /> 
            </p>
            <p>
                <label for="plan-button-text"><b> <?php esc_html_e( 'Change Plan Purchase Button Text Ex: Get It Now','eidmart' ); ?> </b></label>
                <input  class="widefat" type="text" id="plan-button-text" name="purchase_plan_btn_text" value="<?php if ( $purchase_plan_btn_text ): echo esc_attr( $purchase_plan_btn_text ); endif; ?>" /> 
            </p>
            <p>
                <label for="plan-id"><b> <?php esc_html_e( 'Plan Purchase Button ID','eidmart' ); ?> </b></label>
                <input  class="widefat" type="text" id="plan-id" name="purchase_plan_btn_id" value="<?php if ( $purchase_plan_btn_id ): echo esc_attr( $purchase_plan_btn_id ); endif; ?>" /> 
            </p>
        </div> 

        <!--*********************************************************Show hide purchase and comment section******************************-->
        <br><hr/>
        <h3><?php _e( 'Show/Hide Purchase & Comment Section', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label>                    
                    <input type="radio" name="eidmart_radio_value1" value="value_3" <?php checked( $eidmart_radio_value1, 'value_3' ); ?>>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value1" value="value_4" <?php checked( $eidmart_radio_value1, 'value_4' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                
            </p>
            <p><?php _e( 'Note: To hide comments and purchases from all products, Go to Dashboard -> Appearance -> Customize -> Eidmart Settings -> Product Single -> Purchase & Comment Universally show/hide -> Published.', 'eidmart' ); ?></p>
        </div> 

        <!--*********************************************************Show hide Item Nav Tab Menu section******************************-->
        <br><hr/>
        <h3><?php _e( 'Show/Hide Item Nav Tab Menu', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label>                    
                    <input type="radio" name="eidmart_radio_value3" value="value_7" <?php checked( $eidmart_radio_value3, 'value_7' ); ?>>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value3" value="value_8" <?php checked( $eidmart_radio_value3, 'value_8' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                
            </p>
        </div>

        <!--*********************************************************Show hide Item Review section******************************-->
        <br><hr/>
        <h3><?php _e( 'Show/Hide Item Review', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label>                    
                    <input type="radio" name="eidmart_radio_value4" value="value_9" <?php checked( $eidmart_radio_value4, 'value_9' ); ?>>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value4" value="value_10" <?php checked( $eidmart_radio_value4, 'value_10' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                
            </p>
            <p><?php _e( 'Note: To hide reviews from all products, Just uninstall the "EDD Reviews" plugin.', 'eidmart' ); ?></p>
        </div>

        <!--*********************************************************Show hide related item section******************************-->
        <br><hr/>
        <h3><?php _e( 'Show/Hide Related Item Section', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">  
            <p>
                <label>                    
                    <input type="radio" name="eidmart_radio_value2" value="value_5" <?php checked( $eidmart_radio_value2, 'value_5' ); ?>>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="eidmart_radio_value2" value="value_6" <?php checked( $eidmart_radio_value2, 'value_6' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                 
            </p>
            <label for="related_products"><b> <?php esc_html_e( 'Related Product Shortcode Ex: [related-product title="hello" author="on" category="on" sale="on" max_char="35"]','eidmart' ); ?> </b></label>
            <input  class="widefat" type="text" id="related_products" name="related_product" value="<?php if ( $related_product ): echo esc_attr( $related_product ); endif; ?>" /> 
        </div> 

    <?php
    }
}

// Saving meta box
add_action( 'save_post', 'eidmart_save_metaboxes' );
 
if ( ! function_exists( 'eidmart_save_metaboxes' ) ) {
    /**
     * Save controls from the meta boxes
     *
     * @param  int $post_id Current post id.
     * @since 1.0.0
     */
    function eidmart_save_metaboxes( $post_id ) {
        /*
         * We need to verify this came from the our screen and with proper authorization,
         * because save_post can be triggered at other times. Add as many nonces, as you
         * have metaboxes.
         */
        if ( ! isset( $_POST['eidmart_control_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['eidmart_control_meta_box_nonce'] ), 'eidmart_control_meta_box' ) ) { // Input var okay.
            return $post_id;
        }
 
        // Check the user's permissions.
        if ( isset( $_POST['post_type'] ) && 'page' === $_POST['post_type'] ) { // Input var okay.
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return $post_id;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return $post_id;
            }
        }
 
        /*
         * If this is an autosave, our form has not been submitted,
         * so we don't want to do anything.
         */
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }
 
        /* Ok to save */ 
 
        if ( isset( $_POST['eidmart_radio_value'] ) || isset( $_POST['eidmart_radio_value1'] ) || isset( $_POST['eidmart_radio_value2'] ) || isset( $_POST['eidmart_radio_value3'] ) || isset( $_POST['eidmart_radio_value4'] ) || isset( $_POST['eidmart_radio_value5'] ) || isset( $_POST['eidmart_radio_value6'] ) ) { // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value'] ) ) ); // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value1', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value1'] ) ) ); // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value2', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value2'] ) ) ); // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value3', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value3'] ) ) ); // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value4', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value4'] ) ) ); // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value5', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value5'] ) ) ); // Input var okay.
            update_post_meta( $post_id, 'eidmart_radio_value6', sanitize_text_field( wp_unslash( $_POST['eidmart_radio_value6'] ) ) ); // Input var okay.
        }
 
        update_post_meta( $post_id,'related_product', sanitize_text_field( $_POST['related_product']) );
        update_post_meta( $post_id,'product_name', sanitize_text_field( $_POST['product_name']) );
        update_post_meta( $post_id,'purchase_btn_text', sanitize_text_field( $_POST['purchase_btn_text']) );
        update_post_meta( $post_id,'plan_name', sanitize_text_field( $_POST['plan_name']) );
        update_post_meta( $post_id,'product_number', sanitize_text_field( $_POST['product_number']) );
        update_post_meta( $post_id,'purchase_plan_btn_text', sanitize_text_field( $_POST['purchase_plan_btn_text']) );
        update_post_meta( $post_id,'purchase_plan_btn_id', sanitize_text_field( $_POST['purchase_plan_btn_id']) );
        
    }
}

// ********************************************************************************************************************
// Add user profile field
// ********************************************************************************************************************

function eidmart_contact_methods( $profile_fields ) {
    
    // Add new fields
    $profile_fields['twitter'] = esc_html__( 'Twitter Username', 'eidmart' );
    $profile_fields['facebook'] = esc_html__( 'Facebook URL', 'eidmart' );
    $profile_fields['dribbble'] = esc_html__( 'Dribbble', 'eidmart' );
    $profile_fields['linkedin'] = esc_html__( 'Linkedin', 'eidmart' );
    $profile_fields['github'] = esc_html__( 'Github', 'eidmart' );
    $profile_fields['behance'] = esc_html__( 'Behance', 'eidmart' );
    $profile_fields['instagram'] = esc_html__( 'instagram', 'eidmart' );
    $profile_fields['designation'] = esc_html__( 'User Designation', 'eidmart' );

    return $profile_fields;
}
add_filter( 'user_contactmethods', 'eidmart_contact_methods' );


// ********************************************************************************************************************
// Audio meta box
// ********************************************************************************************************************
function eidmart_audio_meta_box(){
	add_meta_box(
		'audio_meta_box',
		esc_html__( 'Audio Information', 'eidmart' ),
		'eidmart_audio_meta_box_output',
		'download',
		'side',
		'high'
	);
}
add_action('add_meta_boxes','eidmart_audio_meta_box');

function eidmart_audio_meta_box_output( $post ){

	$external_audio = get_post_meta( $post->ID, 'external_audio', true );   
	$artist = get_post_meta( $post->ID, 'artist', true );   
	
	$mp3_id = esc_attr(get_post_meta( $post->ID,'mp3_id',true ));
	$mp3_url = esc_attr(get_post_meta( $post->ID,'mp3_url',true ));

	
	?>
	<div class="backend-form">

		<table class="form-table">
			<tr>
				<td>        
					<label><?php esc_html_e( 'Upload MP3','eidmart' ); ?></label>
					<input type="hidden" name="mp3_id" id="mp3_id" value="<?php echo esc_attr( $mp3_id ); ?>"/>
					<input type="hidden" name="mp3_url" id="mp3_url" value="<?php echo esc_attr( $mp3_url ); ?>"/>
					<div id="mp3_display"></div>
					<button class="button" id="upload_mp3"><?php esc_html_e( 'Upload mp3','eidmart' ); ?></button>
					<button class="button" id="remove_mp3_single" ><?php esc_html_e( 'Remove mp3','eidmart' ); ?></button>                
				</td>
			</tr>
		</table>
        <p><?php esc_html_e( 'If you use this uploader then you have to blank the "External/Affiliate URL" field below.','eidmart' ); ?></p>

        <label for="external_audio"><b> <?php esc_html_e( 'Audio External/Affiliate URL','eidmart' ); ?> </b></label>
		<input  class="metastyle mt-input" type="text" id="external_audio" name="external_audio" value="<?php if ( $external_audio ): echo esc_attr( $external_audio ); endif; ?>" />
        
		<label for="artist"><b> <?php esc_html_e( 'Artist Name','eidmart' ); ?> </b></label>
		<input  class="metastyle mt-input" type="text" id="artist" name="artist" value="<?php if ( $artist ): echo esc_attr( $artist ); endif; ?>" />

	</div>  
	<?php
}

function eidmart_audio_database( $post_id ){
	
	if (isset($_POST['mp3_url'])) {

	update_post_meta( $post_id,'external_audio', sanitize_text_field( $_POST['external_audio'] )); 
	update_post_meta( $post_id,'artist', sanitize_text_field( $_POST['artist'] )); 
	
	update_post_meta( $post_id,'mp3_id', sanitize_text_field( $_POST['mp3_id'] )); 
	update_post_meta( $post_id,'mp3_url', sanitize_text_field( $_POST['mp3_url'] )); 
	}
}
add_action('save_post','eidmart_audio_database');


// ********************************************************************************************************************
// Video meta box
// ********************************************************************************************************************
function eidmart_video_meta_box(){
	add_meta_box(
		'video_meta_box',
		esc_html__( 'Video Information', 'eidmart' ),
		'eidmart_video_meta_box_output',
		'download',
		'side',
		'high'
	);
}
add_action('add_meta_boxes','eidmart_video_meta_box');

function eidmart_video_meta_box_output( $post ){

	$external_url = get_post_meta( $post->ID, 'external_url', true );   

	$mp4_id = esc_attr(get_post_meta( $post->ID,'mp4_id',true ));
	$mp4_url = esc_attr(get_post_meta( $post->ID,'mp4_url',true ));

    $meta = get_post_meta( $post->ID );
    $video_type = ( isset( $meta['video_type'][0] ) && '' !== $meta['video_type'][0] ) ? $meta['video_type'][0] : 1;  

	?>
	<div class="backend-form">

		<table class="form-table">
			<tr>
				<td>        
					<label><?php esc_html_e( 'Upload Video','eidmart' ); ?></label>
					<input type="hidden" name="mp4_id" id="mp4_id" value="<?php echo esc_attr( $mp4_id ); ?>"/>
					<input type="hidden" name="mp4_url" id="mp4_url" value="<?php echo esc_attr( $mp4_url ); ?>"/>
					<div id="mp4_display"></div>
					<button class="button" id="upload_mp4"><?php esc_html_e( 'Upload Video','eidmart' ); ?></button>
					<button class="button" id="remove_mp4_single" ><?php esc_html_e( 'Remove Video','eidmart' ); ?></button>                
				</td>
			</tr>
		</table>

		<label for="external_url"><b> <?php esc_html_e( 'Video External/Affiliate URL ( Use only video ID for Youtube )','eidmart' ); ?> </b></label>
		<input  class="metastyle mt-input" type="text" id="external_url" name="external_url" value="<?php if ( $external_url ): echo esc_attr( $external_url ); endif; ?>" />
        
        <input type="radio" name="video_type" value="1" <?php if( $video_type == 1 ): echo "checked"; endif; ?>>
        <?php esc_html_e( 'HTML5 Player', 'eidmart' ); ?>
                
        <input type="radio" name="video_type" value="2" <?php if( $video_type == 2 ): echo "checked"; endif; ?>>
        <?php esc_html_e( 'Youtube Player', 'eidmart' ); ?>        
        
	</div>  
<?php
}

function eidmart_video_database( $post_id ){

	if ( isset($_POST['mp4_url']) ) {

		update_post_meta( $post_id,'external_url', sanitize_text_field( $_POST['external_url'] )); 
		
		update_post_meta( $post_id,'mp4_id', sanitize_text_field( $_POST['mp4_id'] )); 
		update_post_meta( $post_id,'mp4_url', sanitize_text_field( $_POST['mp4_url'] )); 
        //update_post_meta( $post_id, 'video_type', sanitize_text_field( $_POST['video_type'] ) ); // Input var okay.   
        update_post_meta( $post_id, 'video_type', sanitize_text_field( wp_unslash( $_POST['video_type'] ) ) ); // Input var okay.
    }
}
add_action('save_post','eidmart_video_database');


// ********************************************************************************************************************
// Prerequisites for blog post
// ********************************************************************************************************************

add_action( 'add_meta_boxes', 'eidmart_add_blog_meta_box' );
 
if ( ! function_exists( 'eidmart_add_blog_meta_box' ) ) {
    /**
     * Add meta box to page screen
     *
     * This function handles the addition of variuos meta boxes to your page or post screens.
     * You can add as many meta boxes as you want, but as a rule of thumb it's better to add
     * only what you need. If you can logically fit everything in a single metabox then add
     * it in a single meta box, rather than putting each control in a separate meta box.
     *
     * @since 1.0.0
     */
    function eidmart_add_blog_meta_box() {
        add_meta_box( 
            'additional-post-metabox-options', 
            esc_html__( 'Settings', 'eidmart' ), 
            'eidmart_metabox_blog_controls', 
            'post', 
            'normal', 
            'high' 
        );
    }
}

// Adding the control
if ( ! function_exists( 'eidmart_metabox_blog_controls' ) ) {
    /**
     * Meta box render function
     *
     * @param  object $post Post object.
     * @since  1.0.0
     */
    function eidmart_metabox_blog_controls( $post ) {

        $meta = get_post_meta( $post->ID );
        
        $read_time = ( isset( $meta['read_time'][0] ) && '' !== $meta['read_time'][0] ) ? $meta['read_time'][0] : '';        
        $related_product = ( isset( $meta['related_product'][0] ) && '' !== $meta['related_product'][0] ) ? $meta['related_product'][0] : '';        
        $single_blog = ( isset( $meta['single_blog'][0] ) && '' !== $meta['single_blog'][0] ) ? $meta['single_blog'][0] : '';        
        $show_hide_related_post = ( isset( $meta['show_hide_related_post'][0] ) && '' !== $meta['show_hide_related_post'][0] ) ? $meta['show_hide_related_post'][0] : '';
        
        wp_nonce_field( 'eidmart_control_blog_meta_box', 'eidmart_control_blog_meta_box_nonce' ); // Always add nonce to your meta boxes!

        ?>
        
        <!--*********************************************************Product layout******************************-->
        <h3><?php _e( 'Select Item Layout', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label>                    
                    <input type="radio" name="single_blog" value="1" <?php checked( $single_blog, '1' ); ?> checked>
                    <?php esc_html_e( 'General', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="single_blog" value="2" <?php checked( $single_blog, '2' ); ?>>
                    <?php esc_html_e( 'Full Width', 'eidmart' ); ?>
                </label>
            </p>
        </div> 
        
        <!--*********************************************************Minimum read time******************************-->
        <br><hr/>
        <h3><?php _e( 'Minimum Read Time', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">
            
            <label for="read_times"><b> <?php esc_html_e( 'Minimum Post Reading Time','eidmart' ); ?> </b></label>
            <input  class="" type="text" id="read_times" name="read_time" value="<?php if ( $read_time ): echo esc_attr( $read_time ); endif; ?>" />     

        </div>

        <!--*********************************************************Show hide blog related item section******************************-->
        <br><hr/>
        <h3><?php _e( 'Show/Hide Related Item Section', 'eidmart' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">
            <p>
                <label>                    
                    <input type="radio" name="show_hide_related_post" value="1" <?php checked( $show_hide_related_post, '1' ); ?> checked>
                    <?php esc_html_e( 'Show', 'eidmart' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="show_hide_related_post" value="0" <?php checked( $show_hide_related_post, '0' ); ?>>
                    <?php esc_html_e( 'Hide', 'eidmart' ); ?>
                </label>                 
            </p>
            <label for="related_products"><b> <?php esc_html_e( 'Related Post Shortcode Ex: [blog-related-product title="Related Items" max_post="3" max_char="35"]','eidmart' ); ?> </b></label>
            <input  class="widefat" type="text" id="related_products" name="related_product" value="<?php if ( $related_product ): echo esc_attr( $related_product ); endif; ?>" />     

        </div> 

        <?php
    }
}

// Saving meta box
add_action( 'save_post', 'eidmart_save_post_metaboxes' );
 
if ( ! function_exists( 'eidmart_save_post_metaboxes' ) ) {
    /**
     * Save controls from the meta boxes
     *
     * @param  int $post_id Current post id.
     * @since 1.0.0
     */
    function eidmart_save_post_metaboxes( $post_id ) {
        /*
         * We need to verify this came from the our screen and with proper authorization,
         * because save_post can be triggered at other times. Add as many nonces, as you
         * have metaboxes.
         */
        if ( ! isset( $_POST['eidmart_control_blog_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['eidmart_control_blog_meta_box_nonce'] ), 'eidmart_control_blog_meta_box' ) ) { // Input var okay.
            return $post_id;
        }
 
        // Check the user's permissions.
        if ( isset( $_POST['post_type'] ) && 'page' === $_POST['post_type'] ) { // Input var okay.
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return $post_id;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return $post_id;
            }
        }
 
        /*
         * If this is an autosave, our form has not been submitted,
         * so we don't want to do anything.
         */
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }
 
        /* Ok to save */ 
 
        if ( isset( $_POST['single_blog'] ) || isset( $_POST['show_hide_related_post'] ) ) { // Input var okay.
            update_post_meta( $post_id, 'single_blog', sanitize_text_field( wp_unslash( $_POST['single_blog'] ) ) ); // Input var okay.            
            update_post_meta( $post_id, 'show_hide_related_post', sanitize_text_field( wp_unslash( $_POST['show_hide_related_post'] ) ) ); // Input var okay.

        }
 
        update_post_meta( $post_id,'related_product', sanitize_text_field( $_POST['related_product']) );
        update_post_meta( $post_id,'read_time', sanitize_text_field( $_POST['read_time']) );
        
    }
}

/*
function set_download_labels($labels) {
  $labels = array(
    'name' => _x('Products', 'post type general name', 'your-domain'),
    'singular_name' => _x('Product', 'post type singular name', 'your-domain'),
    'add_new' => __('Add New', 'your-domain'),
    'add_new_item' => __('Add New Product', 'your-domain'),
    'edit_item' => __('Edit Product', 'your-domain'),
    'new_item' => __('New Product', 'your-domain'),
    'all_items' => __('All Products', 'your-domain'),
    'view_item' => __('View Product', 'your-domain'),
    'search_items' => __('Search Products', 'your-domain'),
    'not_found' =>  __('No Products found', 'your-domain'),
    'not_found_in_trash' => __('No Products found in Trash', 'your-domain'), 
    'parent_item_colon' => '',
    'menu_name' => __('Products', 'your-domain'),
    'featured_image'        => __( '%1$s Image', 'easy-digital-downloads' ),
    'set_featured_image'    => __( 'Set %1$s Image', 'easy-digital-downloads' ),
    'remove_featured_image' => __( 'Remove %1$s Image', 'easy-digital-downloads' ),
    'use_featured_image'    => __( 'Use as %1$s Image', 'easy-digital-downloads' ),
  );
  return $labels;
}
add_filter('edd_download_labels', 'set_download_labels');

function pw_edd_product_labels( $labels ) {
  $labels = array(
     'singular' => __('Product', 'your-domain'),
     'plural'   => __('Products', 'your-domain')
  );
  return $labels;
}
add_filter('edd_default_downloads_name', 'pw_edd_product_labels');

if ( ! defined( 'EDD_SLUG' ) ) {
  define( 'EDD_SLUG', 'product' );
}



/**
 * If we make archive page as home page
 * We'll use this filter
 *
function eidmart_arc_front_page($wp_query){
    //Stop this filtering to the admin area
    if(is_admin()) {
        return;
    }

    if($wp_query->get('page_id') == get_option('page_on_front')):

        $wp_query->set('post_type', 'download');
        $wp_query->set('page_id', ''); //Empty

        //Set properties that describe the page to reflect that
        //we aren't really displaying a static page
        $wp_query->is_page = 0;
        $wp_query->is_singular = 0;
        $wp_query->is_post_type_archive = 1;
        $wp_query->is_archive = 1;

	endif;
	
	//Fix pagination
	if ( get_query_var('paged') ) {
		$paged = get_query_var('paged');
	} else if ( get_query_var('page') ) {
		$paged = get_query_var('page');
	} else {
		$paged = 1;
	}
	$wp_query->set( 'paged', $paged );
}
add_action('pre_get_posts', 'eidmart_arc_front_page');

*/

