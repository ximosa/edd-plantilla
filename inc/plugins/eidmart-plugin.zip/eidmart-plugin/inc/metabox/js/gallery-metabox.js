var frame, gframe;
(function ($) {

	$(document).ready(function () {
		// MP4 uploader
		var mp4_url = $("#mp4_url").val();
		if (mp4_url) {
			$("#mp4_display").html(`
				<video controls>
					<source src="${mp4_url}" type="video/mp4">
				</video>	 
			`);
		}

		$("#remove_mp4_single").on("click", function () {
			$("#mp4_id").val("");
			$("#mp4_url").val("");
			$("#mp4_display").html("");
			return false;
		});

		// MP3 uploader
		var mp3_url = $("#mp3_url").val();
		if (mp3_url) {
			$("#mp3_display").html(`
				<audio controls>
					<source src="${mp3_url}" type="audio/mpeg">
				</audio>	 
			`);
		}

		$("#remove_mp3_single").on("click", function () {
			$("#mp3_id").val("");
			$("#mp3_url").val("");
			$("#mp3_display").html("");
			return false;
		});

		// Download item uploader
		var image_url = $("#download_item_url").val();

		$("#remove_download_item").on("click", function () {
			$("#download_item_id").val("");
			$("#download_item_url").val("");
			return false;
		});

		// Single logo uploader
		var image_url = $("#product_logo_img_url").val();
		if (image_url) {
			$("#logo_display").html(`<img src="${image_url}" />`);
		}

		$("#remove_image_single").on("click", function () {
			$("#product_logo_img_id").val("");
			$("#product_logo_img_url").val("");
			$("#logo_display").html("");
			return false;
		});

		// Multiple image ulpoader
		var gallery_url = $("#product_gallery_img_url").val();
		gallery_url = gallery_url ? gallery_url.split(";") : [];

		$("#gallery_display").html("");
		for (i in gallery_url) {
			var gallery_urls = gallery_url[i];
			$("#gallery_display").append(`<img src="${gallery_urls}" />`);
		}

		$("#remove_image_multi").on("click", function () {
			$("#product_gallery_img_id").val("");
			$("#product_gallery_img_url").val("");
			$("#gallery_display").html("");
			return false;
		});

		// MP4 uploader processing
		$("#upload_mp4").on("click", function () {
			if (frame) {
				frame.open();
				return false;
			}

			frame = wp.media({
				title: "Upload MP4 File",
				button: {
					text: "Upload MP4",
				},
				multiple: false,
			});

			frame.on("select", function () {
				var attachment = frame.state().get("selection").first().toJSON();
				$("#mp4_id").val(attachment.id);
				$("#mp4_url").val(attachment.url);
				$("#mp4_display").html(`		
					<video controls>
					<source src="${attachment.url}" type="video/mp4">
					</video>
				`);
			});

			frame.open();
			return false;
		});

		// MP3 uploader processing
		$("#upload_mp3").on("click", function () {
			if (frame) {
				frame.open();
				return false;
			}

			frame = wp.media({
				title: "Upload MP3 File",
				button: {
					text: "Upload MP3",
				},
				multiple: false,
			});

			frame.on("select", function () {
				var attachment = frame.state().get("selection").first().toJSON();
				$("#mp3_id").val(attachment.id);
				$("#mp3_url").val(attachment.url);
				$("#mp3_display").html(`		
				<audio controls>
					<source src="${attachment.url}" type="audio/mpeg">
				</audio>
				`);
			});

			frame.open();
			return false;
		});

		// Downloadable item uploader processing
		$("#upload_download_item").on("click", function () {
			if (frame) {
				frame.open();
				return false;
			}

			frame = wp.media({
				title: "Upload Product Logo",
				button: {
					text: "Insert Logo",
				},
				multiple: false,
			});

			frame.on("select", function () {
				var attachment = frame.state().get("selection").first().toJSON();
				$("#download_item_id").val(attachment.id);
				$("#download_item_url").val(attachment.url);
			});

			frame.open();
			return false;
		});

		// Single image uploader processing
		$("#upload_image").on("click", function () {
			if (frame) {
				frame.open();
				return false;
			}

			frame = wp.media({
				title: "Upload Product Logo",
				button: {
					text: "Insert Logo",
				},
				multiple: false,
			});

			frame.on("select", function () {
				var attachment = frame.state().get("selection").first().toJSON();
				$("#product_logo_img_id").val(attachment.id);
				$("#product_logo_img_url").val(attachment.url);
				$("#logo_display").html(`<img src="${attachment.url}" />`);
			});

			frame.open();
			return false;
		});

		// Multiple image uploader processing
		$("#upload_gallery_image").on("click", function () {
			if (gframe) {
				gframe.open();
				return false;
			}

			gframe = wp.media({
				title: "Upload Product Images",
				button: {
					text: "Insert Images",
				},
				multiple: true,
			});

			gframe.on("select", function () {
				var image_ids = [];
				var image_urls = [];
				var attachments = gframe.state().get("selection").toJSON();

				//console.log( attachments );
				$("#gallery_display").html("");
				for (i in attachments) {
					var attachment = attachments[i];
					image_ids.push(attachment.id);
					image_urls.push(attachment.url);
					$("#gallery_display").append(`<img src="${attachment.url}" />`);
				}

				//console.log( image_ids,image_urls );

				$("#product_gallery_img_id").val(image_ids.join(";"));
				$("#product_gallery_img_url").val(image_urls.join(";"));
			});

			gframe.open();
			return false;
		});
	});

})(jQuery);
