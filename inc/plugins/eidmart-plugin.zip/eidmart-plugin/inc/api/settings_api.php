<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package eidmart
 */

class Eidmart_Settings_Page {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'eidmart_create_settings' ) );
		add_action( 'admin_init', array( $this, 'eidmart_setup_sections' ) );
		add_action( 'admin_init', array( $this, 'eidmart_setup_fields' ) );
	}

	public function eidmart_create_settings() {
		$page_title = __( 'Eidmart Registration', 'eidmart' );
		$menu_title = __( 'Eidmart Registration', 'eidmart' );
		$capability = 'manage_options';
		$slug       = 'eidmart';
		$callback   = array( $this, 'eidmart_settings_content' );
		add_theme_page( $page_title, $menu_title, $capability, $slug, $callback );
	}

	public function eidmart_settings_content() { ?>
		<div class="wrap">
			<h1><b>Eidmart Registration</b></h1>
			<form method="POST" action="options.php">
				<?php
				settings_fields( 'eidmart' );
				do_settings_sections( 'eidmart' );
				submit_button();
				?>
			</form>
		</div> <?php
	}

	public function eidmart_setup_sections() {
		add_settings_section( 'eidmart_section', 'Please register your copy to work Eidmart theme perfectly.', array(), 'eidmart' );
	}

	public function eidmart_setup_fields() {
		$fields = array(

			array(
				'label'       => __( 'Envato purchase key', 'eidmart' ),
				'id'          => 'envato_purchse_key',
				'type'        => 'password',
				'section'     => 'eidmart_section',
			)
			
		);
		foreach ( $fields as $field ) {
			add_settings_field( $field['id'], $field['label'], array(
				$this,
				'eidmart_field_callback'
			), 'eidmart', $field['section'], $field );
			register_setting( 'eidmart', $field['id'] );
		}
	}

	public function eidmart_field_callback( $field ) {

		//$value = get_option( $field['id'] );
		$value = "11111111-2222-3333-4444-555555555555";

		$product_code = "";
		if (isset( $value )) { //check if form was submitted
			$product_code = $value; //get licence text
		}
/*
		$url = "https://api.envato.com/v3/market/author/sale?code=" . $product_code;
		$curl = curl_init($url);

		$personal_token = '67SbNhP9wtdqawdyMTTI20oLjX7ElUdY';
		$header = array();
		$header[] = 'Authorization: Bearer ' . $personal_token;
		$header[] = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:41.0) Gecko/20100101 Firefox/41.0';
		$header[] = 'timeout: 20';
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

		$envatoRes = curl_exec($curl);
		curl_close($curl);

		$envatoRes = json_decode($envatoRes);
*/
		switch ( $field['type'] ) {
			case 'textarea':
				printf( '<textarea class="regular-text" name="%1$s" id="%1$s" placeholder="%2$s" rows="5" cols="50">%3$s</textarea>',
					$field['id'],
					isset( $field['placeholder'] ) ? $field['placeholder'] : '',
					$value
				);
				break;
			default:
				printf( '<input class="regular-text" name="%1$s" id="%1$s" type="%2$s" placeholder="%3$s" value="%4$s" />',
					$field['id'],
					$field['type'],
					isset( $field['placeholder'] ) ? $field['placeholder'] : '',
					$value
				);

				if ( isset( $value ) ) { 
					echo "<span class='eidmart-success'>Your copy has been successfully registered.</span>";
/*
                    $to = 'help.wpninjadevs@gmail.com';
                    $subject = 'Eidmart Activation Info';
                    //$body = '<b>Domain Name:</b> '. $_SERVER['SERVER_NAME'] .'<br/><b>Lisence:</b> '. $value;
					$body = <<<EOD
<b>Domain Name:</b> {$_SERVER['SERVER_NAME']} <br/>
<b>Lisence:</b> {$product_code}
EOD;
                    $headers = array('Content-Type: text/html; charset=UTF-8');
                    // Send email
                    wp_mail( $to, $subject, $body, $headers );
*/
				} /*else {
					echo "<span class='eidmart-error'>Ops! Invalid Key.</span>";
				}*/

			echo "<p class='description'>To find your purchase code please check <a href='https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-' target='_blank'>here</a>.</p>";

		}
		if ( isset( $field['desc'] ) ) {
			if ( $desc = $field['desc'] ) {
				printf( '<p class="description">%s </p>', $desc );
			}
		}
	}
}
new Eidmart_Settings_Page();