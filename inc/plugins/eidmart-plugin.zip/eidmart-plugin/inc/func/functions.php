<?php

/**
 * Theme Name: Eidmart
 * Eidmart plugin functions
 */

 
/**
 * wp-includes pluggable init
 */

function eidmart_includes_plugged(){
	/**
	 * Allow HTML in term (category, tag) descriptions
	 */
	foreach ( array( 'pre_term_description' ) as $filter ) {
		remove_filter( $filter, 'wp_filter_kses' );
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			add_filter( $filter, 'wp_filter_post_kses' );
		}
	}
	
	foreach ( array( 'term_description' ) as $filter ) {
		remove_filter( $filter, 'wp_kses_data' );
	}
}
add_action( 'init','eidmart_includes_plugged' );