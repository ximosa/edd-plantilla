<?php
/*
Plugin Name: Eidmart Plugin
Plugin URI: https://wpninjadevs.com/
Description: This plugin is developed to build Eidmart theme features.
Author: wpninjaDevs
Version: 2.1
Author URI: https://wpninjadevs.com/
*/

add_filter( 'widget_text', 'do_shortcode' );

/**
 * Load plugin textdomain.
 */
function eidmart_load_textdomain() {
    load_plugin_textdomain( 'eidmart_textdomain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'eidmart_load_textdomain' );

require_once 'inc/metabox/metabox.php';
require_once 'inc/like/post-like.php';

// Inner pages
require_once 'inc/inner/inner-page.php';
require_once 'inc/inner/data-fetch.php';
require_once 'inc/inner/custom-widget.php';

/**
 * Plugin functions
 */
require_once 'inc/func/functions.php';

/**
 * Eidmart Job & Event CPT
 * require_once 'inc/inner/cpt.php';
 * @return void
 */
require_once 'inc/api/settings_api.php';
require_once 'inc/api/api.php';

/**
 * User follow system
 */
require_once 'inc/user-follow/user_follow.php';

/**
 * Eidmart Elementor initialization
 * 
 * @return void
 */
require_once 'inc/elementor-widget/initialization.php';

if ( EnvatoApi() ) {     
    // Eidmart one click demo imports action hook
    add_filter( 'pt-ocdi/import_files', 'eidmart_import_files' );
}

/**
 * Eidmart one click demo imports
 * 
 * @return void
 */
function eidmart_import_files() {
    return array(
        array(
            'import_file_name'           => 'Software Demo',
            'categories'                 => array( 'Software' ),
            'import_file_url'            => plugin_dir_url( __FILE__ ) . 'dummy_content/software/content.xml',
            'import_widget_file_url'     => plugin_dir_url( __FILE__ ) . 'dummy_content/software/widget.wie',
            'import_customizer_file_url' => plugin_dir_url( __FILE__ ) . 'dummy_content/software/customizer.dat',
            'import_preview_image_url'   => plugin_dir_url( __FILE__ ) . 'dummy_content/software/software.png',
            'import_notice'              => __( 'After click on the Import button only once and wait, it can take a couple of minutes. It depends on your server performance. Know more <a href="https://github.com/awesomemotive/one-click-demo-import/blob/master/docs/import-problems.md">Learn more</a>', 'eidmart' ),
        ),
        array(
            'import_file_name'           => 'Audio Demo',
            'categories'                 => array( 'Audio' ),
            'import_file_url'            => plugin_dir_url( __FILE__ ) . 'dummy_content/audio/content.xml',
            'import_widget_file_url'     => plugin_dir_url( __FILE__ ) . 'dummy_content/audio/widget.wie',
            'import_customizer_file_url' => plugin_dir_url( __FILE__ ) . 'dummy_content/audio/customizer.dat',
            'import_preview_image_url'   => plugin_dir_url( __FILE__ ) . 'dummy_content/audio/audio.png',
            'import_notice'              => __( 'After click on the Import button only once and wait, it can take a couple of minutes. It depends on your server performance. Know more <a href="https://github.com/awesomemotive/one-click-demo-import/blob/master/docs/import-problems.md">Learn more</a>', 'eidmart' ),
        ),
        array(
            'import_file_name'           => 'Photography Demo',
            'categories'                 => array( 'Photography' ),
            'import_file_url'            => plugin_dir_url( __FILE__ ) . 'dummy_content/photography/content.xml',
            'import_widget_file_url'     => plugin_dir_url( __FILE__ ) . 'dummy_content/photography/widget.wie',
            'import_customizer_file_url' => plugin_dir_url( __FILE__ ) . 'dummy_content/photography/customizer.dat',
            'import_preview_image_url'   => plugin_dir_url( __FILE__ ) . 'dummy_content/photography/photography.png',
            'import_notice'              => __( 'After click on the Import button only once and wait, it can take a couple of minutes. It depends on your server performance. Know more <a href="https://github.com/awesomemotive/one-click-demo-import/blob/master/docs/import-problems.md">Learn more</a>', 'eidmart' ),
        ),
        array(
            'import_file_name'           => 'Videomart Demo',
            'categories'                 => array( 'Videomart' ),
            'import_file_url'            => plugin_dir_url( __FILE__ ) . 'dummy_content/video/content.xml',
            'import_widget_file_url'     => plugin_dir_url( __FILE__ ) . 'dummy_content/video/widget.wie',
            'import_customizer_file_url' => plugin_dir_url( __FILE__ ) . 'dummy_content/video/customizer.dat',
            'import_preview_image_url'   => plugin_dir_url( __FILE__ ) . 'dummy_content/video/video.png',
            'import_notice'              => __( 'After click on the Import button only once and wait, it can take a couple of minutes. It depends on your server performance. Know more <a href="https://github.com/awesomemotive/one-click-demo-import/blob/master/docs/import-problems.md">Learn more</a>', 'eidmart' ),
        ),
        array(
            'import_file_name'           => 'Graphics Demo',
            'categories'                 => array( 'Graphics' ),
            'import_file_url'            => plugin_dir_url( __FILE__ ) . 'dummy_content/graphics/content.xml',
            'import_widget_file_url'     => plugin_dir_url( __FILE__ ) . 'dummy_content/graphics/widget.wie',
            'import_customizer_file_url' => plugin_dir_url( __FILE__ ) . 'dummy_content/graphics/customizer.dat',
            'import_preview_image_url'   => plugin_dir_url( __FILE__ ) . 'dummy_content/graphics/graphics.png',
            'import_notice'              => __( 'After click on the Import button only once and wait, it can take a couple of minutes. It depends on your server performance. Know more <a href="https://github.com/awesomemotive/one-click-demo-import/blob/master/docs/import-problems.md">Learn more</a>', 'eidmart' ),
        ),

    );
}

/**
 * After import page setup
 * 
 * @return void
 */
function eidmart_after_import_setup() {

    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
            'primary' => $main_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function
        )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home' );
    //$blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    //update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'eidmart_after_import_setup' );

// Disable the branding notice 
add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );
